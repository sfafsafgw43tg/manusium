# -*- coding: utf-8 -*-
"""
vStudio — rozszerzenie v1.3 (UI + logika)
======================================================
Ten modul dodaje do aplikacji (przez mixin):

  • ZAKLADKA "AUDIO"  — os czasu z plikami audio: dodawanie, odtwarzanie,
    pauza, wznawianie, przewijanie (klik na osi), petla, glosnosc klipu,
    pauza mikrofonu, ODSLUCH (dzwiek slyszalny u siebie) i NAGRYWANIE WAV.
  • ZAKLADKA "AI WIDEO" — darmowe, w pelni OFFLINE AI: piszesz prompt
    (albo wybierasz gotowy styl), AI zamienia go na plan filmu, akceptujesz
    prompt i renderuje sie film ze zdjec (ken burns, ziarno, winieta,
    przejscia, ciecia w rytm muzyki). Kolejne akceptacje ucza lokalny model
    stylu (ai_learning.json) — bez internetu.

Wszystkie metody korzystaja z atrybutow aplikacji (self.audio, self.video,
self.timeline, ...) tworzonych w app.py.
"""
import os
import queue
import sys
import threading
import time

import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox

# --- paleta (identyczna jak w app.py: czarno-bialy minimalizm) ---
BG = "#0B0D12"
CARD = "#141821"
CARD2 = "#1B212E"
LINE = "#262E40"
MUTED = "#8B93A5"
TEXT = "#E9EBF1"
DIM = "#5A6272"
WHITE = "#F2F3F6"
GHOST = dict(fg_color="transparent", border_width=1, border_color=LINE,
             text_color=TEXT, corner_radius=10, hover_color=CARD2)
PRIMARY = dict(fg_color=WHITE, text_color="black", hover_color="#C9CDD6",
               corner_radius=10)

APP_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    from audio_timeline import AudioTimeline, Recorder, fmt_time, AUDIO_EXTS
    HAS_TIMELINE = True
except Exception:
    HAS_TIMELINE = False
    AudioTimeline = Recorder = None
    AUDIO_EXTS = (".wav", ".mp3", ".ogg", ".flac", ".m4a")
    def fmt_time(s):
        try:
            s = max(0, int(float(s)))
            return "%d:%02d" % (s // 60, s % 60)
        except Exception:
            return "0:00"

try:
    import ai_video as AI
    HAS_AI = True
except Exception:
    HAS_AI = False
    AI = None


def _sec(v):
    try:
        return "%.1f s" % float(v)
    except Exception:
        return "-"


def _rescale(plan, q):
    """Ustawia mniejszy bok na q, zachowujac proporcje (pion/poziom/kwadrat)."""
    try:
        W, H = plan["rozmiar"]
        if H >= W:
            return [int(q), int(round(q * H / float(W)))]
        return [int(round(q * W / float(H))), int(q)]
    except Exception:
        return [int(q), int(q * 16 / 9.0)]


class V13Mixin(object):

    # ==================================================================== INIT
    def _init_v13(self):
        """Tworzy obiekty nowych funkcji — wolane z RealmeStudioApp.__init__."""
        try:
            a = self.cfg_audio()
            self.timeline = None
            if HAS_TIMELINE and self.audio is not None:
                self.timeline = AudioTimeline(int(a.get("sample_rate", 48000)))
                self.timeline.gain = float(a.get("music_gain", 0.9))
                self.timeline.loop_all = bool(a.get("music_loop", False))
                self.timeline.on_change = self._on_timeline_change
                try:
                    self.audio.attach_timeline(self.timeline)
                except Exception:
                    pass
            self.recorder = Recorder(int(a.get("sample_rate", 48000)),
                                     a.get("record_folder") or None) if HAS_TIMELINE else None
            self._rec_on = False
            # Local monitoring must always start OFF. Persisted true values used
            # to feed speakers during startup and could create feedback before
            # the user had selected a safe output device.
            self._monitor_on = False
            a["monitor_on"] = False
            self._music_sel = 0
            self._mon_map = {"(domyślne)": None}
            self._tl_head = None
            self._tl_items = []
            self._ui_queue = queue.Queue()

            # --- AI wideo ---
            ai = self.cfg_ai()
            self.ai_photos = [p for p in (ai.get("photos") or []) if p]
            self.ai_plan = None
            self.ai_prompt_accepted = ""
            self._ai_thread = None
            self._ai_cancel = False
            self._ai_quality = ai.get("quality", "1080p")
            self._ai_music_name = ai.get("music_name", "") or "(bez muzyki)"
            self._ai_render_path = ""
            self._ai_last_stats = {}
        except Exception:
            pass

    def _ui_post(self, fn):
        """Bezpieczne zlecenie zmiany UI z innego watku (drenuje ticker)."""
        try:
            self._ui_queue.put(fn)
        except Exception:
            pass

    def _ui_drain(self, limit=40):
        try:
            for _ in range(limit):
                fn = self._ui_queue.get_nowait()
                try:
                    fn()
                except Exception:
                    pass
        except queue.Empty:
            return
        except Exception:
            return

    # male helpery na konfiguracje (dzialaja nawet bez CFG)
    def cfg_audio(self):
        try:
            return self.CFG["audio"]
        except Exception:
            return {}

    def cfg_ai(self):
        try:
            return self.CFG.get("ai", {}) or {}
        except Exception:
            return {}

    # ====================================================== SILNIK AUDIO (wspolny)
    def _want_engine(self):
        music = False
        try:
            music = bool(self.timeline is not None and self.timeline.playing
                         and not self.timeline.paused)
        except Exception:
            pass
        return bool(getattr(self, "broadcasting", False) or music
                    or getattr(self, "_rec_on", False)
                    or getattr(self, "_monitor_on", False))

    def _sync_engine(self, force=False):
        """Uruchamia / zatrzymuje silnik audio zaleznie od tego, co sie dzieje."""
        try:
            if self.audio is None or self.audio.demo_mode:
                return
            want = self._want_engine()
            if want:
                dev = self._dev_map.get(self.var_outdev.get())
                if force or not self.audio.is_running():
                    if self.audio.is_running():
                        self.audio.stop()
                        time.sleep(0.12)
                    self.audio.start(output_device=dev)
                    if self.audio.last_error:
                        self._log(self.audio.last_error)
                if self._monitor_on:
                    ok = self.audio.start_monitor(self._monitor_dev(), self._mon_gain())
                    if not ok:
                        self._log("Odsłuch: " + (self.audio.monitor_error() or "nie udało się"))
            else:
                self.audio.stop_monitor()
                if self.audio.is_running():
                    self.audio.stop()
            self._update_leds()
        except Exception as e:
            self._log("Audio: " + str(e))

    def _mon_gain(self):
        try:
            return float(self.sld_mon_gain.get())
        except Exception:
            return 0.8

    def _monitor_dev(self):
        try:
            return self._mon_map.get(self.var_mon_dev.get())
        except Exception:
            return None

    def _active_audio_source_name(self):
        """Human-readable input that currently supplies the virtual microphone."""
        try:
            if self.audio is not None:
                return self.audio.active_input_device_name()
        except Exception:
            pass
        return "Generator vStudio"

    # =============================================== ZAKLADKA: AUDIO / OS CZASU
    def _tab_music(self, tab):
        box = self._scroll_tab(tab)

        self._section(box, "Pliki audio (os czasu)")
        row = ctk.CTkFrame(box, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=(2, 0))
        ctk.CTkButton(row, text="Dodaj audio", width=104, command=self._music_add,
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row, text="Folder", width=72, command=self._music_add_folder,
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row, text="Wyczyść", width=78, command=self._music_clear,
                      **GHOST).pack(side="left", padx=3)
        self._hint(box, "Muzyka, dźwięki, głos — wszystko leci RAZEM z szumem "
                        "mikrofonu do wirtualnego kabla. Pliki: mp3, wav, ogg, flac, m4a.")

        self.music_list = ctk.CTkFrame(box, fg_color=CARD2, corner_radius=10)
        self.music_list.pack(fill="x", padx=16, pady=6)

        # ---- os czasu (rysowana na kanwie) ----
        self.tl_canvas = tk.Canvas(box, height=58, bg=CARD2, highlightthickness=0,
                                   bd=0)
        self.tl_canvas.pack(fill="x", padx=16, pady=(2, 2))
        self.tl_canvas.bind("<Button-1>", self._tl_seek_click)
        self.lbl_tl_time = ctk.CTkLabel(box, text="0:00 / 0:00", font=ctk.CTkFont(size=11),
                                        text_color=MUTED)
        self.lbl_tl_time.pack(anchor="w", padx=16)

        row2 = ctk.CTkFrame(box, fg_color="transparent")
        row2.pack(fill="x", padx=12, pady=4)
        ctk.CTkButton(row2, text="▶  Odtwarzaj", width=104, command=self._music_play,
                      **PRIMARY).pack(side="left", padx=3)
        ctk.CTkButton(row2, text="❚❚  Pauza", width=88, command=self._music_pause,
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row2, text="■  Stop", width=74, command=self._music_stop,
                      **GHOST).pack(side="left", padx=3)
        row3 = ctk.CTkFrame(box, fg_color="transparent")
        row3.pack(fill="x", padx=12, pady=(0, 2))
        ctk.CTkButton(row3, text="◀  −5 s", width=84, command=lambda: self._music_nudge(-5),
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row3, text="+5 s  ▶", width=84, command=lambda: self._music_nudge(5),
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row3, text="Odtwórz wybrany", width=140, command=self._music_play_selected,
                      **GHOST).pack(side="left", padx=3)

        self.var_music_loop = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(box, text="Pętla (cała os czasu)", variable=self.var_music_loop,
                        command=self._on_music_loop).pack(anchor="w", padx=16, pady=(6, 2))
        self.var_mic_pause = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(box, text="Pauza mikrofonu (cisza na wyjściu)",
                        variable=self.var_mic_pause,
                        command=self._on_mic_pause).pack(anchor="w", padx=16, pady=(0, 2))
        self._hint(box, "Spacja = pauza/wznowienie. Klik na osi = skok do miejsca.")

        self._section(box, "Głośność")
        pct = lambda v: "%d%%" % int(float(v) * 100)
        self.sld_music, self.val_music = self._slider_card(
            box, "Głośność muzyki", float(self.cfg_audio().get("music_gain", 0.9)),
            0, 1.5, 30, pct, self._on_music_gain)
        self.sld_clip, self.val_clip = self._slider_card(
            box, "Głośność wybranego klipu", 1.0, 0, 2, 40, pct, self._on_clip_gain)

        # ---- odsluch ----
        self._section(box, "Odsłuch — słyszę dźwięk u siebie")
        self.lbl_mon_source = ctk.CTkLabel(
            box, text="Źródło mikrofonu: %s" % self._active_audio_source_name(),
            font=ctk.CTkFont(size=11, weight="bold"), text_color=TEXT,
            wraplength=300, justify="left")
        self.lbl_mon_source.pack(anchor="w", padx=16, pady=(2, 5))
        self.var_monitor = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(box, text="Włącz odsłuch (głośniki / słuchawki)",
                        variable=self.var_monitor, command=self._toggle_monitor).pack(
                            anchor="w", padx=16, pady=2)
        ctk.CTkLabel(box, text="Urządzenie odsłuchu", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(anchor="w", padx=16, pady=(8, 0))
        self.var_mon_dev = ctk.StringVar(value=self.cfg_audio().get("monitor_device_name", "") or "(domyślne)")
        self.opt_mon_dev = ctk.CTkOptionMenu(box, variable=self.var_mon_dev, values=["(domyślne)"],
                                             width=270, command=lambda _: self._on_monitor_dev_change())
        self.opt_mon_dev.pack(anchor="w", padx=16, pady=4)
        self.sld_mon_gain, self.val_mon_gain = self._slider_card(
            box, "Głośność odsłuchu", float(self.cfg_audio().get("monitor_gain", 0.8)),
            0, 1, 20, pct, self._on_monitor_gain)
        self.lbl_mon = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11),
                                    text_color=MUTED, wraplength=280, justify="left")
        self.lbl_mon.pack(anchor="w", padx=16, pady=(2, 0))
        self._hint(box, "Odsłuch NIE zmienia tego, co idzie do kabla — to tylko kopia dla "
                        "Twoich uszu. Wybierz tu swoje głośniki lub słuchawki (nie kabel).")

        # ---- nagrywanie ----
        self._section(box, "Nagrywanie")
        row4 = ctk.CTkFrame(box, fg_color="transparent")
        row4.pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(row4, text="●  Nagraj", width=104, command=self._toggle_record,
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row4, text="Folder nagrań", width=120, command=self._open_record_folder,
                      **GHOST).pack(side="left", padx=3)
        self.lbl_rec = ctk.CTkLabel(box, text="Nagrywanie wyłączone.", font=ctk.CTkFont(size=11),
                                    text_color=MUTED, wraplength=280, justify="left")
        self.lbl_rec.pack(anchor="w", padx=16, pady=(4, 0))
        self._hint(box, "Zapisuje dokładnie to, co leci na wirtualny mikrofon "
                        "(szum + muzyka) do pliku WAV — do odsłuchu i montażu.")

        try:
            self._refresh_music_list()
            self._draw_timeline()
            self._refresh_monitor_combo()
        except Exception:
            pass

    # ------------------------------------------------------ lista i os czasu
    def _refresh_music_list(self):
        try:
            for w in self.music_list.winfo_children():
                w.destroy()
            clips = self.timeline.clips if self.timeline else []
            if not clips:
                ctk.CTkLabel(self.music_list, text="Pusto — dodaj pliki audio.",
                             text_color=MUTED, font=ctk.CTkFont(size=11)).pack(padx=8, pady=10)
                return
            for i, c in enumerate(clips):
                row = ctk.CTkFrame(self.music_list, fg_color="transparent")
                row.pack(fill="x", padx=6, pady=2)
                sel = (i == self._music_sel)
                name = c.name if len(c.name) <= 26 else c.name[:24] + "…"
                txt = "%d. %s  (%s)%s" % (i + 1, name, fmt_time(c.duration),
                                          "  [cisza]" if c.mute else "")
                ctk.CTkButton(row, text=txt, anchor="w", height=28,
                              font=ctk.CTkFont(size=11),
                              fg_color=(WHITE if sel else "transparent"),
                              text_color=("black" if sel else TEXT),
                              hover_color=CARD2, corner_radius=8,
                              command=lambda i=i: self._music_select(i)).pack(
                                  side="left", fill="x", expand=True, padx=(0, 4))
                ctk.CTkButton(row, text="▶", width=28, height=28, font=ctk.CTkFont(size=11),
                              command=lambda i=i: self._music_play_selected(i),
                              **GHOST).pack(side="left", padx=2)
                ctk.CTkButton(row, text="✕", width=28, height=28, font=ctk.CTkFont(size=11),
                              command=lambda i=i: self._music_remove(i),
                              **GHOST).pack(side="left", padx=2)
        except Exception:
            pass

    def _music_select(self, i):
        self._music_sel = i
        try:
            c = self.timeline.clips[i]
            self.sld_clip.set(c.gain)
            self.val_clip.configure(text="%d%%" % int(c.gain * 100))
        except Exception:
            pass
        self._refresh_music_list()
        self._draw_timeline()

    def _draw_timeline(self):
        """Rysuje os czasu: bloki klipow + playhead."""
        try:
            c = self.tl_canvas
            c.delete("all")
            self._tl_head = None
            W = int(c.winfo_width() or 280)
            H = int(c.winfo_height() or 58)
            if W < 30:
                W = 280
            clips = self.timeline.clips if self.timeline else []
            total = self.timeline.total_duration if self.timeline else 0.0
            if not clips or total <= 0:
                c.create_text(W // 2, H // 2, text="Brak plików audio",
                              fill=MUTED, font=("Segoe UI", 10))
                return
            cur = self.timeline.current_index()
            x = 4
            span = W - 8
            for i, clip in enumerate(clips):
                w = max(8, int(round((clip.duration / total) * span)))
                fill = WHITE if i == cur else "#2B3448"
                c.create_rectangle(x, 8, x + w - 2, H - 20, fill=fill, outline=LINE)
                label = clip.name if len(clip.name) <= 12 else clip.name[:10] + "…"
                if w > 40:
                    c.create_text(x + 6, (H - 12) / 2 + 6, text=label, anchor="w",
                                  fill=("black" if i == cur else TEXT),
                                  font=("Segoe UI", 9))
                x += w
            pos = self.timeline.position
            px = 4 + int(round((pos / total) * span)) if total > 0 else 4
            px = max(4, min(W - 4, px))
            self._tl_head = c.create_line(px, 2, px, H - 2, fill=WHITE, width=2)
            self.lbl_tl_time.configure(text="%s / %s   •   %s" % (
                fmt_time(pos), fmt_time(total),
                (clips[cur].name if 0 <= cur < len(clips) else "-")))
        except Exception:
            pass

    def _tick_timeline(self):
        """Tania aktualizacja playheada (bez przerysowania calosci)."""
        try:
            if self.timeline is None or not self.tl_canvas.winfo_exists():
                return
            total = self.timeline.total_duration
            if total <= 0 or self._tl_head is None:
                return
            W = int(self.tl_canvas.winfo_width() or 280)
            H = int(self.tl_canvas.winfo_height() or 58)
            span = W - 8
            px = 4 + int(round((self.timeline.position / total) * span))
            px = max(4, min(W - 4, px))
            self.tl_canvas.coords(self._tl_head, px, 2, px, H - 2)
            self.lbl_tl_time.configure(text="%s / %s%s" % (
                fmt_time(self.timeline.position), fmt_time(total),
                "   •   PAUZA" if self.timeline.paused else
                ("" if self.timeline.playing else "   •   stop")))
        except Exception:
            pass

    def _tl_seek_click(self, event):
        try:
            if self.timeline is None:
                return
            total = self.timeline.total_duration
            if total <= 0:
                return
            W = int(self.tl_canvas.winfo_width() or 280)
            frac = max(0.0, min(1.0, (event.x - 4) / float(max(1, W - 8))))
            self.timeline.seek(frac * total)
            self._draw_timeline()
            self._log("Przewinięto na %s." % fmt_time(frac * total))
        except Exception:
            pass

    def _on_timeline_change(self):
        self._ui_post(self._draw_timeline)

    # ------------------------------------------------------------ dodawanie
    def _music_add(self):
        if self.timeline is None:
            self._log("Brak modułu audio (uruchom INSTALUJ.bat).")
            return
        exts = [("Audio", " ".join("*" + e for e in AUDIO_EXTS)),
                ("Wszystkie pliki", "*.*")]
        paths = filedialog.askopenfilenames(title="Dodaj pliki audio", filetypes=exts)
        if paths:
            self._music_load(list(paths))

    def _music_add_folder(self):
        if self.timeline is None:
            return
        folder = filedialog.askdirectory(title="Folder z muzyką")
        if not folder:
            return
        found = []
        for root, _, files in os.walk(folder):
            for f in files:
                if os.path.splitext(f)[1].lower() in AUDIO_EXTS:
                    found.append(os.path.join(root, f))
            if len(found) > 200:
                break
        if found:
            self._music_load(found)
        else:
            self._log("W tym folderze nie ma plików audio.")

    def _music_load(self, paths):
        self._log("Wczytuję %d plików audio…" % len(paths))

        def work():
            added, failed = 0, 0
            for p in paths:
                try:
                    c = self.timeline.add(p)
                    if c.ok:
                        added += 1
                    else:
                        failed += 1
                except Exception:
                    failed += 1
            def done():
                self._log("Dodano %d plików audio%s." % (
                    added, (", %d nie udało się" % failed) if failed else ""))
                self._refresh_music_list()
                self._draw_timeline()
                self._refresh_ai_music()
                self._sync_engine()
            self._ui_post(done)
        threading.Thread(target=work, daemon=True).start()

    def _music_remove(self, i=None):
        try:
            if i is None:
                i = self._music_sel
            self.timeline.remove(i)
            self._music_sel = max(0, min(i, len(self.timeline.clips) - 1))
            self._refresh_music_list()
            self._draw_timeline()
            self._refresh_ai_music()
            self._sync_engine()
        except Exception:
            pass

    def _music_clear(self):
        try:
            self.timeline.clear()
            self._music_sel = 0
            self._refresh_music_list()
            self._draw_timeline()
            self._sync_engine()
            self._log("Wyczyszczono oś czasu.")
        except Exception:
            pass

    def _music_move(self, d):
        try:
            self.timeline.move(self._music_sel, d)
            self._music_sel = max(0, self._music_sel + d)
            self._refresh_music_list()
            self._draw_timeline()
        except Exception:
            pass

    # ------------------------------------------------------------ transport
    def _music_play(self):
        try:
            if self.timeline is None or not self.timeline.clips:
                self._log("Najpierw dodaj pliki audio.")
                return
            self.timeline.play()
            self._sync_engine()
            if self._monitor_off_hint():
                pass
            self._log("Odtwarzanie muzyki (razem z szumem mikrofonu).")
        except Exception as e:
            self._log(str(e))

    def _music_play_selected(self, i=None):
        try:
            if self.timeline is None or not self.timeline.clips:
                return
            if i is not None:
                self._music_sel = i
            self.timeline.play(index=self._music_sel)
            self._sync_engine()
            self._log("Odtwarzam klip: %s" % self.timeline.clips[self._music_sel].name)
            self._refresh_music_list()
        except Exception:
            pass

    def _music_pause(self):
        try:
            self.timeline.pause()
            self._log("Muzyka: pauza (pozycja zapamiętana).")
        except Exception:
            pass

    def _music_stop(self):
        try:
            self.timeline.stop()
            self._sync_engine()
            self._draw_timeline()
            self._log("Muzyka: stop.")
        except Exception:
            pass

    def _music_toggle_play(self):
        try:
            if self.timeline is None:
                return
            st = self.timeline.toggle_play()
            self._sync_engine()
            self._draw_timeline()
            self._log("Muzyka: %s" % ("wznowienie" if (st[0] and not st[1]) else "pauza"))
        except Exception:
            pass

    def _music_nudge(self, d):
        try:
            self.timeline.nudge(d)
            self._draw_timeline()
        except Exception:
            pass

    def _on_music_loop(self):
        try:
            self.timeline.loop_all = bool(self.var_music_loop.get())
        except Exception:
            pass

    def _on_mic_pause(self):
        try:
            if self.audio:
                self.audio.set_paused(bool(self.var_mic_pause.get()))
                self._log("Mikrofon: %s" % ("PAUZA (cisza)" if self.var_mic_pause.get() else "wznowiony"))
        except Exception:
            pass

    def _on_music_gain(self):
        try:
            g = float(self.sld_music.get())
            self.timeline.gain = g
            if self.audio is not None and getattr(self.audio, "mixer", None) is not None:
                self.audio.mixer.music_gain = g
        except Exception:
            pass

    def _on_clip_gain(self):
        try:
            c = self.timeline.clips[self._music_sel]
            c.gain = float(self.sld_clip.get())
        except Exception:
            pass

    # ------------------------------------------------------------ odsluch
    def _monitor_off_hint(self):
        if not self._monitor_on:
            self._log("Wskazówka: włącz „Odsłuch”, żeby słyszeć to u siebie.")
            return True
        return False

    def _refresh_monitor_combo(self):
        try:
            lister = None
            try:
                lister = self.audio.list_output_devices
            except Exception:
                lister = None
            if lister is None:
                import audio_engine as _ae
                lister = _ae.PhoneNoiseEngine.list_output_devices
            devs = lister() or []
            names = ["(domyślne)"] + [n for _, n in devs]
            self._mon_map = {"(domyślne)": None}
            for i, n in devs:
                self._mon_map[n] = i
            cur = getattr(self, "var_mon_dev", None)
            val = cur.get() if cur is not None else "(domyślne)"
            if val not in names:
                val = "(domyślne)"
            self.opt_mon_dev.configure(values=names)
            self.var_mon_dev.set(val)
        except Exception:
            pass

    def _on_monitor_dev_change(self):
        try:
            if self._monitor_on and self.audio is not None:
                ok = self.audio.start_monitor(self._monitor_dev(), self._mon_gain())
                self._log("Odsłuch: %s" % (self.var_mon_dev.get() if ok else
                                           ("błąd — " + (self.audio.monitor_error() or "?"))))
        except Exception:
            pass

    def _on_monitor_gain(self):
        try:
            if self.audio is not None and getattr(self.audio, "monitor", None):
                self.audio.monitor.gain = float(self.sld_mon_gain.get())
        except Exception:
            pass

    def _toggle_monitor(self):
        try:
            self._monitor_on = bool(self.var_monitor.get())
            if self._monitor_on and self.audio is not None and self.audio.demo_mode:
                self._log("Odsłuch niemożliwy — brak modułu dźwięku (tryb demo).")
                self._monitor_on = False
                self.var_monitor.set(False)
                return
            self._sync_engine(force=self._monitor_on)
            if self._monitor_on:
                err = self.audio.monitor_error() if self.audio else ""
                self._log("Odsłuch włączony (%s)%s" % (
                    self.var_mon_dev.get(), (" — " + err) if err else ""))
            else:
                if self.audio is not None:
                    self.audio.stop_monitor()
                self._log("Odsłuch wyłączony.")
        except Exception as e:
            self._log("Odsłuch: " + str(e))

    # ------------------------------------------------------------ nagrywanie
    def _toggle_record(self):
        try:
            if self.recorder is None:
                self._log("Brak modułu nagrywania.")
                return
            if self._rec_on:
                path = self.recorder.stop()
                self._rec_on = False
                if self.audio is not None:
                    self.audio.remove_tap(self.recorder.tap)
                self.lbl_rec.configure(text="Zapisano: %s" % os.path.basename(path or ""))
                self._log("Nagranie zapisane: %s" % path)
                self._sync_engine()
                return
            if self.audio is not None:
                self.audio.add_tap(self.recorder.tap)
            self.recorder.start()
            self._rec_on = True
            self._sync_engine(force=True)
            self.lbl_rec.configure(text="● Nagrywam… %s" % os.path.basename(self.recorder.path))
            self._log("Nagrywanie: %s" % self.recorder.path)
            if self.audio is not None and self.audio.demo_mode:
                self._log("Uwaga: tryb demo — nagranie będzie ciche.")
        except Exception as e:
            self._log("Nagrywanie: " + str(e))

    def _open_record_folder(self):
        try:
            folder = self.recorder.folder if self.recorder else APP_DIR
            os.makedirs(folder, exist_ok=True)
            self._open_path(folder)
        except Exception:
            pass

    def _open_path(self, path):
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)          # noqa
            else:
                import subprocess
                subprocess.Popen(["xdg-open", path])
        except Exception as e:
            self._log("Nie mogę otworzyć: %s" % e)

    # ================================================================ AI WIDEO
    def _tab_ai(self, tab):
        box = self._scroll_tab(tab)

        self._section(box, "Prompt — powiedz AI, co ma powstać")
        self.txt_prompt = ctk.CTkTextbox(box, height=84, font=ctk.CTkFont(size=12),
                                         fg_color=CARD2, corner_radius=10,
                                         border_width=1, border_color=LINE,
                                         text_color=TEXT, wrap="word")
        self.txt_prompt.pack(fill="x", padx=16, pady=4)
        try:
            self.txt_prompt.insert("1.0", self.cfg_ai().get("prompt", "") or "")
        except Exception:
            pass
        row = ctk.CTkFrame(box, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(row, text="Zaproponuj", width=104, command=self._ai_suggest,
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row, text="Akceptuj prompt", width=136, command=self._ai_accept_prompt,
                      **PRIMARY).pack(side="left", padx=3)
        self._hint(box, "Pisz po polsku, np. „kinowy film 30 sekund, wolne najazdy, sepia, "
                        "ciecia w rytm muzyki”. AI zamieni to na liczby i pokaże plan.")

        self._section(box, "Biblioteka stylów")
        self.var_preset = ctk.StringVar(value=list(AI.PRESETS.keys())[0] if HAS_AI else "-")
        values = list(AI.PRESETS.keys()) if HAS_AI else ["-"]
        self.opt_preset = ctk.CTkOptionMenu(box, variable=self.var_preset, values=values,
                                            width=270, command=self._on_preset)
        self.opt_preset.pack(anchor="w", padx=16, pady=4)
        self.lbl_preset = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11),
                                       text_color=MUTED, wraplength=280, justify="left")
        self.lbl_preset.pack(anchor="w", padx=16)
        ctk.CTkButton(box, text="Użyj tego stylu", width=150, command=self._use_preset,
                      **GHOST).pack(anchor="w", padx=16, pady=6)

        self._section(box, "Plan AI (do akceptacji)")
        self.lbl_ai_plan = ctk.CTkLabel(box, text="Napisz prompt i kliknij „Akceptuj prompt”.",
                                        font=ctk.CTkFont(size=11), text_color=MUTED,
                                        wraplength=280, justify="left")
        self.lbl_ai_plan.pack(anchor="w", padx=16)

        self._section(box, "Zdjęcia do filmu")
        row_ph = ctk.CTkFrame(box, fg_color="transparent")
        row_ph.pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(row_ph, text="Dodaj zdjęcia", width=118, command=self._ai_add_photos,
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row_ph, text="Z playlisty", width=104, command=self._ai_from_playlist,
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row_ph, text="Wyczyść", width=80, command=self._ai_clear_photos,
                      **GHOST).pack(side="left", padx=3)
        self.lbl_ai_photos = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11),
                                          text_color=MUTED, wraplength=280, justify="left")
        self.lbl_ai_photos.pack(anchor="w", padx=16, pady=(2, 0))

        self._section(box, "Ustawienia filmu")
        qrow = ctk.CTkFrame(box, fg_color="transparent")
        qrow.pack(fill="x", padx=16, pady=(4, 2))
        ctk.CTkLabel(qrow, text="Jakość:", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="left")
        self.var_ai_quality = ctk.StringVar(value=self._ai_quality)
        ctk.CTkSegmentedButton(qrow, values=["720p", "1080p"], variable=self.var_ai_quality,
                               command=self._on_ai_quality).pack(side="left", padx=8)
        mrow = ctk.CTkFrame(box, fg_color="transparent")
        mrow.pack(fill="x", padx=16, pady=(2, 2))
        ctk.CTkLabel(mrow, text="Muzyka:", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="left")
        self.var_ai_music = ctk.StringVar(value=self._ai_music_name)
        self.opt_ai_music = ctk.CTkOptionMenu(mrow, variable=self.var_ai_music,
                                              values=["(bez muzyki)"], width=180,
                                              command=lambda _: self._on_ai_music())
        self.opt_ai_music.pack(side="left", padx=8)
        self.var_ai_beat = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(box, text="Cięcia w rytm muzyki (z zakładki Audio)",
                        variable=self.var_ai_beat,
                        command=self._ai_update_plan_label).pack(anchor="w", padx=16, pady=(6, 2))
        self.sld_ai_klip, self.val_ai_klip = self._slider_card(
            box, "Długość jednego zdjęcia", 4.0, 0.8, 12.0, 56, _sec, self._ai_slider_changed)
        self.sld_ai_ruch, self.val_ai_ruch = self._slider_card(
            box, "Siła ruchu kamery", 0.12, 0.0, 0.4, 40,
            lambda v: "%.2f" % float(v), self._ai_slider_changed)
        self.sld_ai_ziarno, self.val_ai_ziarno = self._slider_card(
            box, "Ziarno filmowe", 5.0, 0.0, 30.0, 60,
            lambda v: "%.0f" % float(v), self._ai_slider_changed)
        self.sld_ai_cel, self.val_ai_cel = self._slider_card(
            box, "Docelowa długość (0 = auto)", 0.0, 0.0, 120.0, 120,
            lambda v: ("%.0f s" % float(v)) if float(v) > 0 else "auto",
            self._ai_slider_changed)

        self._section(box, "Render")
        row_r = ctk.CTkFrame(box, fg_color="transparent")
        row_r.pack(fill="x", padx=12, pady=2)
        self.btn_ai_render = ctk.CTkButton(row_r, text="Renderuj film", width=136,
                                           command=self._ai_render, **PRIMARY)
        self.btn_ai_render.pack(side="left", padx=3)
        ctk.CTkButton(row_r, text="Anuluj", width=80, command=self._ai_cancel_render,
                      **GHOST).pack(side="left", padx=3)
        self.pb_ai = ctk.CTkProgressBar(box, height=12, corner_radius=6,
                                        fg_color=CARD2, progress_color=WHITE)
        self.pb_ai.pack(fill="x", padx=16, pady=(6, 2))
        self.pb_ai.set(0)
        self.lbl_ai_status = ctk.CTkLabel(box, text="Gotowe do renderu.", font=ctk.CTkFont(size=11),
                                          text_color=MUTED, wraplength=280, justify="left")
        self.lbl_ai_status.pack(anchor="w", padx=16)
        row_o = ctk.CTkFrame(box, fg_color="transparent")
        row_o.pack(fill="x", padx=12, pady=4)
        ctk.CTkButton(row_o, text="Otwórz folder", width=118, command=self._ai_open_folder,
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row_o, text="Dodaj do playlisty", width=140,
                      command=self._ai_add_to_playlist, **GHOST).pack(side="left", padx=3)

        self._section(box, "Nauka AI (lokalna)")
        self.lbl_ai_learn = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11),
                                         text_color=MUTED, wraplength=280, justify="left")
        self.lbl_ai_learn.pack(anchor="w", padx=16)
        ctk.CTkButton(box, text="Wyczyść naukę", width=130, command=self._ai_reset_learning,
                      **GHOST).pack(anchor="w", padx=16, pady=6)
        self._hint(box, "AI uczy się lokalnie: każdy zaakceptowany prompt zapisuje się "
                        "w pliku ai_learning.json i wpływa na kolejne filmy. Bez internetu.")

        try:
            self._on_preset(self.var_preset.get())
            self._refresh_ai_photos()
            self._refresh_ai_music()
            self._ai_refresh_learning()
            self._refresh_monitor_combo()
        except Exception:
            pass

    # ------------------------------------------------------------- prompt
    def _ai_orientation(self):
        try:
            return self.video.orientation
        except Exception:
            return "portrait"

    def _ai_photo_list(self):
        try:
            own = [p for p in (self.ai_photos or []) if os.path.isfile(p)]
            if own:
                return own
            if self.video:
                return [it["path"] for it in self.video.playlist if it.get("type") == "image"
                        and os.path.isfile(it["path"])]
        except Exception:
            pass
        return []

    def _ai_music_path(self):
        try:
            name = self.var_ai_music.get()
            if name and name != "(bez muzyki)" and self.timeline:
                for c in self.timeline.clips:
                    if c.name == name:
                        return c.path
        except Exception:
            pass
        return ""

    def _ai_suggest(self):
        try:
            photos = self._ai_photo_list()
            p = AI.suggest_prompt(len(photos) or 6, bool(self._ai_music_path()),
                                  os.path.basename(self._ai_music_path()),
                                  self._ai_orientation())
            self.txt_prompt.delete("1.0", "end")
            self.txt_prompt.insert("1.0", p)
            self._log("AI zaproponowało prompt. Kliknij „Akceptuj prompt”.")
        except Exception as e:
            self._log("AI: " + str(e))

    def _on_preset(self, name):
        try:
            info = AI.PRESETS.get(name, {}) if HAS_AI else {}
            self.lbl_preset.configure(text=info.get("opis", "-"))
        except Exception:
            pass

    def _use_preset(self):
        try:
            name = self.var_preset.get()
            p = AI.preset_prompt(name)
            if not p:
                return
            self.txt_prompt.delete("1.0", "end")
            self.txt_prompt.insert("1.0", p)
            self._ai_accept_prompt()
            self._log("Styl z biblioteki: %s" % name)
        except Exception as e:
            self._log("AI: " + str(e))

    def _ai_accept_prompt(self):
        """Zamienia prompt na plan (liczby) i pokazuje go do akceptacji."""
        if not HAS_AI:
            self._log("Moduł AI niedostępny (sprawdź plik ai_video.py).")
            return None
        try:
            text = self.txt_prompt.get("1.0", "end").strip()
        except Exception:
            text = ""
        if not text:
            messagebox.showinfo("Prompt", "Napisz, jaki film ma powstać, albo kliknij "
                                          "„Zaproponuj” / wybierz styl z biblioteki.")
            return None
        photos = self._ai_photo_list()
        music = self._ai_music_path()
        plan = AI.parse_prompt(text, max(1, len(photos)), bool(music), self._ai_orientation())
        plan["rozmiar"] = _rescale(plan, 720 if "720" in self.var_ai_quality.get() else 1080)
        if music:
            plan["beat_plik"] = music
            if self.var_ai_beat.get():
                plan["beat_sync"] = True
        self.ai_plan = plan
        self.ai_prompt_accepted = text
        self._ai_sync_sliders()
        self._ai_update_plan_label()
        self._log("Prompt zaakceptowany → plan: %s (klip %.1f s, %s przejścia)" % (
            plan["nazwa"], plan["klip_s"], plan["przejscia"]["typ"]))
        if not photos:
            self._log("Uwaga: brak zdjęć — dodaj je w sekcji „Zdjęcia do filmu” "
                      "albo do playlisty (zakładka Obraz).")
        return plan

    def _ai_sync_sliders(self):
        try:
            p = self.ai_plan or {}
            ru = (p.get("ruch") or {}).get("amp", 0.12)
            ob = (p.get("obraz") or {}).get("ziarno", 5.0)
            self.sld_ai_klip.set(float(p.get("klip_s", 4.0)))
            self.val_ai_klip.configure(text=_sec(p.get("klip_s", 4.0)))
            self.sld_ai_ruch.set(float(ru))
            self.val_ai_ruch.configure(text="%.2f" % float(ru))
            self.sld_ai_ziarno.set(float(ob))
            self.val_ai_ziarno.configure(text="%.0f" % float(ob))
            self.sld_ai_cel.set(float(p.get("cel_s", 0.0)))
            self.val_ai_cel.configure(text=("auto" if float(p.get("cel_s", 0.0)) <= 0
                                            else "%.0f s" % float(p.get("cel_s", 0.0))))
        except Exception:
            pass

    def _ai_slider_changed(self):
        try:
            if not self.ai_plan:
                return
            self.ai_plan["klip_s"] = float(self.sld_ai_klip.get())
            self.ai_plan.setdefault("ruch", {})["amp"] = float(self.sld_ai_ruch.get())
            self.ai_plan.setdefault("obraz", {})["ziarno"] = float(self.sld_ai_ziarno.get())
            self.ai_plan["cel_s"] = float(self.sld_ai_cel.get())
            self._ai_update_plan_label()
        except Exception:
            pass

    def _ai_update_plan_label(self):
        try:
            if not self.ai_plan:
                return
            if self.var_ai_beat.get() and self._ai_music_path():
                self.ai_plan["beat_sync"] = True
                self.ai_plan["beat_plik"] = self._ai_music_path()
            elif not self.var_ai_beat.get():
                self.ai_plan["beat_sync"] = False
            self.lbl_ai_plan.configure(
                text=AI.plan_text(self.ai_plan, len(self._ai_photo_list()), self._ai_music_path()))
        except Exception:
            pass

    def _on_ai_quality(self, val=None):
        try:
            if self.ai_plan:
                self.ai_plan["rozmiar"] = _rescale(
                    self.ai_plan, 720 if "720" in self.var_ai_quality.get() else 1080)
                self._ai_update_plan_label()
        except Exception:
            pass

    def _on_ai_music(self):
        try:
            self.ai_plan and self._ai_update_plan_label()
        except Exception:
            pass

    # ------------------------------------------------------------- zdjecia
    def _ai_add_photos(self):
        exts = [("Zdjęcia", "*.jpg *.jpeg *.png *.bmp *.webp *.tif *.tiff"),
                ("Wszystkie", "*.*")]
        paths = filedialog.askopenfilenames(title="Zdjęcia do filmu AI", filetypes=exts)
        if paths:
            for p in paths:
                if p not in self.ai_photos:
                    self.ai_photos.append(p)
            self._refresh_ai_photos()
            self._log("Zdjęcia do AI: %d" % len(self.ai_photos))

    def _ai_from_playlist(self):
        try:
            photos = [it["path"] for it in self.video.playlist if it.get("type") == "image"]
            if not photos:
                self._log("W playliście nie ma zdjęć (tylko nagrania).")
                return
            self.ai_photos = list(photos)
            self._refresh_ai_photos()
            self._log("Wzięto %d zdjęć z playlisty." % len(photos))
        except Exception:
            pass

    def _ai_clear_photos(self):
        self.ai_photos = []
        self._refresh_ai_photos()

    def _refresh_ai_photos(self):
        try:
            own = [p for p in self.ai_photos if os.path.isfile(p)]
            playlist = 0
            try:
                playlist = len([it for it in self.video.playlist if it.get("type") == "image"])
            except Exception:
                pass
            if own:
                txt = "Wybrane: %d zdjęć (własna lista).\nPierwsze: %s" % (
                    len(own), ", ".join(os.path.basename(p) for p in own[:3]))
            elif playlist:
                txt = "Brak własnej listy — AI użyje %d zdjęć z playlisty (zakładka Obraz)." % playlist
            else:
                txt = "Brak zdjęć — dodaj pliki albo wczytaj je do playlisty."
            self.lbl_ai_photos.configure(text=txt)
        except Exception:
            pass

    def _refresh_ai_music(self):
        try:
            names = ["(bez muzyki)"]
            if self.timeline:
                names += [c.name for c in self.timeline.clips]
            cur = self.var_ai_music.get()
            if cur not in names:
                cur = names[0]
            self.opt_ai_music.configure(values=names)
            self.var_ai_music.set(cur)
        except Exception:
            pass

    # ------------------------------------------------------------- render
    def _ai_render(self):
        if not HAS_AI:
            self._log("Moduł AI niedostępny.")
            return
        try:
            if self._ai_thread is not None and self._ai_thread.is_alive():
                self._log("Render już trwa — poczekaj albo kliknij Anuluj.")
                return
            photos = self._ai_photo_list()
            if not photos:
                messagebox.showinfo("AI Wideo", "Dodaj zdjęcia (albo wczytaj je do playlisty), "
                                                "żeby zrobić film.")
                return
            if not self.ai_plan:
                if self._ai_accept_prompt() is None:
                    return
            if not self._ai_accept_prompt_if_changed():
                pass
            out_dir = os.path.join(APP_DIR, "output")
            os.makedirs(out_dir, exist_ok=True)
            out = os.path.join(out_dir, "AI_wideo_%s.mp4" % time.strftime("%Y-%m-%d_%H-%M-%S"))
            self._ai_cancel = False
            self.pb_ai.set(0)
            self.lbl_ai_status.configure(text="Renderuję… (możesz korzystać z aplikacji)")
            self.btn_ai_render.configure(state="disabled")
            plan = dict(self.ai_plan)
            self._ai_thread = threading.Thread(target=self._ai_worker,
                                               args=(photos, plan, out), daemon=True)
            self._ai_thread.start()
        except Exception as e:
            self._log("AI render: " + str(e))

    def _ai_accept_prompt_if_changed(self):
        """Jesli tekst promptu zmienil sie od ostatniej akceptacji — przelicz plan."""
        try:
            cur = self.txt_prompt.get("1.0", "end").strip()
            if cur and cur != self.ai_prompt_accepted:
                return self._ai_accept_prompt() is not None
        except Exception:
            pass
        return False

    def _ai_worker(self, photos, plan, out):
        def prog(a, b):
            frac = min(1.0, a / float(max(1, b)))
            txt = "Render: %d / %d klatek (%.0f%%)" % (a, b, 100.0 * frac)
            self._ui_post(lambda: (self.pb_ai.set(frac),
                                   self.lbl_ai_status.configure(text=txt)))

        def log(m):
            self._ui_post(lambda m=m: self._log("AI: " + m))

        try:
            ok, msg, path, stats = AI.render(photos, plan, out,
                                             progress=prog, cancel=lambda: self._ai_cancel,
                                             log=log)
        except Exception as e:
            ok, msg, path, stats = False, "Błąd renderu: %s" % e, "", {}
        self._ui_post(lambda: self._ai_done(ok, msg, path, stats))

    def _ai_done(self, ok, msg, path, stats):
        try:
            self.btn_ai_render.configure(state="normal")
            self.pb_ai.set(1.0 if ok else 0.0)
            self.lbl_ai_status.configure(text=msg)
            self._log("AI: " + msg)
            if ok:
                self._ai_render_path = path
                self._ai_last_stats = stats or {}
                try:
                    AI.learning().reinforce(self.ai_plan or {}, self.ai_prompt_accepted)
                    self._ai_refresh_learning()
                    self._log("AI zapamiętało ten styl (nauka lokalna).")
                except Exception:
                    pass
                self.bell()
            else:
                self._log("AI: render nie udał się.")
        except Exception:
            pass

    def _ai_cancel_render(self):
        self._ai_cancel = True
        self._log("Anuluję render…")

    def _ai_open_folder(self):
        self._open_path(os.path.dirname(self._ai_render_path) if self._ai_render_path
                        else os.path.join(APP_DIR, "output"))

    def _ai_add_to_playlist(self):
        try:
            if not self._ai_render_path or not os.path.isfile(self._ai_render_path):
                self._log("Najpierw wyrenderuj film.")
                return
            n = self.video.add_files([self._ai_render_path])
            self._refresh_playlist_ui()
            self._log("Dodano film AI do playlisty (%d)." % n)
        except Exception as e:
            self._log("Playlista: " + str(e))

    def _ai_refresh_learning(self):
        try:
            self.lbl_ai_learn.configure(text=AI.learning().stats())
        except Exception:
            pass

    def _ai_reset_learning(self):
        try:
            if messagebox.askyesno("Nauka AI", "Wyczyścić lokalną pamięć stylów AI?"):
                AI.learning().reset()
                self._ai_refresh_learning()
                self._log("Pamięć AI wyczyszczona.")
        except Exception:
            pass

    # ============================================== SPRZATANIE / ZAPIS USTAWIEN
    def _v13_on_close(self):
        """Zapis dodatkowych ustawien — wolane z _on_close."""
        try:
            a = self.CFG.setdefault("audio", {})
            if self.timeline is not None:
                a["music_gain"] = float(self.timeline.gain)
                a["music_loop"] = bool(self.timeline.loop_all)
                a["music_files"] = [c.path for c in self.timeline.clips if c.ok][:80]
            a["monitor_on"] = bool(self._monitor_on)
            try:
                a["monitor_device_name"] = self.var_mon_dev.get()
            except Exception:
                pass
            try:
                a["monitor_gain"] = float(self.sld_mon_gain.get())
            except Exception:
                pass
            if self.recorder is not None:
                a["record_folder"] = self.recorder.folder
            self.CFG["ai"] = {
                "prompt": (self.txt_prompt.get("1.0", "end").strip()[:600]
                           if hasattr(self, "txt_prompt") else ""),
                "photos": list(self.ai_photos)[:200],
                "quality": self.var_ai_quality.get() if hasattr(self, "var_ai_quality") else "1080p",
                "music_name": self.var_ai_music.get() if hasattr(self, "var_ai_music") else "",
            }
        except Exception:
            pass

    def _v13_shutdown(self):
        try:
            if self.recorder is not None and getattr(self, "_rec_on", False):
                self.recorder.stop()
        except Exception:
            pass
        try:
            if self.audio is not None:
                self.audio.stop_monitor()
        except Exception:
            pass
        try:
            if self.timeline is not None:
                self.timeline.stop()
        except Exception:
            pass

    # ------------------------------------------- startowe pliki muzyki z configu
    def _v13_restore_music(self):
        """Po starcie doklada pliki audio zapisane w config.json (w tle)."""
        try:
            files = [p for p in (self.cfg_audio().get("music_files") or []) if os.path.isfile(p)]
            if not files or self.timeline is None:
                return
            self._log("Przywracam %d plików audio z ostatniej sesji…" % len(files))
            self._music_load(files)
        except Exception:
            pass

    # --------------------------------------------------------- skroty klawiszowe
    def _v13_bind_keys(self):
        try:
            self.bind("<space>", lambda e: self._music_toggle_play())
            self.bind("<Control-r>", lambda e: self._toggle_record())
            self.bind("<Control-m>", lambda e: self.var_monitor.set(not self.var_monitor.get())
                      or self._toggle_monitor())
        except Exception:
            pass

    # --------------------------------------------------- ticker dodatkowy (VU mon)
    def _v13_tick(self):
        try:
            self._ui_drain()
            self._tick_timeline()
            if self.audio is not None:
                source_name = self._active_audio_source_name()
                self.lbl_mon_source.configure(text="Źródło mikrofonu: %s" % source_name)
                if self._monitor_on:
                    self.lbl_mon.configure(text="Odsłuch: poziom %.0f%% · %s" % (
                        self.audio.monitor_level() * 100.0, source_name))
                else:
                    self.lbl_mon.configure(text="Odsłuch wyłączony · źródło: %s" % source_name)
            if self._rec_on and self.recorder is not None:
                self.lbl_rec.configure(text="● Nagrywam %s   (%s)" % (
                    os.path.basename(self.recorder.path), fmt_time(self.recorder.seconds)))
        except Exception:
            pass;
