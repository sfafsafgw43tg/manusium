# -*- coding: utf-8 -*-
"""
vStudio — lokalny generator mowy (TTS). 100% OFFLINE.

Żadnego chmury, żadnego API, żadnych zapytań sieciowych. Tekst → plik WAV,
a WAV trafia na oś czasu audio, więc rozmówca słyszy mowę przez wirtualny
mikrofon (razem z szumem telefonu) i w nagrywaniu.

Silniki (w kolejności, pierwszy działający wygrywa):
  1) Windows — System.Speech (.NET Framework, wbudowane głosy SAPI5,
     np. „Microsoft Zosia Desktop”, „Microsoft Mark Desktop”). Zero instalacji.
  2) espeak-ng w PATH (Linux / Windows) — `espeak-ng -v pl -w plik.wav`.
  3) pyttsx3 (opcjonalne `pip install pyttsx3`) — ten sam SAPI5/espeak, przez Pythona.

Wynik zawsze to samo: ścieżka do WAV + krótki komunikat. Wszystko w wątku
roboczym — UI nigdy nie wisi.
"""
import os
import subprocess
import sys
import tempfile
import threading

WIN = sys.platform.startswith("win")

MAX_CHARS = 6000            # twardszy limit niż w okienku — ochrona przed „ścinaniem”
VOICES_TIMEOUT = 20
SYNTH_TIMEOUT = 180

_ps_lock = threading.Lock()  # PowerShell nie lubi równoległych wywołań w tej samej apce


# ------------------------------------------------------------------ pomocnicze
def _run(cmd, timeout=60, shell=False):
    """Uruchom, złap stdout/stderr, nie pokazuj okienka na Windows."""
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if WIN else 0
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=timeout, creationflags=flags, shell=shell,
                           stdin=subprocess.DEVNULL)
        out = (p.stdout or b"").decode("utf-8", "replace")
        err = (p.stderr or b"").decode("utf-8", "replace")
        return p.returncode == 0, out, err
    except FileNotFoundError:
        return False, "", "brak programu: %s" % (cmd[0] if cmd else "?")
    except subprocess.TimeoutExpired:
        return False, "", "przekroczono czas (%ds)" % timeout
    except Exception as e:                       # noqa: BLE001
        return False, "", str(e)


def _write_ps(script):
    """Zapisz skrypt .ps1 w UTF-8 z BOM (PowerShell 5.1 inaczej gubi polskie znaki)."""
    fd, path = tempfile.mkstemp(prefix="r12ps_", suffix=".ps1")
    with os.fdopen(fd, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write(script)
    return path


def _write_txt(text):
    fd, path = tempfile.mkstemp(prefix="r12txt_", suffix=".txt")
    with os.fdopen(fd, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(text)
    return path


def _which(name):
    """Szukaj binarki (bez pełnego 'which', żeby nie ciągnąć modułów)."""
    exe = name + (".exe" if WIN else "")
    for d in os.environ.get("PATH", "").split(os.pathsep):
        if d:
            p = os.path.join(d, exe)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                return p
    return None


_PS = "powershell.exe" if WIN else "powershell"


# --------------------------------------------------------------------- silniki
def have_powershell():
    if not WIN:
        return False
    ok, out, _ = _run([_PS, "-NoProfile", "-Command", "Write-Output ok"], timeout=25)
    return ok and "ok" in out.lower()


def have_espeak():
    return bool(_which("espeak-ng") or _which("espeak"))


def have_pyttsx3():
    try:
        import pyttsx3                      # noqa: F401
        return True
    except Exception:
        return False


_CHECKS = {"windows": have_powershell, "espeak": have_espeak, "pyttsx3": have_pyttsx3}


def detect_backend():
    """'windows' | 'espeak' | 'pyttsx3' | '' (nic nie ma)."""
    for be in ("windows", "espeak", "pyttsx3"):
        if _CHECKS[be]():
            return be
    return ""


_BACKEND = {"id": None}


def backend(force=False):
    if _BACKEND["id"] is None or force:
        _BACKEND["id"] = detect_backend()
    return _BACKEND["id"]


def is_available():
    return bool(backend())


# ----------------------------------------------------------------------- głosy
_VOICE_SCRIPT = r'''
$ErrorActionPreference = "SilentlyContinue"
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
foreach ($v in $s.GetInstalledVoices()) {
  if ($v.Enabled) {
    $i = $v.VoiceInfo
    Write-Output ($i.Name + "`t" + $i.Culture.Name + "`t" + $i.Gender)
  }
}
$s.Dispose()
'''


def _voices_windows():
    script = _VOICE_SCRIPT
    path = _write_ps(script)
    try:
        ok, out, err = _run([_PS, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", path],
                            timeout=VOICES_TIMEOUT)
    finally:
        try:
            os.remove(path)
        except Exception:
            pass
    voices = []
    if ok:
        for line in out.splitlines():
            parts = line.strip().split("\t")
            if len(parts) >= 2 and parts[0]:
                gender = parts[2].lower() if len(parts) > 2 else ""
                g = "kobiecy" if "female" in gender else ("męski" if "male" in gender else "")
                label = "%s  (%s%s)" % (parts[0], parts[1], (" • " + g) if g else "")
                voices.append((parts[0], label))
    return voices


def _voices_espeak():
    exe = _which("espeak-ng") or _which("espeak")
    if not exe:
        return []
    ok, out, _ = _run([exe, "--voices"], timeout=VOICES_TIMEOUT)
    voices = []
    if ok:
        started = False
        for line in out.splitlines():
            if not started:
                started = line.strip().lower().startswith("idx") or "language" in line.lower()
                continue
            cols = line.split()
            if len(cols) < 3:
                continue
            lang, name = cols[2], " ".join(cols[3:])
            voices.append((lang, "%s  (%s)" % (name or lang, lang)))
    return voices


def list_voices():
    """[(id_glosu, etykieta_do_okna)] — pusta lista = użyj domyślnego głosu systemu."""
    be = backend()
    try:
        if be == "windows":
            return _voices_windows()
        if be == "espeak":
            return _voices_espeak()
        if be == "pyttsx3":
            import pyttsx3
            e = pyttsx3.init()
            out = []
            for i, vid in enumerate(getattr(e, "property", {}).get("voices", []) or []):
                name = getattr(vid, "name", "") or getattr(vid, "id", "glos %d" % i)
                out.append((getattr(vid, "id", name), name))
            return out
    except Exception:
        pass
    return []


# ----------------------------------------------------------------- synteza mowy
_SYNTH_SCRIPT = r'''
param([string]$TextFile, [string]$OutFile, [string]$Voice, [int]$Rate, [int]$Volume)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
if ($Voice) { try { $s.SelectVoice($Voice) } catch {} }
try { $s.Rate = $Rate } catch {}
try { $s.Volume = $Volume } catch {}
try {
  $fmt = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(44100, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)
  $s.SetOutputToWaveFile($OutFile, $fmt)
} catch { $s.SetOutputToWaveFile($OutFile) }
$txt = [System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8)
$s.Speak($txt)
$s.Dispose()
'''


def _synth_windows(text, out_path, voice, rate, volume):
    txt_path = _write_txt(text)
    ps_path = _write_ps(_SYNTH_SCRIPT)
    try:
        cmd = [_PS, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps_path,
               "-TextFile", txt_path, "-OutFile", out_path,
               "-Voice", (voice or ""), "-Rate", str(int(rate)),
               "-Volume", str(int(max(0, min(100, volume))))]
        with _ps_lock:
            ok, out, err = _run(cmd, timeout=SYNTH_TIMEOUT)
        if not ok:
            return False, "System.Speech: %s" % (err.strip()[:200] or "nie poszło")
        if not os.path.isfile(out_path) or os.path.getsize(out_path) < 1024:
            return False, "System.Speech: pusty plik WAV (pewnie brak głosów w systemie)."
        return True, "gotowe (Windows / System.Speech)"
    finally:
        for p in (txt_path, ps_path):
            try:
                os.remove(p)
            except Exception:
                pass


def _synth_espeak(text, out_path, voice, rate, volume):
    exe = _which("espeak-ng") or _which("espeak")
    if not exe:
        return False, "brak espeak-ng w PATH"
    txt_path = _write_txt(text)
    try:
        wpm = 170 + int(rate) * 18
        cmd = [exe, "-w", out_path, "-s", str(max(70, min(400, wpm))),
               "-a", str(int(60 + 40 * max(0.0, min(1.0, volume / 100.0))))]
        if voice:
            cmd[1:1] = ["-v", voice]
        cmd[1:1] = ["-f", txt_path]
        ok, out, err = _run(cmd, timeout=SYNTH_TIMEOUT)
        if not ok:
            return False, "espeak: %s" % (err.strip()[:200] or out.strip()[:200] or "nie poszło")
        if not os.path.isfile(out_path) or os.path.getsize(out_path) < 1024:
            return False, "espeak: pusty plik WAV"
        return True, "gotowe (espeak-ng)"
    finally:
        try:
            os.remove(txt_path)
        except Exception:
            pass


def _synth_pyttsx3(text, out_path, voice, rate, volume):
    try:
        import pyttsx3
    except Exception:
        return False, "brak pyttsx3 (pip install pyttsx3)"
    try:
        e = pyttsx3.init()
        try:
            e.setProperty("rate", 170 + int(rate) * 18)
            e.setProperty("volume", max(0.0, min(1.0, volume / 100.0)))
            if voice:
                for v in (e.property.get("voices", []) or []):
                    if getattr(v, "id", "") == voice or getattr(v, "name", "") == voice:
                        e.voice = v.id
                        break
        except Exception:
            pass
        e.save_to_file(text, out_path)
        e.runAndWait()
        try:
            e.stop()
        except Exception:
            pass
        if os.path.isfile(out_path) and os.path.getsize(out_path) > 1024:
            return True, "gotowe (pyttsx3)"
        return False, "pyttsx3: pusty plik WAV"
    except Exception as ex:                       # noqa: BLE001
        return False, "pyttsx3: %s" % ex


_SYNTH = {"windows": _synth_windows, "espeak": _synth_espeak, "pyttsx3": _synth_pyttsx3}


def _cloud_voice(net, voice):
    """Wybór głosu dla chmury: nazwa z listy OpenAI, inaczej to co w ustawieniach."""
    try:
        import cloud_net as C
        if voice and str(voice).strip() in C.TTS_VOICES:
            return str(voice).strip()
        v = str((net or {}).get("tts_voice") or "").strip()
        return v or None
    except Exception:
        return None


def synth(text, out_path, voice="", rate=0, volume=90, backend_id=None, net=None):
    """Tekst → plik WAV. Zwraca (ok, komunikat, sciezka).

    rate: -10..10 (tempo, jak w SAPI), volume: 0..100, voice: nazwa głosu lub "".
    net: sekcja „net” z configa — JEŚLI jest klucz API i zgoda, proba mowy
    z chmury (OpenAI /audio/speech). Bez tego lub przy wpadce: w 100% lokalnie.
    """
    text = (text or "").strip()
    if len(text) < 2:
        return False, "Wpisz tekst do wypowiedzenia.", ""
    if len(text) > MAX_CHARS:
        text = text[:MAX_CHARS]

    note = ""
    if net is not None and not backend_id:
        try:
            import cloud_net as C
        except Exception:
            C = None
        if C is not None and C.enabled(net, "tts"):
            try:
                sp = 1.0 + 0.05 * float(rate or 0)
            except Exception:
                sp = 1.0
            try:
                cok, cmsg, cpath = C.tts_speak(text, out_path, net,
                                               voice=_cloud_voice(net, voice), speed=sp)
            except Exception as e:                    # noqa: BLE001
                cok, cmsg, cpath = False, C.scrub(e, net), ""
            if cok:
                return True, "chmura: %s" % cmsg, (cpath or out_path)
            note = "  (chmura: %s — przesiadam się na silnik lokalny)" % cmsg

    be = backend_id or backend()
    if not be:
        return False, ("Brak lokalnego silnika mowy. Na Windows głosy SAPI5 są wbudowane "
                       "(sprawdź: Ustawienia → Czas i język → Mowa). Na Linuksie: "
                       "apt install espeak-ng. Opcjonalnie: pip install pyttsx3."), ""
    try:
        d = os.path.dirname(os.path.abspath(out_path))
        if d:
            os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    if os.path.isfile(out_path):
        try:
            os.remove(out_path)
        except Exception:
            out_path = out_path + ".tmp.wav"
    # pierwszy działający wygrywa; reszta to cichy fallback (awaryjnie)
    order = [be] + [b for b in ("windows", "espeak", "pyttsx3") if b != be]
    last = "brak silnika mowy"
    for b in order:
        try:
            ok, msg = _SYNTH[b](text, out_path, voice, rate, volume)
        except Exception as e:                    # noqa: BLE001
            ok, msg = False, "%s: %s" % (b, e)
        if ok and os.path.isfile(out_path) and os.path.getsize(out_path) > 1024:
            return True, msg + note, out_path
        last = msg
    return False, (last or "silnik mowy") + note, ""
