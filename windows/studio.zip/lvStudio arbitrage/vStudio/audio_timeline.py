# -*- coding: utf-8 -*-
"""
vStudio — modul AUDIO (v1.3)
=========================================
Trzy rzeczy, ktorych wczesniej nie bylo:

  1. TIMELINE  — dodajesz pliki audio (muzyka, dzwieki, glos), widzisz je na
     osi czasu, mozesz ZATRZYMAC / WZNOWIC / przewijac / loopowac / sciszac
     kazdy kawalek osobno.
  2. MIXER     — to wszystko idzie RAZEM z szumem telefonu do wirtualnego
     mikrofonu (CABLE Input). Odbiorec slyszy szum + muzyke zmiksowane.
  3. ODSLUCH   — "Slyszalny w aplikacji": dzwiek slyszysz takze u siebie
     (monitor na glosnikach/sluchawkach) i mozesz go wlaczac/wylaczac.
  4. NAGRYWANIE — zapis tego, co leci na wirtualny mikrofon, do pliku WAV.

Wszystko dziala OFFLINE — dekodowanie przez soundfile / miniaudio / ffmpeg
(jesli jest) / wbudowany modul wave. Bez internetu.
"""
import math
import os
import struct
import subprocess
import sys
import tempfile
import threading
import time
import wave

try:
    import numpy as np
    HAS_NUMPY = True
except Exception:
    HAS_NUMPY = False
    np = None

try:
    import soundfile as sf
    HAS_SF = True
except Exception:
    HAS_SF = False
    sf = None

try:
    import sounddevice as sd
    HAS_SD = True
except Exception:
    HAS_SD = False
    sd = None

try:
    import miniaudio as ma
    HAS_MINIAUDIO = True
except Exception:
    HAS_MINIAUDIO = False
    ma = None

AUDIO_EXTS = (".wav", ".mp3", ".ogg", ".flac", ".m4a", ".aac", ".wma",
              ".opus", ".aiff", ".aif", ".mp4", ".webm")


# ====================================================================== TAP
class RingTap:
    """Bufor pierscieniowy: silnik pisze, odbiorcy (odsluch / nagrywanie) czytaja."""

    def __init__(self, sample_rate=48000, seconds=1.5):
        self.sr = int(sample_rate)
        self.n = max(2048, int(self.sr * seconds))
        self.buf = np.zeros((self.n, 2), dtype=np.float32) if HAS_NUMPY else None
        self.w = 0
        self.r = 0
        self.lock = threading.Lock()
        self.dropped = 0

    def write(self, block):
        if not HAS_NUMPY or block is None:
            return
        try:
            b = np.asarray(block, dtype=np.float32)
            if b.ndim == 1:
                b = np.stack([b, b], axis=1)
            n = len(b)
            if n == 0:
                return
            if n > self.n:
                b = b[-self.n:]
                n = self.n
            with self.lock:
                end = self.w + n
                if end <= self.n:
                    self.buf[self.w:end] = b
                else:
                    first = self.n - self.w
                    self.buf[self.w:] = b[:first]
                    self.buf[:end - self.n] = b[first:]
                self.w = end % self.n
                avail = (self.w - self.r) % self.n
                if avail > int(self.n * 0.85):   # nadmiar: przeskocz do najnowszych
                    self.r = (self.w - int(self.n * 0.5)) % self.n
                    self.dropped += 1
        except Exception:
            pass

    def read(self, n):
        out = np.zeros((n, 2), dtype=np.float32)
        if not HAS_NUMPY:
            return out
        try:
            with self.lock:
                avail = (self.w - self.r) % self.n
                take = min(n, avail)
                if take:
                    end = self.r + take
                    if end <= self.n:
                        out[:take] = self.buf[self.r:end]
                    else:
                        first = self.n - self.r
                        out[:first] = self.buf[self.r:]
                        out[first:take] = self.buf[:end - self.n]
                    self.r = end % self.n
                if avail < n:            # brak danych → nie zostawaj w tyle (niska latencja)
                    self.r = self.w
        except Exception:
            pass
        return out

    def clear(self):
        try:
            with self.lock:
                self.buf[:] = 0.0
                self.r = self.w
        except Exception:
            pass

    def available(self):
        try:
            with self.lock:
                return (self.w - self.r) % self.n
        except Exception:
            return 0


# ============================================================ DEKODOWANIE
def _resample(x, sr_in, sr_out):
    """Prosta, szybka interpolacja liniowa (bez dodatkowych bibliotek)."""
    try:
        sr_in = int(sr_in or 0)
        sr_out = int(sr_out)
        if sr_in <= 0 or sr_in == sr_out:
            return x
        n_out = int(round(len(x) * sr_out / float(sr_in)))
        if n_out <= 1:
            return x
        src = np.arange(len(x), dtype=np.float64)
        dst = np.linspace(0.0, len(x) - 1.0, n_out)
        return np.interp(dst, src, x.astype(np.float64)).astype(np.float32)
    except Exception:
        return x


def _to_stereo(data):
    if data.ndim == 1:
        return np.stack([data, data], axis=1)
    if data.shape[1] == 1:
        return np.repeat(data, 2, axis=1)
    if data.shape[1] > 2:
        return data[:, :2]
    return data


def _read_ffmpeg(path):
    """Awaryjne dekodowanie przez ffmpeg.exe (jesli jest w PATH)."""
    tmp = None
    try:
        fd, tmp = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        exe = "ffmpeg.exe" if os.name == "nt" else "ffmpeg"
        cmd = [exe, "-y", "-v", "error", "-i", path, "-ac", "2",
               "-ar", "48000", "-f", "wav", tmp]
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=180, creationflags=flags, check=False)
        if os.path.isfile(tmp) and os.path.getsize(tmp) > 44:
            data, sr = sf.read(tmp, dtype="float32", always_2d=True) if HAS_SF else (None, 0)
            if data is not None and len(data):
                return _to_stereo(data), sr
    except Exception:
        pass
    finally:
        try:
            if tmp and os.path.isfile(tmp):
                os.remove(tmp)
        except Exception:
            pass
    return None, 0


def _read_wave_stdlib(path):
    try:
        with wave.open(path, "rb") as w:
            ch, sw, sr, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
            raw = w.readframes(n)
        if sw == 2:
            arr = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
        elif sw == 1:
            arr = (np.frombuffer(raw, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
        elif sw == 4:
            arr = np.frombuffer(raw, dtype="<i4").astype(np.float32) / 2147483648.0
        else:
            return None, 0
        if ch > 1:
            arr = arr.reshape(-1, ch)
        return _to_stereo(np.asarray(arr, dtype=np.float32)), sr
    except Exception:
        return None, 0


def decode_audio(path, target_sr=48000):
    """Zwraca (data[n,2] float32, sample_rate) albo (None, 0). Wszystko offline."""
    if not HAS_NUMPY:
        return None, 0
    ext = os.path.splitext(path)[1].lower()
    data, sr = None, 0

    if HAS_SF:
        try:
            data, sr = sf.read(path, dtype="float32", always_2d=True)
        except Exception:
            data, sr = None, 0

    if data is None and HAS_MINIAUDIO:
        try:
            dec = ma.decode_file(path)
            arr = np.asarray(dec.samples, dtype=np.float32)
            nch = int(getattr(dec, "nchannels", 1) or 1)
            if arr.ndim == 1 and nch > 1:
                arr = arr.reshape(-1, nch)
            data = _to_stereo(arr)
            sr = int(getattr(dec, "sample_rate", target_sr) or target_sr)
        except Exception:
            data, sr = None, 0

    if data is None and ext in (".wav", ".wave"):
        data, sr = _read_wave_stdlib(path)

    if data is None:
        data, sr = _read_ffmpeg(path)

    if data is None or len(data) == 0:
        return None, 0

    data = _to_stereo(np.asarray(data, dtype=np.float32))
    if int(sr) != int(target_sr):
        chans = [_resample(data[:, c], sr, target_sr) for c in range(data.shape[1])]
        m = min(len(c) for c in chans)
        data = np.stack([c[:m] for c in chans], axis=1)
    return data, int(target_sr)


# ====================================================================== KLIP
class AudioClip:
    """Jeden plik audio na osi czasu."""

    def __init__(self, path, data, sr):
        self.path = path
        self.name = os.path.basename(path)
        self.data = data                      # (n, 2) float32
        self.sr = int(sr)
        self.gain = 1.0                       # 0..2
        self.mute = False
        self.loop = False
        self.ok = data is not None and len(data) > 0
        self.error = "" if self.ok else "nie udalo sie zdekodowac"

    @property
    def n(self):
        return 0 if self.data is None else len(self.data)

    @property
    def duration(self):
        return self.n / float(self.sr) if self.sr else 0.0

    def read(self, start, frames):
        """Kawalek od probki `start` (z zapetleniem), dlugosci `frames`."""
        out = np.zeros((frames, 2), dtype=np.float32)
        if not self.ok or frames <= 0:
            return out
        take = frames
        a = int(start)
        if a >= self.n:
            if not self.loop:
                return out
            a %= self.n
        if a + take <= self.n:
            out[:take] = self.data[a:a + take]
        else:
            first = self.n - a
            out[:first] = self.data[a:]
            rest = take - first
            if self.loop and self.n > 0:
                reps = int(math.ceil(rest / float(self.n)))
                chunk = np.tile(self.data, (reps, 1))[:rest]
                out[first:] = chunk
            # bez loop: reszta zostaje cisza
        if self.mute:
            return np.zeros_like(out)
        return out * float(self.gain)


# ================================================================== TIMELINE
class AudioTimeline:
    """
    Oś czasu: klipy grane JEDEN PO DRUGIM (kolejka), z zatrzymaniem,
    wznowieniem, przewijaniem, petla i podgladem pozycji.

    Metoda read(n) jest wolana z watku audio silnika — dlatego wszystko
    chronione jest zamkiem.
    """

    def __init__(self, sample_rate=48000):
        self.sr = int(sample_rate)
        self.clips = []
        self.playing = False
        self.paused = False
        self.position = 0.0        # sekundy na calej osi
        self.loop_all = False
        self.gain = 0.9            # glosnosc muzyki (0..1.5)
        self._solo = None          # indeks klipu odtwarzanego pojedynczo
        self.on_change = None      # callback do UI
        self._lock = threading.RLock()
        self._started_at = 0.0
        self._paused_pos = 0.0

    # ---------------------------------------------------------- dodawanie
    def add(self, path, target_sr=None):
        data, sr = decode_audio(path, target_sr or self.sr)
        clip = AudioClip(path, data, sr or self.sr)
        with self._lock:
            self.clips.append(clip)
        self._notify()
        return clip

    def add_many(self, paths):
        added = 0
        for p in paths:
            try:
                c = self.add(p)
                if c.ok:
                    added += 1
            except Exception:
                continue
        return added

    def remove(self, index):
        with self._lock:
            if 0 <= index < len(self.clips):
                del self.clips[index]
        self._notify()

    def clear(self):
        with self._lock:
            self.clips = []
            self.position = 0.0
            self.playing = False
            self.paused = False
            self._solo = None
        self._notify()

    def move(self, index, delta):
        with self._lock:
            j = index + delta
            if 0 <= index < len(self.clips) and 0 <= j < len(self.clips):
                self.clips[index], self.clips[j] = self.clips[j], self.clips[index]
        self._notify()

    # ---------------------------------------------------------- wlasciwosci
    @property
    def total_duration(self):
        try:
            with self._lock:
                return float(sum(c.duration for c in self.clips))
        except Exception:
            return 0.0

    def clip_start(self, index):
        with self._lock:
            return float(sum(c.duration for c in self.clips[:index]))

    def index_at(self, t):
        with self._lock:
            acc = 0.0
            for i, c in enumerate(self.clips):
                d = c.duration
                if t < acc + d or i == len(self.clips) - 1:
                    return i, max(0.0, min(d, t - acc))
                acc += d
            return (0, 0.0) if self.clips else (-1, 0.0)

    def current_index(self):
        try:
            i, _ = self.index_at(self.position)
            return i
        except Exception:
            return -1

    # ---------------------------------------------------------- transport
    def play(self, index=None):
        with self._lock:
            if index is not None and 0 <= index < len(self.clips):
                self._solo = index
                self.position = self.clip_start(index)
            elif not self.clips:
                return False
            if self.position >= self.total_duration - 0.01 and self._solo is None:
                self.position = 0.0
            self.playing = True
            self.paused = False
        self._notify()
        return True

    def play_clip(self, index):
        return self.play(index=index)

    def pause(self):
        with self._lock:
            if self.playing:
                self.paused = True
                self._paused_pos = self.position
        self._notify()

    def resume(self):
        with self._lock:
            if self.playing and self.paused:
                self.paused = False
                self.position = self._paused_pos
        self._notify()

    def toggle_play(self):
        with self._lock:
            if not self.playing:
                self.playing = True
                self.paused = False
                if self.position >= self.total_duration - 0.01:
                    self.position = 0.0
            elif self.paused:
                self.paused = False
            else:
                self.paused = True
            st = (self.playing, self.paused)
        self._notify()
        return st

    def stop(self):
        with self._lock:
            self.playing = False
            self.paused = False
            self.position = 0.0
            self._solo = None
        self._notify()

    def seek(self, seconds):
        with self._lock:
            tot = self.total_duration
            self.position = max(0.0, min(tot, float(seconds)))
        self._notify()

    def nudge(self, delta_seconds):
        self.seek(self.position + float(delta_seconds))

    def is_active(self):
        with self._lock:
            return bool(self.playing and not self.paused and self.clips)

    def status(self):
        with self._lock:
            return {"playing": self.playing, "paused": self.paused,
                    "position": self.position, "total": self.total_duration,
                    "index": self.index_at(self.position)[0] if self.clips else -1}

    # ---------------------------------------------------------- audio
    def read(self, frames):
        """Miks klipow na osi — wolane z watku audio. Zwraca (frames, 2)."""
        out = np.zeros((frames, 2), dtype=np.float32)
        if not HAS_NUMPY or frames <= 0:
            return out
        with self._lock:
            if not self.playing or self.paused or not self.clips:
                return out
            solo = self._solo
            i, off = self.index_at(self.position)
            if i < 0:
                return out
            clip = self.clips[i]
            chunk = clip.read(int(off * clip.sr), frames)
            out += chunk
            self.position += frames / float(self.sr)

            # przejscie do nastepnego klipu
            if self.position >= self.clip_start(i) + clip.duration - 1e-6:
                if solo is not None:
                    # tryb "tylko ten klip" — konczymy po jego koncu
                    self.playing = False
                    self.paused = False
                    self._solo = None
                elif i >= len(self.clips) - 1:
                    if self.loop_all:
                        self.position = 0.0
                    else:
                        self.playing = False
                        self.position = self.total_duration
            g = float(self.gain)
            out *= g
        return out

    def _notify(self):
        try:
            if callable(self.on_change):
                self.on_change()
        except Exception:
            pass


# ==================================================================== MIXER
class AudioMixer:
    """Sumuje szum telefonu + os czasu muzyki, pilnuje limitera."""

    def __init__(self, sample_rate=48000):
        self.sr = int(sample_rate)
        self.noise_gain = 1.0
        self.music_gain = 0.9
        self.limiter = True

    def mix(self, noise_block, timeline_block):
        out = noise_block
        if timeline_block is not None and len(timeline_block):
            out = out + timeline_block
        if self.limiter:
            out = np.tanh(out * 0.9).astype(np.float32)
        else:
            out = np.clip(out, -1.0, 1.0).astype(np.float32)
        return out


# ================================================================== ODSLUCH
class MonitorOut:
    """Odsluch u siebie (glosniki/sluchawki) — dzwiek slyszalny w aplikacji."""

    def __init__(self, sample_rate=48000, device=None, gain=0.8, blocksize=1024):
        self.sr = int(sample_rate)
        self.device = device
        self.gain = float(gain)
        self.blocksize = int(blocksize)
        self.tap = RingTap(self.sr, seconds=1.0)
        self._stream = None
        self._level = 0.0
        self.last_error = ""

    @property
    def running(self):
        return self._stream is not None

    def start(self):
        if not HAS_SD:
            self.last_error = "brak sounddevice"
            return False
        if self.running:
            return True
        try:
            self._stream = sd.OutputStream(
                samplerate=self.sr, blocksize=self.blocksize, channels=2,
                dtype="float32", device=self.device, callback=self._cb)
            self._stream.start()
            self.last_error = ""
            return True
        except Exception as e:
            self.last_error = str(e)
            # awaryjnie: domyslne urzadzenie
            try:
                self._stream = sd.OutputStream(
                    samplerate=self.sr, blocksize=self.blocksize, channels=2,
                    dtype="float32", device=None, callback=self._cb)
                self._stream.start()
                self.last_error = "Wybrane urzadzenie odsluchu niedostepne — uzyto domyslnego."
                return True
            except Exception as e2:
                self._stream = None
                self.last_error = str(e2)
                return False

    def _cb(self, outdata, frames, time_info, status):
        try:
            buf = self.tap.read(frames) * float(self.gain)
            np.clip(buf, -1.0, 1.0, out=buf)
            try:
                rms = float(np.sqrt(np.mean(buf ** 2)))
                self._level = 0.7 * self._level + 0.3 * min(1.0, rms * 4.0)
            except Exception:
                pass
            outdata[:] = buf
        except Exception:
            outdata[:] = 0.0

    def stop(self):
        try:
            if self._stream is not None:
                self._stream.stop()
                self._stream.close()
        except Exception:
            pass
        self._stream = None
        self._level = 0.0

    def level(self):
        return float(self._level)

    def set_device(self, dev):
        was = self.running
        self.stop()
        self.device = dev
        if was:
            self.start()


# ================================================================ RECORDER
class Recorder:
    """Nagrywa to, co idzie na wirtualny mikrofon, do pliku WAV (16 bit)."""

    def __init__(self, sample_rate=48000, folder=None):
        self.sr = int(sample_rate)
        self.folder = folder or os.path.join(os.path.expanduser("~"), "Videos",
                                             "Realme12ProStudio")
        self.tap = RingTap(self.sr, seconds=3.0)
        self._thread = None
        self._run = False
        self.path = ""
        self.seconds = 0.0
        self.last_error = ""

    @property
    def running(self):
        return self._run

    def start(self, path=None):
        if self._run:
            return True
        try:
            os.makedirs(self.folder, exist_ok=True)
        except Exception:
            pass
        if not path:
            stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
            path = os.path.join(self.folder, "mikrofon_%s.wav" % stamp)
        self.path = path
        self.tap.clear()
        self._run = True
        self.seconds = 0.0
        self.last_error = ""
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return True

    def _loop(self):
        wf = None
        try:
            wf = wave.open(self.path, "wb")
            wf.setnchannels(2)
            wf.setsampwidth(2)
            wf.setframerate(self.sr)
        except Exception as e:
            self.last_error = str(e)
            self._run = False
            return
        try:
            while self._run:
                # piszemy TYLKO realne dane z silnika (zadnych pustych blokow)
                avail = self.tap.available()
                if avail <= 0:
                    time.sleep(0.012)
                    continue
                n = int(min(2048, avail))
                block = self.tap.read(n)
                if block is None or not len(block):
                    time.sleep(0.012)
                    continue
                pcm = (np.clip(block, -1.0, 1.0) * 32767.0).astype("<i2")
                wf.writeframes(pcm.tobytes())
                self.seconds += len(block) / float(self.sr)
        except Exception as e:
            self.last_error = str(e)
        finally:
            try:
                wf.close()
            except Exception:
                pass

    def stop(self):
        self._run = False
        try:
            if self._thread is not None:
                self._thread.join(timeout=2.0)
        except Exception:
            pass
        self._thread = None
        return self.path


# ============================================================== BEAT / SYNC
def beat_times(data, sr, max_beats=64):
    """
    Prosty detektor uderzen (bez AI/online): obwiednia energii + piki.
    Uzywany do ciecia zdjec w rytm muzyki. Zwraca liste czasow [s].
    """
    try:
        if data is None or not len(data):
            return []
        mono = data.mean(axis=1) if data.ndim > 1 else data
        hop = max(1, int(sr * 0.02))              # okno 20 ms
        n = len(mono) // hop
        if n < 8:
            return []
        env = np.abs(mono[:n * hop]).reshape(n, hop).mean(axis=1)
        env = env - env.mean()
        # wygladzenie
        k = np.ones(5, dtype=np.float32) / 5.0
        env = np.convolve(env, k, mode="same")
        thr = env.std() * 1.1
        times, last = [], -1e9
        for i in range(1, n - 1):
            if env[i] > thr and env[i] >= env[i - 1] and env[i] > env[i + 1]:
                t = i * hop / float(sr)
                if t - last > 0.28:               # min. odstep 280 ms
                    times.append(t)
                    last = t
                if len(times) >= max_beats:
                    break
        return times
    except Exception:
        return []


def fmt_time(seconds):
    try:
        s = max(0, int(round(float(seconds))))
        return "%d:%02d" % (s // 60, s % 60)
    except Exception:
        return "0:00"


if __name__ == "__main__":   # szybki test modulu
    tl = AudioTimeline()
    print("Modul audio_timeline OK. soundfile:", HAS_SF, "| miniaudio:", HAS_MINIAUDIO)
    print("Formaty:", " ".join(AUDIO_EXTS))
