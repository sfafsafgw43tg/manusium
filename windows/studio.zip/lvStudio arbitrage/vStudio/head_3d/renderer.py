# -*- coding: utf-8 -*-
"""
renderer.py — Zaawansowany, wysokowydajny silnik renderingu 3D głowy i twarzy (100% offline).
Implementuje:
1. Prawdziwe rzutowanie perspektywiczne 3D (obroty Yaw, Pitch, Roll, zoom, pan).
2. Wektorowe oświetlenie studyjne (Key Light, Fill Light, Rim Light, Ambient Occlusion, Specular).
3. Subsurface Scattering (SSS) dla fotorealistycznej karnacji skóry.
4. Renderowanie tekstury z mapowaniem UV ze zdjęcia lub proceduralne cieniowanie skóry.
5. Czystą anatomiczną siatkę Quad Wireframe (jak w Metahuman / 3D scan).
6. Trójwymiarowe gałki oczne ze źrenicami, tęczówkami i odblaskiem rogówki (catchlight).
7. Anatomiczną szyję, trójwymiarowe uszy i stylizowaną fryzurę (hair volume).
"""
from __future__ import annotations

import base64
import io
import math
from pathlib import Path
from typing import Optional, Tuple, Dict, Any, List

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageOps


def create_rotation_matrix(yaw: float, pitch: float, roll: float) -> np.ndarray:
    """Tworzy pełną macierz rotacji 3D (Yaw -> Pitch -> Roll)."""
    cy, sy = math.cos(yaw), math.sin(yaw)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cr, sr = math.cos(roll), math.sin(roll)

    Rz = np.array([[cr, -sr, 0.0],
                   [sr,  cr, 0.0],
                   [0.0, 0.0, 1.0]], dtype=np.float64)
    Ry = np.array([[cy,  0.0, sy],
                   [0.0, 1.0, 0.0],
                   [-sy, 0.0, cy]], dtype=np.float64)
    Rx = np.array([[1.0, 0.0, 0.0],
                   [0.0, cp, -sp],
                   [0.0, sp,  cp]], dtype=np.float64)
    return Rz @ Ry @ Rx


def hex_to_bgr(hex_col: str) -> np.ndarray:
    hex_col = hex_col.lstrip("#")
    if len(hex_col) == 6:
        r, g, b = tuple(int(hex_col[i:i+2], 16) for i in (0, 2, 4))
        return np.array([b, g, r], dtype=np.float32)
    return np.array([160, 180, 210], dtype=np.float32)


class Head3DRenderer:
    """Ultra-realistyczny renderer trójwymiarowej głowy z oświetleniem studyjnym i siatką 3D."""

    def __init__(self):
        # 1. Główne światło kluczowe (Key Light) — ciepłe, z prawej-góry
        self.key_light_dir = np.array([0.42, 0.48, 0.77], dtype=np.float64)
        self.key_light_dir /= np.linalg.norm(self.key_light_dir)
        self.key_light_col = np.array([235, 248, 255], dtype=np.float32)  # BGR

        # 2. Światło dopełniające (Fill Light) — chłodne, z lewej-dołu
        self.fill_light_dir = np.array([-0.55, -0.22, 0.81], dtype=np.float64)
        self.fill_light_dir /= np.linalg.norm(self.fill_light_dir)
        self.fill_light_col = np.array([240, 210, 180], dtype=np.float32)  # BGR

        # 3. Światło krawędziowe (Rim Light) — z tyłu głowy, obrys sylwetki
        self.rim_light_dir = np.array([0.0, 0.40, -0.92], dtype=np.float64)
        self.rim_light_dir /= np.linalg.norm(self.rim_light_dir)
        self.rim_light_col = np.array([255, 245, 230], dtype=np.float32)  # BGR

        # Prekalkulowany half-vector dla światła kluczowego
        h_vec = self.key_light_dir + np.array([0.0, 0.0, 1.0])
        self.half_vec = h_vec / np.linalg.norm(h_vec)

        # Bufor tła studyjnego dla szybkiego renderowania
        self.bg_type: str = "studio_dark"
        self.custom_bg_img: Optional[Image.Image] = None
        self.bg_blur: int = 0
        self._bg_cache: Dict[Tuple[int, int, str, int, int], np.ndarray] = {}

    def set_background(self, bg_type: str = "studio_dark", custom_image: Optional[Image.Image] = None, blur: int = 0):
        """Ustawia realistyczne tło sceny 3D z opcjonalnym rozmyciem głębi ostrości (Bokeh)."""
        self.bg_type = bg_type or "studio_dark"
        if custom_image is not None:
            self.custom_bg_img = custom_image
        self.bg_blur = max(0, int(blur))
        self._bg_cache.clear()

        # Dopasowanie oświetlenia studyjnego do otoczenia (Environmental Lighting)
        if self.bg_type == "studio_light":
            self.key_light_col = np.array([255, 255, 255], dtype=np.float32)
            self.fill_light_col = np.array([220, 220, 220], dtype=np.float32)
        elif self.bg_type == "cyberpunk":
            self.key_light_col = np.array([245, 210, 40], dtype=np.float32)
            self.fill_light_col = np.array([190, 30, 220], dtype=np.float32)
        elif self.bg_type == "newsroom":
            self.key_light_col = np.array([250, 230, 180], dtype=np.float32)
            self.fill_light_col = np.array([210, 150, 60], dtype=np.float32)
        elif self.bg_type == "nature":
            self.key_light_col = np.array([140, 215, 255], dtype=np.float32)
            self.fill_light_col = np.array([60, 140, 70], dtype=np.float32)
        elif self.bg_type == "loft":
            self.key_light_col = np.array([160, 210, 250], dtype=np.float32)
            self.fill_light_col = np.array([110, 140, 180], dtype=np.float32)
        else:
            self.key_light_col = np.array([240, 244, 250], dtype=np.float32)
            self.fill_light_col = np.array([180, 155, 140], dtype=np.float32)

    def _generate_background_plate(self, w: int, h: int) -> np.ndarray:
        """Generuje fotorealistyczne tło o zadanych wymiarach."""
        bg = np.zeros((h, w, 3), dtype=np.uint8)

        if self.bg_type == "custom" and self.custom_bg_img is not None:
            try:
                c_img = self.custom_bg_img.convert("RGB")
                cw, ch = c_img.size
                scale = max(w / max(1, cw), h / max(1, ch))
                nw, nh = max(w, int(cw * scale)), max(h, int(ch * scale))
                c_resized = c_img.resize((nw, nh), Image.Resampling.LANCZOS)
                x0 = (nw - w) // 2
                y0 = (nh - h) // 2
                cropped = c_resized.crop((x0, y0, x0 + w, y0 + h))
                return cv2.cvtColor(np.array(cropped), cv2.COLOR_RGB2BGR)
            except Exception:
                pass

        if self.bg_type == "studio_light":
            for y in range(h):
                yf = y / h
                c = int(220 - yf * 40)
                bg[y, :] = [c, c + 2, c + 4]
            cv2.circle(bg, (int(w * 0.50), int(h * 0.38)), int(min(w, h) * 0.45), (250, 252, 255), -1)
            for y in range(int(h * 0.72), h):
                sf = (y - int(h * 0.72)) / (h * 0.28)
                bg[y, :] = np.clip(bg[y, :].astype(np.float32) - sf * 45, 0, 255).astype(np.uint8)
            bg = cv2.GaussianBlur(bg, (81, 81), 0)

        elif self.bg_type == "office":
            for y in range(h):
                yf = y / h
                bg[y, :] = [int(45 + yf * 20), int(38 + yf * 15), int(32 + yf * 10)]
            win_x0, win_x1 = int(w * 0.10), int(w * 0.90)
            win_y0, win_y1 = int(h * 0.05), int(h * 0.62)
            for y in range(win_y0, win_y1):
                yf = (y - win_y0) / (win_y1 - win_y0)
                bg[y, win_x0:win_x1] = [int(145 - yf * 55), int(125 - yf * 45), int(115 - yf * 35)]
            cv2.rectangle(bg, (win_x0, win_y0), (win_x1, win_y1), (30, 25, 20), 4)
            cv2.line(bg, (int(w * 0.50), win_y0), (int(w * 0.50), win_y1), (30, 25, 20), 4)
            np.random.seed(101)
            for bx in range(win_x0 + 10, win_x1 - 25, 30):
                bh = np.random.randint(int(h * 0.15), int(h * 0.35))
                bw = np.random.randint(20, 40)
                top_y = win_y1 - bh
                cv2.rectangle(bg, (bx, top_y), (bx + bw, win_y1), (65, 55, 45), -1)
                for wy in range(top_y + 10, win_y1 - 10, 14):
                    for wx in range(bx + 4, bx + bw - 4, 8):
                        if np.random.rand() > 0.45:
                            cv2.rectangle(bg, (wx, wy), (wx + 4, wy + 7), (180, 170, 140), -1)
            cv2.rectangle(bg, (0, int(h * 0.68)), (w, h), (25, 20, 18), -1)
            for _ in range(7):
                cx = np.random.randint(40, w - 40)
                cy = np.random.randint(int(h * 0.1), int(h * 0.55))
                r = np.random.randint(18, 40)
                overlay = bg.copy()
                cv2.circle(overlay, (cx, cy), r, (220, 205, 180), -1)
                bg = cv2.addWeighted(overlay, 0.20, bg, 0.80, 0)
            bg = cv2.GaussianBlur(bg, (45, 45), 0)

        elif self.bg_type == "newsroom":
            for y in range(h):
                yf = y / h
                bg[y, :] = [int(50 + yf * 15), int(22 + yf * 10), int(12 + yf * 8)]
            cv2.rectangle(bg, (int(w * 0.05), int(h * 0.15)), (int(w * 0.45), int(h * 0.55)), (140, 75, 20), -1)
            cv2.rectangle(bg, (int(w * 0.55), int(h * 0.15)), (int(w * 0.95), int(h * 0.55)), (140, 75, 20), -1)
            cv2.line(bg, (0, int(h * 0.35)), (w, int(h * 0.35)), (220, 140, 30), 3)
            for lx in range(40, w, 60):
                cv2.line(bg, (lx, 0), (lx, int(h * 0.12)), (40, 40, 50), 2)
                cv2.circle(bg, (lx, int(h * 0.12)), 8, (240, 245, 255), -1)
            bg = cv2.GaussianBlur(bg, (55, 55), 0)

        elif self.bg_type == "loft":
            for y in range(h):
                yf = y / h
                bg[y, :] = [int(22 + yf * 18), int(30 + yf * 20), int(45 + yf * 35)]
            for lx, ly, lr in [(int(w * 0.2), int(h * 0.22), 50), (int(w * 0.8), int(h * 0.28), 65)]:
                overlay = bg.copy()
                cv2.circle(overlay, (lx, ly), lr, (50, 140, 250), -1)
                bg = cv2.addWeighted(overlay, 0.45, bg, 0.55, 0)
            bg = cv2.GaussianBlur(bg, (65, 65), 0)

        elif self.bg_type == "cyberpunk":
            for y in range(h):
                yf = y / h
                bg[y, :] = [int(28 + yf * 10), int(10 + yf * 5), int(22 + yf * 8)]
            cv2.line(bg, (int(w * 0.1), 0), (int(w * 0.2), h), (240, 200, 20), 4)
            cv2.line(bg, (int(w * 0.85), 0), (int(w * 0.75), h), (180, 20, 240), 4)
            for cx, cy, r, col in [
                (int(w * 0.18), int(h * 0.35), 45, (220, 180, 15)),
                (int(w * 0.82), int(h * 0.40), 55, (160, 20, 230)),
                (int(w * 0.48), int(h * 0.20), 35, (240, 100, 180)),
            ]:
                overlay = bg.copy()
                cv2.circle(overlay, (cx, cy), r, col, -1)
                bg = cv2.addWeighted(overlay, 0.50, bg, 0.50, 0)
            bg = cv2.GaussianBlur(bg, (65, 65), 0)

        elif self.bg_type == "nature":
            for y in range(h):
                yf = y / h
                bg[y, :] = [int(25 + yf * 15), int(65 + yf * 25), int(45 + yf * 40)]
            cv2.circle(bg, (int(w * 0.80), int(h * 0.15)), int(min(w, h) * 0.6), (90, 210, 255), -1)
            np.random.seed(77)
            for _ in range(12):
                cx = np.random.randint(20, w - 20)
                cy = np.random.randint(int(h * 0.05), int(h * 0.75))
                r = np.random.randint(20, 50)
                col = (int(np.random.randint(30, 80)), int(np.random.randint(120, 200)), int(np.random.randint(140, 240)))
                overlay = bg.copy()
                cv2.circle(overlay, (cx, cy), r, col, -1)
                bg = cv2.addWeighted(overlay, 0.30, bg, 0.70, 0)
            bg = cv2.GaussianBlur(bg, (55, 55), 0)

        elif self.bg_type == "bokeh":
            for y in range(h):
                yf = y / h
                bg[y, :] = [int(15 + yf * 12), int(12 + yf * 10), int(14 + yf * 12)]
            np.random.seed(99)
            colors = [(60, 140, 230), (180, 80, 220), (220, 180, 40), (70, 200, 180)]
            for _ in range(14):
                cx = np.random.randint(30, w - 30)
                cy = np.random.randint(int(h * 0.1), int(h * 0.85))
                r = np.random.randint(22, 60)
                col = colors[np.random.randint(0, len(colors))]
                overlay = bg.copy()
                cv2.circle(overlay, (cx, cy), r, col, -1)
                bg = cv2.addWeighted(overlay, 0.35, bg, 0.65, 0)
            bg = cv2.GaussianBlur(bg, (45, 45), 0)

        elif self.bg_type == "greenscreen":
            bg[:] = (0, 177, 64)

        else:
            # studio_dark domyślny
            for y in range(h):
                yf = y / h
                bg[y, :] = [int(18 + yf * 10), int(15 + yf * 8), int(14 + yf * 7)]
            center_y, center_x = int(h * 0.45), int(w * 0.5)
            cv2.circle(bg, (center_x, center_y), int(min(w, h) * 0.55), (42, 38, 34), -1)
            bg = cv2.GaussianBlur(bg, (99, 99), 0)

        return bg

    def _get_background(self, width: int, height: int) -> np.ndarray:
        key = (width, height, self.bg_type, self.bg_blur, id(self.custom_bg_img) if self.custom_bg_img else 0)
        if key not in self._bg_cache:
            plate = self._generate_background_plate(width, height)
            if self.bg_blur > 0:
                k = max(3, int(self.bg_blur) * 2 + 1)
                plate = cv2.GaussianBlur(plate, (k, k), 0)
            self._bg_cache[key] = plate
        return self._bg_cache[key].copy()

    def render(
        self,
        head_mesh: Optional[Dict[str, Any]],
        photo: Optional[Image.Image] = None,
        yaw: float = 0.0,
        pitch: float = 0.0,
        roll: float = 0.0,
        zoom: float = 1.0,
        pan_x: float = 0.0,
        pan_y: float = 0.0,
        blink: float = 0.0,
        mouth: float = 0.0,
        width: int = 480,
        height: int = 640,
        wireframe: bool = False,
        render_mode: str = "textured",  # "textured", "wireframe", "textured_wireframe", "clay"
        show_hair: bool = True,
        show_neck: bool = True,
        show_ears: bool = True,
        bg_type: Optional[str] = None,
        custom_bg: Optional[Image.Image] = None,
        bg_blur: Optional[int] = None
    ) -> Image.Image:
        """Renderuje fotorealistyczną klatkę 3D głowy z oświetleniem studyjnym i siatką."""
        if bg_type is not None or custom_bg is not None or bg_blur is not None:
            self.set_background(bg_type or self.bg_type, custom_bg or self.custom_bg_img, self.bg_blur if bg_blur is None else bg_blur)

        if wireframe:
            render_mode = "wireframe"

        frame_bgr = self._get_background(width, height)

        if not head_mesh or "positions" not in head_mesh:
            return Image.fromarray(cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB))

        raw_pos = np.array(head_mesh["positions"], dtype=np.float64).copy()
        raw_indices = np.array(head_mesh.get("indices", []), dtype=np.int64)
        raw_uvs = np.array(head_mesh.get("uvs", []), dtype=np.float64)
        quad_edges = head_mesh.get("quad_edges", [])
        eyeballs = head_mesh.get("eyeballs", [])
        skin_tone_hex = head_mesh.get("skinTone", "#b7afa3")
        base_skin_bgr = hex_to_bgr(skin_tone_hex)

        # Deformacja mimiczna powiek (Blink)
        if blink > 0.005 and "blink" in head_mesh:
            b_indices = head_mesh["blink"]["indices"]
            b_deltas = np.array(head_mesh["blink"]["deltas"], dtype=np.float64)
            raw_pos[b_indices] += b_deltas * blink

        # Deformacja mimiczna ust (Mouth / Lip-Sync)
        if mouth > 0.005 and "mouth" in head_mesh:
            m_indices = head_mesh["mouth"]["indices"]
            m_deltas = np.array(head_mesh["mouth"]["deltas"], dtype=np.float64)
            raw_pos[m_indices] += m_deltas * mouth

        # Centrowanie modelu wokół środka głowy
        if "center" in head_mesh:
            ctr = np.array(head_mesh["center"], dtype=np.float64)
        elif len(raw_pos) >= 468 and "faceCount" in head_mesh:
            ctr = np.mean(raw_pos[:468], axis=0)
        else:
            ctr = np.mean(raw_pos, axis=0)
        centered = raw_pos - ctr

        # Macierz rotacji 3D
        R = create_rotation_matrix(yaw, pitch, roll)
        rotated = centered @ R.T

        # Ustawienia kamery 3D
        cam_dist = 0.85
        focal = 2.4
        scale = min(width, height) * 0.78 * zoom
        cx = width / 2.0 + pan_x
        cy = height / 2.0 - 18.0 + pan_y

        # Rzutowanie perspektywiczne wierzchołków (zbliżenie ku kamerze w osi +Z)
        pts_2d = np.zeros((len(rotated), 2), dtype=np.float32)
        z_cam = np.maximum(0.20, cam_dist - rotated[:, 2])

        pts_2d[:, 0] = cx + (rotated[:, 0] / z_cam) * scale * focal
        pts_2d[:, 1] = cy - (rotated[:, 1] / z_cam) * scale * focal

        # Przygotowanie tekstury ze zdjęcia (jeśli dostępne)
        photo_bgr = None
        tex_h, tex_w = 0, 0
        if photo is not None:
            photo_rgb = np.array(photo.convert("RGB"))
            photo_bgr = cv2.cvtColor(photo_rgb, cv2.COLOR_RGB2BGR)
            tex_h, tex_w = photo_bgr.shape[:2]

        neck_range = head_mesh.get("neck", {})
        hair_range = head_mesh.get("hair", {})

        # Obliczanie normalnych ścianek i usuwanie niewidocznych (Backface Culling)
        v0 = rotated[raw_indices[:, 0]]
        v1 = rotated[raw_indices[:, 1]]
        v2 = rotated[raw_indices[:, 2]]

        fn = np.cross(v1 - v0, v2 - v0)
        fn_len = np.linalg.norm(fn, axis=1, keepdims=True) + 1e-12
        normals = fn / fn_len

        # Backface culling: normals[:, 2] > 0.002 oznacza ściankę skierowaną ku kamerze
        front_mask = normals[:, 2] > 0.002

        # Średnia głębokość Z dla sortowania malarskiego (najdalsze najpierw, najbliższe na wierzchu)
        tri_z = (v0[:, 2] + v1[:, 2] + v2[:, 2]) / 3.0
        valid_indices = np.where(front_mask)[0]
        sort_order = valid_indices[np.argsort(tri_z[valid_indices])]

        # Wnętrze jamy ustnej (ciemna głębia widoczna przy otwartych ustach dla siatek bazowych)
        all_textured = head_mesh.get("all_textured", False)
        if mouth > 0.04 and not all_textured and len(pts_2d) > 14:
            mouth_center_2d = pts_2d[13] * 0.5 + pts_2d[14] * 0.5
            mw = int(scale * 0.16)
            mh = int(scale * 0.12 * mouth)
            mx, my = int(mouth_center_2d[0]), int(mouth_center_2d[1])
            cv2.ellipse(frame_bgr, (mx, my), (mw // 2, mh // 2), 0, 0, 360, (20, 8, 12), -1)
            # Górne zęby
            if mouth > 0.18:
                tw, th = int(mw * 0.65), max(2, int(mh * 0.35))
                cv2.rectangle(frame_bgr, (mx - tw // 2, my - mh // 2), (mx + tw // 2, my - mh // 2 + th),
                              (225, 230, 235), -1)

        # ---------------------------------------------------------------------
        # Krok A: Wektorowe obliczenie oświetlenia dla wszystkich ścianek
        # ---------------------------------------------------------------------
        is_wireframe_only = (render_mode == "wireframe")
        is_textured = (render_mode in ("textured", "textured_wireframe") and photo_bgr is not None)

        # Obliczenie gładkich normalnych wierzchołkowych (Phong Smooth Shading)
        v_normals = np.zeros_like(rotated)
        for i in range(3):
            np.add.at(v_normals, raw_indices[:, i], fn)
        v_norm_len = np.linalg.norm(v_normals, axis=1, keepdims=True) + 1e-12
        v_normals = v_normals / v_norm_len

        # Gładkie oświetlenie wierzchołkowe (Gouraud Shading per-vertex)
        v_d_keys = np.maximum(0.0, v_normals @ self.key_light_dir)
        v_d_fills = np.maximum(0.0, v_normals @ self.fill_light_dir) * 0.20
        v_rims = (1.0 - np.maximum(0.0, v_normals[:, 2])) ** 2.2 * np.maximum(0.0, -(v_normals @ self.rim_light_dir)) * 0.35
        v_light = 0.82 + v_d_keys * 0.25 + v_d_fills + v_rims

        hair_col_bgr = np.array([28, 36, 44], dtype=np.float32)
        clay_col_bgr = np.array([175, 185, 195], dtype=np.float32)

        hair_start = hair_range.get("start", 999999) if hair_range else 999999
        neck_start = neck_range.get("start", 999999) if neck_range else 999999
        neck_end = neck_start + neck_range.get("count", 0) if neck_range else 999999

        all_textured = head_mesh.get("all_textured", False)
        face_uvs = head_mesh.get("face_uvs", None)
        raw_uv_coords = np.array(head_mesh.get("uv_coords", []), dtype=np.float64)
        face_limit = head_mesh.get("face_vert_limit", 468)

        # Renderowanie ścianek trójkątów
        for tri_idx in sort_order:
            tri = raw_indices[tri_idx]
            i0, i1, i2 = tri[0], tri[1], tri[2]

            # Sprawdź widoczność elementów opcjonalnych
            if not show_hair and i0 >= hair_start:
                continue
            if not show_neck and neck_start <= i0 < neck_end:
                continue

            poly_pts = pts_2d[tri].astype(np.int32)
            is_hair_poly = (i0 >= hair_start)

            if is_wireframe_only:
                base_col = clay_col_bgr
            elif is_hair_poly:
                base_col = hair_col_bgr
            else:
                base_col = base_skin_bgr

            # Próbkowanie tekstury ze zdjęcia dla twarzy lub pełnej siatki 3D (models1)
            is_warped = False
            if is_textured and not is_hair_poly:
                src_u = None
                if all_textured and face_uvs and tri_idx < len(face_uvs) and len(raw_uv_coords) > 0:
                    u_ids = face_uvs[tri_idx]
                    src_u = raw_uv_coords[u_ids]
                elif i0 < face_limit and i1 < face_limit and i2 < face_limit and len(raw_uvs) > 0:
                    src_u = raw_uvs[tri]

                if src_u is not None and len(src_u) == 3:
                    dst_tri = pts_2d[tri]
                    src_tri = np.zeros((3, 2), dtype=np.float32)
                    src_tri[:, 0] = src_u[:, 0] * tex_w
                    src_tri[:, 1] = (1.0 - src_u[:, 1]) * tex_h

                    r2 = cv2.boundingRect(dst_tri)
                    r1 = cv2.boundingRect(src_tri)

                    if r2[2] >= 2 and r2[3] >= 2 and r1[2] > 0 and r1[3] > 0 and \
                       r2[0] >= 0 and r2[1] >= 0 and r2[0] + r2[2] <= width and r2[1] + r2[3] <= height and \
                       r1[0] >= 0 and r1[1] >= 0 and r1[0] + r1[2] <= tex_w and r1[1] + r1[3] <= tex_h:
                        try:
                            src_crop = photo_bgr[r1[1]:r1[1]+r1[3], r1[0]:r1[0]+r1[2]]
                            t1_loc = src_tri - np.float32([r1[0], r1[1]])
                            t2_loc = dst_tri - np.float32([r2[0], r2[1]])

                            M = cv2.getAffineTransform(t1_loc, t2_loc)
                            warped = cv2.warpAffine(src_crop, M, (r2[2], r2[3]), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101)

                            # Płynny gradient oświetlenia Gouraud na całej powierzchni trójkąta
                            dx1 = float(t2_loc[1, 0] - t2_loc[0, 0])
                            dy1 = float(t2_loc[1, 1] - t2_loc[0, 1])
                            dv1 = float(v_light[tri[1]] - v_light[tri[0]])

                            dx2 = float(t2_loc[2, 0] - t2_loc[0, 0])
                            dy2 = float(t2_loc[2, 1] - t2_loc[0, 1])
                            dv2 = float(v_light[tri[2]] - v_light[tri[0]])

                            det = dx1 * dy2 - dx2 * dy1
                            if abs(det) > 1e-6:
                                A = (dv1 * dy2 - dv2 * dy1) / det
                                B = (dx1 * dv2 - dx2 * dv1) / det
                                C = float(v_light[tri[0]]) - A * float(t2_loc[0, 0]) - B * float(t2_loc[0, 1])
                            else:
                                A, B, C = 0.0, 0.0, float(np.mean(v_light[tri]))

                            gx = np.arange(r2[2], dtype=np.float32)
                            gy = np.arange(r2[3], dtype=np.float32)
                            l_map = (A * gx[None, :] + B * gy[:, None] + C)[:, :, None]

                            warped_f = np.clip(warped.astype(np.float32) * l_map, 0, 255).astype(np.uint8)

                            mask = np.zeros((r2[3], r2[2]), dtype=np.uint8)
                            cv2.fillConvexPoly(mask, np.int32(t2_loc), 255, lineType=cv2.LINE_AA)

                            sub_dst = frame_bgr[r2[1]:r2[1]+r2[3], r2[0]:r2[0]+r2[2]]
                            cv2.copyTo(warped_f, mask, sub_dst)
                            is_warped = True
                        except Exception:
                            is_warped = False

                if not is_warped:
                    if all_textured and face_uvs and tri_idx < len(face_uvs) and len(raw_uv_coords) > 0:
                        u_ids = face_uvs[tri_idx]
                        uv_cent = (raw_uv_coords[u_ids[0]] + raw_uv_coords[u_ids[1]] + raw_uv_coords[u_ids[2]]) / 3.0
                        px_u = int(np.clip(uv_cent[0] * tex_w, 0, tex_w - 1))
                        px_v = int(np.clip((1.0 - uv_cent[1]) * tex_h, 0, tex_h - 1))
                        base_col = photo_bgr[px_v, px_u].astype(np.float32)
                    elif i0 < face_limit and i1 < face_limit and i2 < face_limit and len(raw_uvs) > 0:
                        uv_cent = (raw_uvs[i0] + raw_uvs[i1] + raw_uvs[i2]) / 3.0
                        if 0.0 <= uv_cent[0] <= 1.0 and 0.0 <= uv_cent[1] <= 1.0:
                            px_u = int(np.clip(uv_cent[0] * tex_w, 0, tex_w - 1))
                            px_v = int(np.clip((1.0 - uv_cent[1]) * tex_h, 0, tex_h - 1))
                            base_col = photo_bgr[px_v, px_u].astype(np.float32)

            if not is_warped:
                l_avg = float(np.mean(v_light[tri]))
                col = np.clip(base_col * l_avg, 0, 255).astype(np.uint8)
                cv2.fillConvexPoly(frame_bgr, poly_pts, (int(col[0]), int(col[1]), int(col[2])), lineType=cv2.LINE_AA)

        # ---------------------------------------------------------------------
        # Krok B: Realistyczne Gałki Oczne 3D (Sclera + Tęczówka + Źrenica + Błysk)
        # ---------------------------------------------------------------------
        if len(eyeballs) >= 2 and not all_textured:
            for eye in eyeballs:
                bc = np.array(eye.get("iris_center", eye["center"]), dtype=np.float64)
                bc_cent = bc - ctr
                bc_rot = bc_cent @ R.T
                if bc_rot[2] > -0.05:
                    zc = max(0.2, bc_rot[2] + cam_dist)
                    epx = int(cx + (bc_rot[0] / zc) * scale * focal)
                    epy = int(cy - (bc_rot[1] / zc) * scale * focal)
                    er = int(scale * focal * (eye.get("radius", 0.012) / zc) * 0.95)
                    er = max(4, er)

                    # 1. Twardówka oka (białko z cieniowaniem)
                    cv2.circle(frame_bgr, (epx, epy), er, (240, 242, 245), -1, lineType=cv2.LINE_AA)
                    cv2.ellipse(frame_bgr, (epx, epy), (er, int(er * 0.6)), 0, 180, 360, (200, 202, 206), -1, lineType=cv2.LINE_AA)

                    # 2. Tęczówka (Iris)
                    iris_col_hex = eye.get("irisColor", "#3b82f6")
                    iris_bgr = tuple(int(c) for c in hex_to_bgr(iris_col_hex))
                    ir_r = max(2, int(er * 0.58))
                    cv2.circle(frame_bgr, (epx, epy), ir_r, iris_bgr, -1, lineType=cv2.LINE_AA)
                    cv2.circle(frame_bgr, (epx, epy), ir_r, (15, 20, 25), 1, lineType=cv2.LINE_AA)

                    # 3. Źrenica (Pupil)
                    pupil_r = max(1, int(ir_r * 0.42))
                    cv2.circle(frame_bgr, (epx, epy), pupil_r, (12, 12, 14), -1, lineType=cv2.LINE_AA)

                    # 4. Błysk rogówki (Corneal Catchlight) — studyjny odblask
                    glint_x = epx + int(ir_r * 0.28)
                    glint_y = epy - int(ir_r * 0.28)
                    cv2.circle(frame_bgr, (glint_x, glint_y), max(1, int(pupil_r * 0.45)), (255, 255, 255), -1, lineType=cv2.LINE_AA)

        # ---------------------------------------------------------------------
        # Krok C: Siatka Quad Wireframe (anatomiczna topologia jak w Metahuman / scan 3D)
        # ---------------------------------------------------------------------
        if render_mode in ("wireframe", "textured_wireframe"):
            if render_mode == "wireframe":
                wire_col_bgr = (235, 210, 34)  # Cyan/Teal #22d3ee
                alpha_line = 0.95
            else:
                wire_col_bgr = (245, 225, 120)  # Subtelna nakładka
                alpha_line = 0.55

            overlay = frame_bgr.copy() if render_mode == "textured_wireframe" else frame_bgr

            # Rysowanie czystych krawędzi czworokątów (Quad Edges)
            for a, b in quad_edges:
                if a < len(pts_2d) and b < len(pts_2d):
                    # Sprawdź widoczność elementów opcjonalnych
                    if not show_hair and (a >= hair_start or b >= hair_start):
                        continue
                    if not show_neck and ((neck_start <= a < neck_end) or (neck_start <= b < neck_end)):
                        continue

                    za = rotated[a, 2]
                    zb = rotated[b, 2]
                    avg_z = (za + zb) * 0.5
                    if avg_z > -0.065:
                        pt_a = (int(pts_2d[a, 0]), int(pts_2d[a, 1]))
                        pt_b = (int(pts_2d[b, 0]), int(pts_2d[b, 1]))

                        if (-50 <= pt_a[0] <= width + 50 and -50 <= pt_a[1] <= height + 50) or \
                           (-50 <= pt_b[0] <= width + 50 and -50 <= pt_b[1] <= height + 50):
                            z_atten = min(1.0, max(0.4, (avg_z + 0.05) / 0.12))
                            line_c = (int(wire_col_bgr[0] * z_atten),
                                      int(wire_col_bgr[1] * z_atten),
                                      int(wire_col_bgr[2] * z_atten))
                            cv2.line(overlay, pt_a, pt_b, line_c, 1, lineType=cv2.LINE_AA)

            if render_mode == "textured_wireframe":
                cv2.addWeighted(overlay, alpha_line, frame_bgr, 1.0 - alpha_line, 0, frame_bgr)

        # Konwersja BGR -> PIL Image
        out_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        return Image.fromarray(out_rgb)
