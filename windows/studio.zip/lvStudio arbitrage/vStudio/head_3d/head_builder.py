# -*- coding: utf-8 -*-
"""
head_builder.py — Kompletny, anatomiczny generator modeli 3D głowy, twarzy, czaszki, szyi i uszu.
Łączy geometrię MediaPipe 478 punktów (face_model_with_iris.obj), sferyczną czaszkę/cranium (build_scalp),
anatomiczną szyję i obojczyki (build_neck), trójwymiarowe uszy (build_ears), gałki oczne 3D
oraz fryzurę 3D (build_hair) wraz z czystą topologią siatki quad (wireframe).
"""
from __future__ import annotations

import json
from pathlib import Path
from collections import defaultdict
from typing import List, Tuple
import numpy as np

DATA = Path(__file__).resolve().parent.parent / "data"

OUTER_EYE_CORNER_DIST = 0.093   # metry, odległość canthal (33 <-> 263)
CLAY_TONE = "#b7afa3"
EYEBALL_IRIS_RATIO = 0.52

IRIS_CENTERS = [468, 473]
IRIS_RINGS = [[469, 470, 471, 472], [474, 475, 476, 477]]


def _load_obj(path: Path):
    verts, uvs, faces = [], [], []
    for line in path.read_text().splitlines():
        p = line.split()
        if not p:
            continue
        if p[0] == "v":
            verts.append([float(x) for x in p[1:4]])
        elif p[0] == "vt":
            uvs.append([float(x) for x in p[1:3]])
        elif p[0] == "f":
            faces.append([int(q.split("/")[0]) - 1 for q in p[1:4]])
    V = np.asarray(verts, dtype=np.float64)
    UV = np.asarray(uvs, dtype=np.float64) if uvs else None
    return V, UV, np.asarray(faces, dtype=np.int64)


def _conn_verts(conn):
    s = set()
    for a, b in conn:
        s.add(a)
        s.add(b)
    return sorted(s)


def _order_ring(conn):
    adj = {}
    for a, b in conn:
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)
    start = next(iter(adj))
    ring, prev, cur = [start], None, start
    while True:
        nxt = [n for n in adj[cur] if n != prev]
        if not nxt:
            break
        prev, cur = cur, nxt[0]
        if cur == start:
            break
        ring.append(cur)
    return ring


class Topology:
    def __init__(self):
        V, UV, F = _load_obj(DATA / "face_model_with_iris.obj")
        conn = json.loads((DATA / "mesh_topology.json").read_text())["connections"]

        V = V * (OUTER_EYE_CORNER_DIST / np.linalg.norm(V[33] - V[263]))

        self.eye_L = _conn_verts(conn["FACEMESH_LEFT_EYE"])
        self.eye_R = _conn_verts(conn["FACEMESH_RIGHT_EYE"])
        self.brow_L = _conn_verts(conn["FACEMESH_LEFT_EYEBROW"])
        self.brow_R = _conn_verts(conn["FACEMESH_RIGHT_EYEBROW"])
        self.lips = _conn_verts(conn["FACEMESH_LIPS"])
        self.oval = _order_ring(conn["FACEMESH_FACE_OVAL"])
        self.UV = UV

        keep = []
        for f in F:
            drop = False
            for ring_ids in (self.eye_L, self.eye_R):
                ring = V[ring_ids]
                ctr = ring.mean(axis=0)
                rmax = np.linalg.norm(ring - ctr, axis=1).max()
                if all(np.linalg.norm(V[v] - ctr) <= rmax * 1.05 for v in f):
                    drop = True
                    break
            if not drop:
                keep.append(f)
        self.V = V
        self.F = np.asarray(keep, dtype=np.int64)
        self.iris = True


def orient_faces_consistent(V, F, ref):
    from collections import defaultdict, deque
    F = np.asarray(F, dtype=np.int64).copy()
    n = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    c = V[F].mean(axis=1) - ref
    ln = np.linalg.norm(n, axis=1) + 1e-30
    lc = np.linalg.norm(c, axis=1) + 1e-30
    cos = (n * c).sum(axis=1) / (ln * lc)
    seed = int(np.argmax(cos))

    ef = defaultdict(list)
    for i in range(len(F)):
        fl = F[i].tolist()
        for a, b in zip(fl, fl[1:] + fl[:1]):
            ef[tuple(sorted((a, b)))].append(i)

    def directed_edges(fi):
        return [(fi[k], fi[(k + 1) % 3]) for k in range(3)]

    visited = {seed}
    q = deque([seed])
    while q:
        i = q.popleft()
        for a, b in directed_edges(F[i].tolist()):
            for j in ef.get(tuple(sorted((a, b))), ()):
                if j in visited:
                    continue
                visited.add(j)
                q.append(j)
                fj = F[j].tolist()
                if (a, b) in directed_edges(fj):
                    F[j] = [fj[0], fj[2], fj[1]]
    return F


def vertex_normals(V, F):
    N = np.zeros_like(V)
    fn = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    for k in range(3):
        np.add.at(N, F[:, k], fn)
    ln = np.linalg.norm(N, axis=1, keepdims=True)
    return np.divide(N, np.where(ln == 0, 1, ln))


def slerp_batch(a, b, t):
    b = np.broadcast_to(b, a.shape).copy()
    dot = (a * b).sum(axis=1, keepdims=True).clip(-1, 1)
    theta = np.arccos(dot)
    st = np.sin(theta)
    small = st[:, 0] < 1e-8
    wa = np.where(small[:, None], 1 - t, np.sin((1 - t) * theta) / np.where(small[:, None], 1, st))
    wb = np.where(small[:, None], t, np.sin(t * theta) / np.where(small[:, None], 1, st))
    out = wa * a + wb * b
    return out / np.linalg.norm(out, axis=1, keepdims=True)


def _smooth(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)


def build_scalp(V, topo, radii_scale=(1.0, 1.0, 1.0), depth_scale=1.0):
    """Generuje sferyczną czaszkę i tył głowy (cranium) łączący się z obwodem twarzy."""
    rim = topo.oval
    B = V[rim]
    M = len(B)

    ctr = V[:468].mean(axis=0)
    hc = np.array([0.0, ctr[1] + 0.004, ctr[2] - 0.030])

    rim_x = np.abs(B[:, 0]).max()
    radii = np.array([
        rim_x * 1.13,
        (B[:, 1].max() - hc[1]) * 1.06 + 0.010,
        rim_x * 1.78 * depth_scale,
    ]) * np.asarray(radii_scale)

    sd = np.linalg.norm((B - hc) / radii, axis=1).max()
    if sd > 0.96:
        radii *= sd / 0.96

    dirs = (B - hc) / radii
    dirs /= np.linalg.norm(dirs, axis=1, keepdims=True)
    pole_dir = np.array([0.0, -0.06, -1.0])
    pole_dir /= np.linalg.norm(pole_dir)

    E = hc + radii * dirs
    step1 = np.linalg.norm(E - B, axis=1, keepdims=True)
    t1 = np.maximum(0.45, 0.004 / np.maximum(step1, 1e-9))

    ROWS = 12
    grid = np.zeros((ROWS, M, 3))
    grid[0] = B
    grid[1] = B + t1 * (E - B)
    grid[2] = B + 0.85 * (E - B)
    grid[3] = E
    relax = [1.0, 0.995, 0.99, 0.98, 0.97, 0.96, 0.95, 0.94]
    ts = [0.10, 0.22, 0.36, 0.50, 0.63, 0.75, 0.86, 0.95]
    for k, t in enumerate(ts):
        d = slerp_batch(dirs, pole_dir, t)
        grid[4 + k] = hc + radii * d * relax[k]
    pole = hc + radii * pole_dir * 0.93

    sv = np.vstack([grid[1:].reshape(-1, 3), pole[None]])
    off = ROWS - 1
    P = ROWS * M
    faces = []
    quad_edges = []
    for i in range(M):
        i2 = (i + 1) % M
        for r in range(off - 1):
            a, b, c, d = (r * M + i, r * M + i2, (r + 1) * M + i2, (r + 1) * M + i)
            faces.append([a, b, c])
            faces.append([a, c, d])
            quad_edges.append((a, b))
            quad_edges.append((a, d))
        faces.append([(off - 1) * M + i, (off - 1) * M + i2, P])
        quad_edges.append(((off - 1) * M + i, (off - 1) * M + i2))
    sf = np.asarray(faces, dtype=np.int64)
    return sv, sf, hc, radii, quad_edges


def build_neck(top_y: float = -0.088, bottom_y: float = -0.235, num_rings: int = 8, num_sectors: int = 24):
    """Generuje anatomiczną szyję i obojczyki łączące głowę z tułowiem."""
    verts = []
    faces = []
    quad_edges = []
    uvs = []

    for r in range(num_rings):
        t = r / float(num_rings - 1)
        y = top_y + t * (bottom_y - top_y)
        rx = 0.052 + (t ** 1.8) * 0.068
        rz = 0.058 + (t ** 1.2) * 0.038
        cz = -0.025 - t * 0.015

        for s in range(num_sectors):
            th = s * (2.0 * np.pi / num_sectors)
            larynx = 0.007 * np.exp(-((t - 0.32) / 0.12) ** 2) * max(0.0, np.cos(th)) ** 2
            trap_y = -0.020 * (t ** 2) * abs(np.sin(th))

            vx = rx * np.sin(th)
            vy = y + trap_y
            vz = cz + rz * np.cos(th) + larynx
            verts.append([vx, vy, vz])
            uvs.append([s / float(num_sectors), 0.15 + t * 0.70])

    for r in range(num_rings - 1):
        for s in range(num_sectors):
            s2 = (s + 1) % num_sectors
            v0 = r * num_sectors + s
            v1 = r * num_sectors + s2
            v2 = (r + 1) * num_sectors + s2
            v3 = (r + 1) * num_sectors + s
            faces.append([v0, v1, v2])
            faces.append([v0, v2, v3])
            quad_edges.append((v0, v1))
            quad_edges.append((v0, v3))

    return np.array(verts, dtype=np.float64), np.array(faces, dtype=np.int64), quad_edges, np.array(uvs, dtype=np.float64)


def build_ear(side: str = "left", num_rings: int = 4, num_sectors: int = 12):
    """Generuje realistyczne trójwymiarowe ucho (helix, concha, antihelix, lobule)."""
    sign = -1.0 if side == "left" else 1.0
    cx = sign * 0.076
    cy = -0.016
    cz = -0.024

    verts = []
    faces = []
    quad_edges = []
    uvs = []

    thetas = np.linspace(-np.pi * 0.40, np.pi * 1.35, num_sectors)

    for r in range(num_rings):
        t_r = (r + 1) / float(num_rings)
        ry = 0.027 * t_r
        rz = 0.016 * t_r
        for s, th in enumerate(thetas):
            flare = 0.004 + 0.016 * (t_r ** 1.3) * (0.4 + 0.6 * np.cos(th))
            vx = cx + sign * flare
            vy = cy + ry * np.sin(th)
            vz = cz + rz * np.cos(th)
            verts.append([vx, vy, vz])
            uvs.append([0.5 + 0.4 * np.cos(th) * t_r, 0.5 + 0.4 * np.sin(th) * t_r])

    for r in range(num_rings - 1):
        for s in range(num_sectors - 1):
            v0 = r * num_sectors + s
            v1 = r * num_sectors + (s + 1)
            v2 = (r + 1) * num_sectors + (s + 1)
            v3 = (r + 1) * num_sectors + s
            faces.append([v0, v1, v2])
            faces.append([v0, v2, v3])
            quad_edges.append((v0, v1))
            quad_edges.append((v0, v3))

    return np.array(verts, dtype=np.float64), np.array(faces, dtype=np.int64), quad_edges, np.array(uvs, dtype=np.float64)


def build_hair_volume(sv: np.ndarray, sf: np.ndarray, hc: np.ndarray, radii: np.ndarray, gender: str = "female"):
    """Generuje trójwymiarową warstwę fryzury z koczkiem/objętością z tyłu głowy."""
    dirs = sv - hc
    dist = np.linalg.norm(dirs, axis=1, keepdims=True) + 1e-9
    dirs /= dist

    thickness = 0.008 if gender == "female" else 0.006
    top_boost = np.clip((sv[:, 1] - hc[1]) / 0.06, 0, 1)[:, None] * 0.005

    hair_v = sv + dirs * (thickness + top_boost)

    # Stylizowany koczek/objętość z tyłu głowy (ponytail/bun jak na obrazie referencyjnym)
    extra_verts = []
    extra_faces = []
    extra_edges = []
    start_idx = len(hair_v)

    bun_c = np.array([0.0, -0.062, -radii[2] - 0.032])
    bun_rx, bun_ry, bun_rz = 0.038, 0.040, 0.035
    LATS, LONS = 6, 12

    for lat in range(LATS):
        th1 = np.pi * (lat + 0.5) / float(LATS)
        for lon in range(LONS):
            th2 = 2.0 * np.pi * lon / float(LONS)
            extra_verts.append([
                bun_c[0] + bun_rx * np.sin(th1) * np.sin(th2),
                bun_c[1] + bun_ry * np.cos(th1),
                bun_c[2] + bun_rz * np.sin(th1) * np.cos(th2)
            ])

    for lat in range(LATS - 1):
        for lon in range(LONS):
            lon2 = (lon + 1) % LONS
            v0 = start_idx + lat * LONS + lon
            v1 = start_idx + lat * LONS + lon2
            v2 = start_idx + (lat + 1) * LONS + lon2
            v3 = start_idx + (lat + 1) * LONS + lon
            extra_faces.append([v0, v1, v2])
            extra_faces.append([v0, v2, v3])
            extra_edges.append((v0, v1))
            extra_edges.append((v0, v3))

    all_hv = np.vstack([hair_v, np.array(extra_verts)])
    all_hf = np.vstack([sf, np.array(extra_faces)])
    return all_hv, all_hf, extra_edges


def gender_modify(V, topo, gender):
    V = V.copy()
    if gender not in ("male", "female"):
        return V
    y = V[:468, 1]

    if gender == "male":
        wjaw = np.zeros(len(V))
        wjaw[:468] = _smooth((0.008 - y) / 0.050)
        V[:, 0] *= 1 + 0.085 * wjaw
        wcheek = np.zeros(len(V))
        wcheek[:468] = _smooth((0.018 - y) / 0.03) * _smooth((np.abs(V[:468, 0]) - 0.030) / 0.018)
        V[:, 2] += 0.0022 * wcheek
        brow = np.zeros(len(V))
        brow[topo.brow_L + topo.brow_R] = 1.0
        V[:, 2] += 0.0022 * brow
        V *= 1.025
    else:
        wjaw = np.zeros(len(V))
        wjaw[:468] = _smooth((0.014 - y) / 0.055)
        V[:, 0] *= 1 - 0.075 * wjaw
        wcheek = np.zeros(len(V))
        wcheek[:468] = _smooth((0.026 - y) / 0.030) * _smooth((np.abs(V[:468, 0]) - 0.028) / 0.020)
        V[:, 2] += 0.0024 * wcheek
        lips = np.zeros(len(V))
        lips[topo.lips] = 1.0
        V[:, 2] += 0.0011 * lips
        V *= 0.975
    return V


def eye_data(V, topo):
    fwd = vertex_normals(V[:468], topo.F).mean(axis=0)
    fwd /= np.linalg.norm(fwd)
    if fwd[2] < 0:
        fwd = -fwd

    eyes = []
    for ring_ids in (topo.eye_L, topo.eye_R):
        ring = V[ring_ids]
        c = ring.mean(axis=0)
        eye_r = float(np.linalg.norm(ring - c, axis=1).max())

        best = min(IRIS_CENTERS, key=lambda i: np.linalg.norm(V[i] - c))
        iris_ring_ids = IRIS_RINGS[IRIS_CENTERS.index(best)]
        iris_c = V[best]
        iris_ring = V[iris_ring_ids]
        iris_r = float(np.linalg.norm(iris_ring - iris_c, axis=1).mean())

        ball_r = iris_r / EYEBALL_IRIS_RATIO
        ball_center = iris_c - fwd * np.sqrt(max(ball_r ** 2 - iris_r ** 2, 0.0))

        eyes.append({
            "ring": ring_ids, "ring_center": c, "ring_r": eye_r,
            "iris_center": iris_c, "iris_r": iris_r, "iris_ring": iris_ring_ids,
            "ball_center": ball_center, "ball_r": ball_r, "forward": fwd,
        })
    return eyes


def blink_deltas(V, topo):
    delta = np.zeros_like(V)
    eyes = eye_data(V, topo)
    touched = set()

    for e in eyes:
        c = e["ring_center"]
        r = e["ring_r"]
        fwd = e["forward"]
        d = np.linalg.norm(V - c, axis=1)
        near = np.where(d < r * 2.2)[0]

        gc = e["ball_center"]
        up = np.array([0.0, 1.0, 0.0])
        right = np.cross(up, fwd)
        right /= np.linalg.norm(right)
        up2 = np.cross(fwd, right)
        for i in near:
            rel = V[i] - gc
            rn = np.linalg.norm(rel)
            if rn < 1e-6:
                continue
            elev = np.arctan2(rel @ up2, rel @ fwd)
            upper = elev > 0.06
            target_elev = -0.05 if upper else elev * 0.72
            dang = float(np.clip(target_elev - elev, -1.1, 1.1))
            if abs(dang) < 1e-4:
                continue
            K = np.array([[0, -right[2], right[1]],
                          [right[2], 0, -right[0]],
                          [-right[1], right[0], 0]])
            R = np.eye(3) + np.sin(dang) * K + (1 - np.cos(dang)) * (K @ K)
            new_rel = R @ rel
            nn = np.linalg.norm(new_rel)
            if nn < r * 1.02:
                new_rel = new_rel / max(nn, 1e-9) * (r * 1.02)
            w = _smooth(1 - (d[i] - r) / (r * 1.2))
            if w <= 0:
                continue
            delta[i] += (new_rel - rel) * w
            touched.add(int(i))
    idx = sorted(touched)
    return idx, delta[idx], eyes


def mouth_deltas(V, topo):
    mc = (V[13] + V[14]) * 0.5
    delta = np.zeros_like(V)
    touched = set()
    for i in range(len(V)):
        d = np.linalg.norm(V[i] - mc)
        if d < 0.075 and V[i, 1] <= mc[1] + 0.005:
            w = _smooth(1.0 - (d / 0.075))
            dy = -0.018 * w
            dz = -0.005 * w
            delta[i] += [0.0, dy, dz]
            touched.add(int(i))
        elif d < 0.040 and V[i, 1] > mc[1] + 0.002:
            w = _smooth(1.0 - (d / 0.040))
            dy = 0.003 * w
            delta[i] += [0.0, dy, 0.0]
            touched.add(int(i))
    idx = sorted(touched)
    return idx, delta[idx]


def extract_facial_quad_edges(V: np.ndarray, F: np.ndarray) -> List[Tuple[int, int]]:
    """Łączy sąsiadujące trójkąty twarzy w czyste czworokąty (quad topology) jak w Metahuman / Metascan."""
    edge_to_faces = defaultdict(list)
    for fi, tri in enumerate(F):
        for k in range(3):
            e = tuple(sorted((int(tri[k]), int(tri[(k + 1) % 3]))))
            edge_to_faces[e].append(fi)

    diagonals = set()
    used_faces = set()

    for e, f_indices in edge_to_faces.items():
        if len(f_indices) == 2:
            f1, f2 = f_indices
            if f1 not in used_faces and f2 not in used_faces:
                v0_1, v1_1, v2_1 = V[F[f1, 0]], V[F[f1, 1]], V[F[f1, 2]]
                n1 = np.cross(v1_1 - v0_1, v2_1 - v0_1)
                ln1 = np.linalg.norm(n1)
                v0_2, v1_2, v2_2 = V[F[f2, 0]], V[F[f2, 1]], V[F[f2, 2]]
                n2 = np.cross(v1_2 - v0_2, v2_2 - v0_2)
                ln2 = np.linalg.norm(n2)
                if ln1 > 1e-8 and ln2 > 1e-8:
                    cos_ang = np.dot(n1 / ln1, n2 / ln2)
                    if cos_ang > 0.82:  # kąt < 35 stopni -> tworzą quad
                        diagonals.add(e)
                        used_faces.add(f1)
                        used_faces.add(f2)

    quad_edges = [e for e in edge_to_faces.keys() if e not in diagonals]
    return quad_edges


def build_head(gender: str = "female", texture=None, skin_tone=CLAY_TONE,
               fitted_V=None, fitted_uv=None, iris_colors=None,
               scalp_scale=(1.0, 1.0, 1.0), depth_scale=1.0,
               include_neck: bool = True, include_ears: bool = True,
               include_hair: bool = True):
    """
    Buduje kompletny, ultra-realistyczny model 3D głowy z twarzą, czaszką, szyją,
    uszami, gałkami ocznymi i fryzurą oraz precyzyjną topologią siatki quad (wireframe).
    """
    topo = Topology()

    if fitted_V is not None:
        assert len(fitted_V) == 478, "fitted_V must carry all 478 landmarks"
        V = np.asarray(fitted_V, dtype=np.float64).copy()
        uv = np.asarray(fitted_uv, dtype=np.float64).copy() if fitted_uv is not None else topo.UV.copy()
    else:
        V = gender_modify(topo.V, topo, gender)
        uv = topo.UV.copy() if topo.UV is not None else np.full((478, 2), 0.5)

    sc = list(scalp_scale)
    if gender == "male":
        sc = [s * a for s, a in zip(sc, (1.035, 1.015, 1.03))]
    elif gender == "female":
        sc = [s * a for s, a in zip(sc, (0.995, 1.01, 0.99))]
    sv, sf_local, hc, radii, scalp_quad_edges = build_scalp(V, topo, radii_scale=tuple(sc), depth_scale=depth_scale)

    rim = topo.oval
    M = len(rim)
    sf = sf_local.copy()
    is_rim = sf < M
    sf[is_rim] = np.asarray(rim)[sf[is_rim]]
    sf[~is_rim] = sf[~is_rim] - M + 478

    positions_list = [V, sv]
    uv_scalp = np.full((len(sv), 2), 0.05)
    uvs_list = [uv, uv_scalp]
    indices_list = [topo.F, sf]

    face_quad_edges = extract_facial_quad_edges(V, topo.F)
    all_quad_edges = list(face_quad_edges)

    # Przesunięcie indeksów krawędzi cranium
    for a, b in scalp_quad_edges:
        ea = int(rim[a]) if a < M else int(a - M + 478)
        eb = int(rim[b]) if b < M else int(b - M + 478)
        all_quad_edges.append((ea, eb))

    cur_v_offset = len(V) + len(sv)

    # 1. Anatomiczna szyja (Neck)
    neck_info = {}
    if include_neck:
        nv, nf, n_quads, n_uvs = build_neck()
        neck_indices = nf + cur_v_offset
        positions_list.append(nv)
        uvs_list.append(n_uvs)
        indices_list.append(neck_indices)
        for a, b in n_quads:
            all_quad_edges.append((a + cur_v_offset, b + cur_v_offset))
        neck_info = {"start": cur_v_offset, "count": len(nv), "faces": neck_indices.tolist()}
        cur_v_offset += len(nv)

    # 2. Trójwymiarowe uszy (Ears: Left & Right)
    ears_info = {}
    if include_ears:
        ev_l, ef_l, eq_l, euv_l = build_ear("left")
        ears_l_indices = ef_l + cur_v_offset
        positions_list.append(ev_l)
        uvs_list.append(euv_l)
        indices_list.append(ears_l_indices)
        for a, b in eq_l:
            all_quad_edges.append((a + cur_v_offset, b + cur_v_offset))
        l_offset = cur_v_offset
        cur_v_offset += len(ev_l)

        ev_r, ef_r, eq_r, euv_r = build_ear("right")
        ears_r_indices = ef_r + cur_v_offset
        positions_list.append(ev_r)
        uvs_list.append(euv_r)
        indices_list.append(ears_r_indices)
        for a, b in eq_r:
            all_quad_edges.append((a + cur_v_offset, b + cur_v_offset))
        r_offset = cur_v_offset
        cur_v_offset += len(ev_r)

        ears_info = {"left": {"start": l_offset, "count": len(ev_l)},
                     "right": {"start": r_offset, "count": len(ev_r)}}

    # 3. Fryzura / Włosy 3D (Hair Volume)
    hair_info = {}
    if include_hair:
        hv, hf, hq = build_hair_volume(sv, sf_local, hc, radii, gender=gender)
        hair_indices = hf + cur_v_offset
        positions_list.append(hv)
        uvs_list.append(np.full((len(hv), 2), 0.08))
        indices_list.append(hair_indices)
        hair_info = {"start": cur_v_offset, "count": len(hv), "faces": hair_indices.tolist()}
        cur_v_offset += len(hv)

    positions = np.vstack(positions_list)
    uvs = np.vstack(uvs_list)
    indices = np.vstack(indices_list)

    face_count = len(topo.F)
    bidx, bdelta, eyes = blink_deltas(positions[:len(V)], topo)
    midx, mdelta = mouth_deltas(positions[:len(V)], topo)

    eyeballs = []
    for k, e in enumerate(eyes):
        col = (iris_colors[k] if iris_colors else
               ("#3b82f6" if gender == "female" else "#78716c"))
        eyeballs.append({
            "center": e["ball_center"].tolist(),
            "radius": e["ball_r"],
            "irisColor": col,
            "iris_center": e["iris_center"].tolist(),
            "iris_radius": e["iris_r"]
        })

    return {
        "gender": gender,
        "positions": positions.tolist(),
        "uvs": uvs.tolist(),
        "indices": indices.tolist(),
        "quad_edges": all_quad_edges,
        "faceCount": int(face_count),
        "blink": {"indices": bidx, "deltas": bdelta.tolist()},
        "mouth": {"indices": midx, "deltas": mdelta.tolist()},
        "eyeballs": eyeballs,
        "skinTone": skin_tone,
        "texture": texture,
        "center": hc.tolist(),
        "neck": neck_info,
        "ears": ears_info,
        "hair": hair_info
    }
