# -*- coding: utf-8 -*-
"""
cloud_net.py — klucz API do mowy (TTS) i do konsultacji planu „AI Wideo”.

ZASADY (świadomie restrykcyjne):
  1. DOMYŚLNIE WSZYSTKO JEST OFFLINE. Bez klucza i bez zaznaczonej zgody
     żaden bajt nie opuszcza komputera — ten moduł tylko na to pozwala.
  2. Klucz NIGDY nie leci do dziennika, do presetu ani do wyjątku
     (scrub() wycina każde jego wystąpienie).
  3. Klucz wysyłamy wyłącznie po https — albo na localhost (własny serwer:
     Ollama / LM Studio / LocalAI / vLLM / LiteLLM), gdzie ruch nie opuszcza maszyny.
  4. Zdjęcia (miniatury) lecą tylko przy osobnym suwaku „zgoda na miniatury”.
  5. Odpowiedź modelu to TYLKO liczby z listy dozwolonych pól planu (PLAN_FIELDS),
     każdą wartość sprawdzamy co do typu i zakresu. Żaden tekst z sieci nie jest
     tu wykonywany ani nie zmienia ustawień poza planem filmu.

Kompatybilność: OpenAI `/v1` i każdy serwer odtwarzający te endpointy
(/audio/speech, /chat/completions, /models).
"""
import base64
import json
import os
import re
import ssl
import urllib.error
import urllib.request

APP_VERSION = "1.4"

DEFAULTS = {
    "provider": "offline",       # "offline" | "openai"
    "base_url": "https://api.openai.com/v1",
    "key_tts": "",
    "key_ai": "",
    "tts_model": "gpt-4o-mini-tts",
    "tts_voice": "alloy",
    "ai_model": "gpt-4o-mini",
    "consent_tts": False,        # zgoda: tekst mowy opuszcza komputer
    "consent_ai": False,         # zgoda: treść promptu opuszcza komputer
    "ai_send_photos": False,     # zgoda: miniatury zdjęć opuszczają komputer
    "ai_thumb_px": 384,
    "remember_keys": True,       # False = klucze tylko w pamięci, nie w config.json
    "timeout_s": 30,
}

# głosy OpenAI TTS (stali bywalcy endpointu /audio/speech)
TTS_VOICES = ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova",
              "onyx", "sage", "shimmer", "verse", "marin", "cedar"]

# ------------------------------------------------- plan filmu: co wolno zmienić
# ścieżka w planie -> (typ, min, max, dozwolone wartości)
PLAN_FIELDS = {
    "klip_s":        ("num", 1.0, 30.0, None),
    "ruch.amp":      ("num", 0.0, 0.35, None),
    "ruch.obrot":    ("num", -3.0, 3.0, None),
    "ruch.shak":     ("num", 0.0, 0.12, None),
    "ruch.typ":      ("txt", None, None, ("kenburns", "zoom", "pan", "obrot", "sztywno", "handheld")),
    "obraz.ziarno":  ("num", 0.0, 14.0, None),
    "obraz.winieta": ("num", 0.0, 0.6, None),
    "obraz.rozmycie": ("num", 0.0, 6.0, None),
    "obraz.jasnosc": ("num", 0.7, 1.35, None),
    "obraz.kontrast": ("num", 0.7, 1.4, None),
    "obraz.nasycenie": ("num", 0.5, 1.6, None),
    "obraz.migotanie": ("num", 0.0, 0.5, None),
    "obraz.kol":     ("txt", None, None, ("normal", "bw", "sepia", "vintage", "kinowy",
                                          "cieply", "zimny", "sen")),
    "przejscia.czas": ("num", 0.0, 2.5, None),
    "przejscia.typ": ("txt", None, None, ("fade", "cut", "glitch", "move", "bialy")),
    "fps":           ("num", 12.0, 60.0, None),
    "cel_s":         ("num", 0.0, 600.0, None),
    "muzyka_gain":   ("num", 0.0, 1.5, None),
    "dopasowanie":   ("txt", None, None, ("fill", "fit", "stretch")),
}

SYSTEM_AI = (
    "Jesteś operatorem montażu. Dostajesz polski opis filmu ze zdjęć i aktualny plan "
    "renderowania. Odpowiedz WYŁĄCZNIE jednym obiektem JSON (bez markdown, bez komentarzy) "
    "z kluczami z tej listy: " + ", ".join(sorted(PLAN_FIELDS)) + ". "
    "Zasady: wartości liczbowe w podanych zakresach, tekstowe tylko z dozwolonych, "
    "pomiń klucze, których nie chcesz zmieniać, nie wymyślaj nazw plików ani osób, "
    "nie proś o dane osobowe. Jeśli opis jest niejasny, zwróć {}."
)


# =========================================================== małe narzędzia
def norm(net):
    """Sekcja configu + brakujące pola z DEFAULTS (nic nie zapisuje)."""
    out = dict(DEFAULTS)
    if isinstance(net, dict):
        for k in DEFAULTS:
            if k in net and net[k] is not None:
                out[k] = net[k]
    try:
        out["base_url"] = str(out.get("base_url", "")).strip().rstrip("/")
    except Exception:
        out["base_url"] = ""
    for k in ("key_tts", "key_ai"):
        out[k] = str(out.get(k, "") or "").strip()
    for k in ("tts_model", "tts_voice", "ai_model"):
        out[k] = str(out.get(k, "") or "").strip()
    for k in ("consent_tts", "consent_ai", "ai_send_photos", "remember_keys"):
        out[k] = bool(out.get(k))
    try:
        out["timeout_s"] = max(5.0, min(180.0, float(out.get("timeout_s", 30))))
    except Exception:
        out["timeout_s"] = 30.0
    try:
        out["ai_thumb_px"] = int(max(128, min(1024, int(out.get("ai_thumb_px", 384)))))
    except Exception:
        out["ai_thumb_px"] = 384
    try:
        out["provider"] = str(out.get("provider") or "offline").strip().lower()
    except Exception:
        out["provider"] = "offline"
    return out


def is_local(url):
    u = str(url or "").lower()
    return ("localhost" in u) or ("://127.0." in u) or (":://[::1]" in u) or ("://0.0.0.0" in u)


def secure_enough(net):
    """https albo localhost — przez czysty http na zewnątrz klucza nie wyślemy."""
    u = str(net.get("base_url") or "")
    if u.startswith("https://"):
        return True
    return u.startswith("http://") and is_local(u)


def mask(key):
    s = str(key or "")
    if not s:
        return "(brak)"
    if len(s) <= 10:
        return "•" * len(s)
    return "%s…%s  (%d znaki)" % (s[:3], s[-4:], len(s))


def scrub(text, net):
    """Wycina klucze z dowolnego tekstu (logi, komunikaty błędów)."""
    s = str(text if text is not None else "")
    n = norm(net) if isinstance(net, dict) else DEFAULTS
    for k in (n["key_tts"], n["key_ai"]):
        if k and len(k) > 4:
            s = s.replace(k, "••••")
    s = re.sub(r"(Bearer\s+)[A-Za-z0-9\-_=.]{6,}", r"\1••••", s)
    s = re.sub(r"sk-[A-Za-z0-9\-_]{6,}", "sk-••••", s)
    return s[:400]


def redact(net):
    """Kopia sekcji bez kluczy — do presetów i do anything shared."""
    out = dict(net or {})
    out["key_tts"] = ""
    out["key_ai"] = ""
    return out


def enabled(net, what):
    """Czy dana funkcja może iść do chmury: provider + klucz + zgoda + bezpieczny URL."""
    n = norm(net)
    if n["provider"] != "openai":
        return False
    if not n["base_url"]:
        return False
    if not secure_enough(n):
        return False
    if what == "tts":
        return bool(n["key_tts"]) and bool(n["consent_tts"])
    if what == "ai":
        return bool(n["key_ai"]) and bool(n["consent_ai"])
    return False


def why_off(net, what):
    """Po ludzku: czemu mimo wszystko lecimy offline."""
    n = norm(net)
    if n["provider"] != "openai":
        return "tryb offline (brak klucza)"
    if not n["base_url"]:
        return "puste API"
    if not secure_enough(n):
        return "adres API bez https — klucza nie wysyłamy"
    key = "key_tts" if what == "tts" else "key_ai"
    if not n[key]:
        return "brak klucza"
    if not (n["consent_tts"] if what == "tts" else n["consent_ai"]):
        return ("nie zaznaczona zgoda na wysłanie %s"
                % ("tekstu" if what == "tts" else "treści promptu"))
    return ""


# ============================================================== transport HTTP
def _ctx():
    try:
        return ssl.create_default_context()
    except Exception:
        return None


def request(net, path, payload, key, timeout=None, method="POST"):
    """Jeden request do serwera OpenAI-kompatybilnego. (ok, dane, msg)."""
    n = norm(net)
    url = n["base_url"].rstrip("/") + path
    if not url.lower().startswith(("http://", "https://")):
        return False, None, "adres API musi zaczynać się od https:// (lub http://localhost)"
    headers = {"Accept": "application/json", "User-Agent": "Realme12ProStudio/%s" % APP_VERSION}
    if key:
        headers["Authorization"] = "Bearer %s" % key
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        kw = {"timeout": float(timeout or n["timeout_s"])}
        if url.lower().startswith("https://"):
            kw["context"] = _ctx()
        with urllib.request.urlopen(req, **kw) as r:
            raw = r.read()
            code = getattr(r, "status", 200)
        if path.endswith("/chat/completions") or path.endswith("/models"):
            try:
                return True, json.loads(raw.decode("utf-8", "replace")), "HTTP %s" % code
            except Exception as e:
                return False, None, scrub("odpowiedź nie jest JSON: %s" % e, n)
        return True, raw, "HTTP %s" % code
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", "replace")[:220]
        except Exception:
            pass
        hint = ""
        if e.code in (401, 403):
            hint = " — klucz odrzucony albo brak dostępu do tego modelu"
        elif e.code == 404:
            hint = " — zły adres API albo model niedostępny"
        elif e.code == 429:
            hint = " — limit zapytań / brak środków na koncie"
        return False, None, scrub("HTTP %s%s %s" % (e.code, hint, body), n)
    except urllib.error.URLError as e:
        return False, None, scrub("brak połączenia z %s (%s)" % (url.split("/v1")[0], e.reason), n)
    except Exception as e:
        return False, None, scrub("błąd: %s" % e, n)


def probe(net, which="tts"):
    """'Testuj połączenie' — tylko /models, nic nie wysyłamy poza kluczem."""
    n = norm(net)
    if not n["base_url"]:
        return False, "wpierw wpisz adres API"
    key = n["key_tts"] if which == "tts" else n["key_ai"]
    if not key:
        return False, "brak klucza"
    if not secure_enough(n):
        return False, "adres bez https — przez czysty http nie wysyłamy klucza"
    ok, data, msg = request(n, "/models", None, key, timeout=min(12.0, n["timeout_s"]),
                            method="GET")
    if not ok:
        return False, msg
    ids = []
    try:
        ids = sorted(m.get("id", "") for m in data.get("data", []) if m.get("id"))
    except Exception:
        pass
    want = n["tts_model"] if which == "tts" else n["ai_model"]
    hit = "" if not want else ("  •  model %s: %s" % (want, "widzę go" if want in ids else "nie na liście"))
    return True, "%s  •  %d modeli%s" % (msg, len(ids), hit)


# ==================================================================== TTS (chmura)
def tts_speak(text, out_path, net, voice=None, speed=None, model=None):
    """POST /audio/speech → plik. (ok, msg, path)."""
    n = norm(net)
    txt = " ".join(str(text or "").split())
    if len(txt) < 2:
        return False, "pusty tekst", ""
    if len(txt) > 4000:
        txt = txt[:4000]        # tniemy, zamiast wysyłać 10 kB na raz
    payload = {
        "model": str(model or n["tts_model"] or "gpt-4o-mini-tts"),
        "input": txt,
        "voice": str(voice or n["tts_voice"] or "alloy"),
        "response_format": "wav",
    }
    try:
        sp = float(speed) if speed is not None else 1.0
        payload["speed"] = max(0.5, min(2.0, sp))
    except Exception:
        pass
    ok, raw, msg = request(n, "/audio/speech", payload, n["key_tts"])
    if not ok:
        return False, msg, ""
    if not raw or len(raw) < 200:
        return False, "serwer zwrócił pusty audio-odpowiedź (%d bajt.)" % len(raw or b""), ""
    try:
        d = os.path.dirname(os.path.abspath(out_path))
        if d:
            os.makedirs(d, exist_ok=True)
        with open(out_path, "wb") as f:
            f.write(raw)
    except Exception as e:
        return False, scrub("zapis pliku: %s" % e, n), ""
    return True, "%s  •  %s kB  •  %s" % (msg, len(raw) // 1024, payload["voice"]), out_path


# ============================================================ AI Wideo (konsultacja)
def _thumb_dataurl(path, max_px):
    """Miniatura JPG → data URL. Bez cv2/PIL po prostu nie wysyłamy zdjęcia."""
    try:
        import cv2
    except Exception:
        return ""
    try:
        cap = cv2.VideoCapture(path)
        img = None
        try:
            ok, img = cap.read()
        finally:
            cap.release()
        if img is None and os.path.isfile(path):
            img = cv2.imread(path)
        if img is None:
            return ""
        h, w = img.shape[:2]
        m = max(h, w) or 1
        if m > max_px:
            s = float(max_px) / float(m)
            img = cv2.resize(img, (max(2, int(w * s)), max(2, int(h * s))))
        ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 72])
        if not ok:
            return ""
        return "data:image/jpeg;base64," + base64.b64encode(buf.tobytes()).decode("ascii")
    except Exception:
        return ""


def consult_plan(prompt, plan, net, photos=None, include_photos=None):
    """
    Pyta model o dopracowanie planu. Zwraca (ok, msg, patch) — patch to już
    PRZEFILTROWANE pola z PLAN_FIELDS. Nigdy nie zapisuje niczego poza planem.
    """
    n = norm(net)
    txt = " ".join(str(prompt or "").split())[:1200]
    if len(txt) < 3:
        return False, "wpierw napisz prompt (czego ma dotyczyć film)", {}
    cur = {}
    try:
        for k in PLAN_FIELDS:
            v = plan
            ok = True
            for part in k.split("."):
                if isinstance(v, dict) and part in v:
                    v = v[part]
                else:
                    ok = False
                    break
            if ok and not isinstance(v, (dict, list)):
                cur[k] = v
    except Exception:
        pass
    content = [{"type": "text",
                "text": "OPIS UŻYTKOWNIKA (PL):\n%s\n\nAKTUALNY PLAN (JSON):\n%s"
                        % (txt, json.dumps(cur, ensure_ascii=False))}]
    want = n["ai_send_photos"] if include_photos is None else bool(include_photos)
    sent = 0
    if want and photos:
        for p in list(photos)[:4]:
            du = _thumb_dataurl(p, n["ai_thumb_px"])
            if du:
                content.append({"type": "image_url", "image_url": {"url": du}})
                sent += 1
    payload = {
        "model": n["ai_model"] or "gpt-4o-mini",
        "temperature": 0.4,
        "max_tokens": 700,
        "response_format": {"type": "json_object"},
        "messages": [{"role": "system", "content": SYSTEM_AI},
                     {"role": "user", "content": content}],
    }
    ok, data, msg = request(n, "/chat/completions", payload, n["key_ai"])
    if not ok:
        return False, msg, {}
    raw = ""
    try:
        raw = data["choices"][0]["message"]["content"]
    except Exception:
        return False, scrub("nie znam kształtu odpowiedzi serwera", n), {}
    patch, warn = parse_patch(raw)
    if not patch:
        return False, scrub("model nie podał nic użytecznego: %s" % (raw or "")[:160], n), {}
    note = "  •  %d pól planu%s" % (len(patch), (" (patrzył na %d miniatur)" % sent) if sent else "")
    return True, "%s  •  %s%s%s" % (msg, n["ai_model"], note, (("  •  " + warn) if warn else "")), patch


JSON_RE = re.compile(r"\{.*\}", re.S)


def parse_patch(raw):
    """JSON z odpowiedzi → tylko dozwolone pola, w zakresach. (patch, ostrzeżenie).

    Nic poza PLAN_FIELDS nie ma tu wstępu, więc model nie może np. dopisać
    sobie ścieżki pliku ani innego pola configu."""
    out, dropped = {}, []
    try:
        obj = json.loads(raw)
    except Exception:
        m = JSON_RE.search(str(raw or ""))
        if not m:
            return {}, ""
        try:
            obj = json.loads(m.group(0))
        except Exception:
            return {}, ""
    if not isinstance(obj, dict):
        return {}, ""
    for k, spec in PLAN_FIELDS.items():
        if k not in obj:
            continue
        kind, lo, hi, allowed = spec
        v = obj[k]
        if kind == "num":
            try:
                f = float(v)
            except Exception:
                dropped.append("%s (nie liczba)" % k)
                continue
            if f != f or f in (float("inf"), float("-inf")):
                dropped.append("%s (nieskończoność)" % k)
                continue
            new = max(lo, min(hi, f))
            if int(new) == new and int(lo) == lo and int(hi) == hi and k in ("fps", "cel_s"):
                new = int(new)
            out[k] = new
        else:
            s = str(v or "").strip().lower()
            if s in (allowed or ()):
                out[k] = s
            else:
                dropped.append("%s („%s” nie z listy)" % (k, s[:18]))
    for k in list(out):
        if k == "klip_s":
            out[k] = float(out[k])
    warn = ("odrzuciłem: " + ", ".join(dropped[:4])) if dropped else ""
    return out, warn


def merge_plan(plan, patch):
    """Wpisuje patch do planu (tylko dozwolone ścieżki). Zwraca liczbę zmian."""
    if not isinstance(plan, dict) or not patch:
        return 0
    n = 0
    for k, v in patch.items():
        if k not in PLAN_FIELDS:
            continue
        cur = plan
        parts = k.split(".")
        try:
            for p in parts[:-1]:
                if not isinstance(cur.get(p), dict):
                    cur = None
                    break
                cur = cur[p]
            if cur is None:
                continue
            cur[parts[-1]] = v
            n += 1
        except Exception:
            continue
    return n


# ============================================================ opis dla użytkownika
def privacy_lines(net=None):
    """Tekst do okienka ⓘ — co realnie wędruje do sieci, a co nie."""
    n = norm(net)
    cloud = n["provider"] == "openai"
    tgt = n["base_url"] or "—"
    local = is_local(tgt)
    host = tgt.split("//")[-1].split("/")[0] if "//" in tgt else tgt
    L = []
    L.append("DOMYŚLNIE: WSZYSTKO LOKALNIE")
    L.append("  Dopóki pole „tryb” = offline, aplikacja nie otwiera żadnego")
    L.append("  połączenia sieciowego. Mowa idzie przez System.Speech (Windows)")
    L.append("  albo espeak-ng, film ze zdjęć liczy ai_video.py na Twoim CPU.")
    L.append("")
    L.append("CO WYCHODZI Z KOMPUTERA, GDY WŁĄCZYSZ KLUCZ")
    L.append("  • Mowa (TTS): treść pola z tekstem (max 4000 znaków) + nazwa")
    L.append("    głosu/model. Reszta (głośność, tempo) zostaje u Ciebie.")
    L.append("  • AI Wideo: treść promptu (max 1200 znaków) + liczby z planu.")
    L.append("    Miniatury zdjęć TYLKO gdy osobno zaznaczysz zgodę (max 4")
    L.append("    zdjęcia, zmniejszone do %d px, JPEG q72)." % n["ai_thumb_px"])
    L.append("  • Nic więcej: nie wysyłamy ścieżek plików, playlisty, nazwy")
    L.append("    urządzenia, nagrania z mikrofonu, ani config.json.")
    L.append("")
    L.append("DOKĄD")
    L.append("  Adres API: %s" % tgt)
    if local:
        L.append("  To localhost — ruch nie opuszcza maszyny (np. Ollama,")
        L.append("  LM Studio, LocalAI). Klucz i tak leci w nagłówku.")
    elif cloud:
        L.append("  Serwer: %s — po https. Dostawca widzi treść zapytania" % host)
        L.append("  i loguje je we własnej polityce; my nie mamy na to wpływu.")
    else:
        L.append("  Tryb offline — nic nie jest wysyłane.")
    L.append("")
    L.append("KLUCZ API")
    L.append("  • %s" % mask(n["key_tts"]))
    L.append("  • %s" % mask(n["key_ai"]))
    L.append("  Trzymamy go w config.json obok programu (plik tekstowy, bez")
    L.append("  szyfrowania — kto ma plik, ten ma klucz).")
    L.append("  %s" % ("Zapis: WŁĄCZONY (remember_keys)." if n["remember_keys"]
                        else "Zapis: WYŁĄCZONY — klucz żyje tylko do zamknięcia okna."))
    L.append("  Kluczy NIGDY nie ma w presetach (udostępnialnych plikach")
    L.append("  ustawień) ani w dzienniku aplikacji.")
    L.append("")
    L.append("JAK SIĘ COFNĄĆ")
    L.append("  Wyzeruj tryb na „offline” (albo odznacz zgody) i kliknij")
    L.append("  „Wyczyść klucze”. Ustawienia wrócą do stanu bez sieci.")
    L.append("")
    L.append("  Status teraz: TTS %s  |  AI Wideo %s"
             % (("gotowy" if enabled(n, "tts") else (why_off(n, "tts") or "offline")),
                ("gotowy" if enabled(n, "ai") else (why_off(n, "ai") or "offline"))))
    return "\n".join(L)
