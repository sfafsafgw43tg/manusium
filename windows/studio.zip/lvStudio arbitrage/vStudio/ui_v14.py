# -*- coding: utf-8 -*-
"""
vStudio — rozszerzenie v1.4 (UI + logika)
=====================================================
Mixindodaje do aplikacji (bez ruszenia starego kodu):

  • PASEK ODTWARZACZA pod podglaadem — start / pauza / stop MP4, suwak czasu
    (0:04 / 0:10), skoki ±5 s. Widoczny WYLACZNIE gdy biezacy material to
    nagranie — przy zdjeciach caly wiersz znika (zadnej nakladki na obrazie).
  • PETLA NAGRANIA z plynnym szwem — „loop blend”: ostatnie klatki rozplywaja
    sie w pierwsze, wiec powtorka nie trzaska cieciem (crossfade, nie jump).
  • ZAKLADKA „Mowa (TTS)” — tekst → mowa, w 100% offline (glosy Windows
    System.Speech / espeak-ng / pyttsx3). Mowa leci jako klip na osi czasu,
    wiec rozmowca slyszy ja przez wirtualny mikrofon razem z szumem telefonu.
  • ZAPIS / WCZYTANIE USTAWIEN — caly stan aplikacji do pliku JSON
    (+ szybkie presety w folderze presets/), przywracanie domyslnych,
    autouzupelnienie widgetow i silnikow po wczytaniu.
  • ZAKLADKA „Prywatnosc” — opcjonalne klucze API (mowa z chmury + konsultacja
    planu AI) z okienkiem ⓘ o tym, co realnie wychodzi z komputera. Domyślnie
    nic nie jest wysylane: provider=offline, a przy chmurze potrzebne sa
    osobne zgody na tekst / prompt / miniatury zdjęć.

Wszystko przez atrybuty aplikacji z app.py (self.video, self.audio,
self.timeline, self.CFG, ...). Kazde wywolanie UI jest chronione — brak
modulu / brak biblioteki nie wysadza aplikacji.
"""
import json
import os
import sys
import threading
import time
from datetime import datetime

import customtkinter as ctk
from tkinter import filedialog, messagebox

# --- paleta (ta sama co w app.py / ui_v13.py) ---
BG = "#0B0D12"
CARD = "#141821"
CARD2 = "#1B212E"
LINE = "#262E40"
MUTED = "#8B93A5"
TEXT = "#E9EBF1"
DIM = "#5A6272"
WHITE = "#F2F3F6"
GHOST = dict(fg_color="transparent", border_width=1, border_color=LINE,
             text_color=TEXT, corner_radius=10, hover_color=CARD2)
PRIMARY = dict(fg_color=WHITE, text_color="black", hover_color="#C9CDD6",
               corner_radius=10)
OPTION_MENU = dict(fg_color=WHITE, text_color="black", button_color="#C9CDD6",
                   button_hover_color=MUTED, dropdown_fg_color=CARD,
                   dropdown_text_color=TEXT, dropdown_hover_color=CARD2,
                   corner_radius=10)

APP_DIR = os.path.dirname(os.path.abspath(__file__))
PRESET_DIR = os.path.join(APP_DIR, "presets")
SETTINGS_EXT = ".json"

BACKEND_LABELS = {"auto": "Auto", "obs": "OBS Studio", "unitycapture": "Unity Capture"}

try:
    from phone_formats import PHONE_FORMATS, FIT_MODES, FILTERS, TRANSITIONS, SLIDESHOW_MODES
except Exception:
    PHONE_FORMATS = FIT_MODES = FILTERS = TRANSITIONS = SLIDESHOW_MODES = {}

try:
    import tts_engine as TTS
    HAS_TTS = True
except Exception:
    HAS_TTS = False
    TTS = None

try:
    import cloud_net as NET
    HAS_NET = True
except Exception:
    HAS_NET = False
    NET = None

try:
    import ai_video as AI
except Exception:
    AI = None

# etykiety widoczne w UI  <->  wartosci w configu
PROVIDER_LABELS = {
    "offline": "Offline (nic nie wychodzi)",
    "openai": "OpenAI-kompatybilne API",
}
PROVIDER_IDS = {v: k for k, v in PROVIDER_LABELS.items()}

try:
    from audio_timeline import fmt_time
except Exception:
    def fmt_time(s):
        try:
            s = max(0, int(float(s)))
            return "%d:%02d" % (s // 60, s % 60)
        except Exception:
            return "0:00"


def _app_module():
    """Modul app.py (uruchomiony jako __main__ przez START_*.bat) — bez ponownego exec()."""
    for name in ("__main__", "app"):
        m = sys.modules.get(name)
        if m is not None and hasattr(m, "DEFAULT_CONFIG"):
            return m
    return None


def _fmt_clock(seconds):
    """0:04 / 12:07 — jak w odtwarzaczu wideo."""
    try:
        s = max(0.0, float(seconds))
        total = int(round(s))
        if total >= 3600:
            return "%d:%02d:%02d" % (total // 3600, (total % 3600) // 60, total % 60)
        return "%02d:%02d" % (total // 60, total % 60)
    except Exception:
        return "0:00"


def _safe_name(text):
    keep = "".join(ch if (ch.isalnum() or ch in "-_ ") else "_" for ch in (text or ""))
    return (keep.strip().replace(" ", "_")[:48] or "preset")


class V14Mixin(object):

    # ==================================================================== INIT
    def _init_v14(self):
        """Stan nowych funkcji — wolane z RealmeStudioApp.__init__ (przed _build_ui)."""
        self._v14_ctr = 0
        self._v14_drag = False
        self._v14_shown = False
        self._v14_panel = None
        self._v14_grid = {}
        self._tts_busy = False
        self._tts_voices = []
        self._tts_backend = ""
        self._tts_last_path = ""
        self._settings_win = None
        try:
            v = (self.CFG.get("video") or {})
            if self.video is not None:
                self.video.loop_video = bool(v.get("loop_video", True))
                self.video.set_loop_blend(float(v.get("loop_blend", 0.35)))
        except Exception:
            pass
        try:
            t = (self.CFG.get("tts") or {})
            self._tts_voice = t.get("voice", "") or ""
            self._tts_rate = float(t.get("rate", 0))
            self._tts_volume = float(t.get("volume", 90))
        except Exception:
            self._tts_voice, self._tts_rate, self._tts_volume = "", 0.0, 90.0

    def _accent(self):
        try:
            return (self.CFG.get("ui") or {}).get("accent") or "#E8A93D"
        except Exception:
            return "#E8A93D"

    # ================================================== PASEK ODTWARZACZA (UI)
    def _build_v14_ui(self):
        """Pasek odtwarzacza pod podglądem. Wolane na koncu _build_ui.

        Widoczny WYLACZNIE, gdy biezacy slajd to nagranie (mp4/avi/mkv/mov...) —
        przy zdjeciach pasek jest zdjety, zeby nie udawal odtwarzacza.
        """
        try:
            holder = self.lbl_preview.master          # „telefon” (phone_outer)
            accent = self._accent()

            # ---- pasek pod podgladem (na starcie ukryty — decyduje _v14_tick)
            panel = ctk.CTkFrame(holder, fg_color="#0E1016", corner_radius=16,
                                 border_width=1, border_color=LINE)
            self._v14_panel = panel
            self._v14_grid = dict(row=2, column=0, sticky="ew", padx=12, pady=(2, 12))
            panel.grid(**self._v14_grid)
            panel.grid_remove()
            self._v14_shown = False

            row = ctk.CTkFrame(panel, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=(8, 2))
            ctk.CTkButton(row, text="⏮", width=40, font=ctk.CTkFont(size=14),
                          command=self._slide_prev, **GHOST).pack(side="left", padx=2)
            self.btn_vplay_sm = ctk.CTkButton(row, text="▶", width=52, height=30,
                                              font=ctk.CTkFont(size=15, weight="bold"),
                                              command=self._v14_toggle, **PRIMARY)
            self.btn_vplay_sm.pack(side="left", padx=2)
            ctk.CTkButton(row, text="⏹", width=40, font=ctk.CTkFont(size=14),
                          command=self._v14_stop, **GHOST).pack(side="left", padx=2)
            ctk.CTkButton(row, text="⏭", width=40, font=ctk.CTkFont(size=14),
                          command=self._slide_next, **GHOST).pack(side="left", padx=(2, 6))

            self.lbl_vtime = ctk.CTkLabel(row, text="00:00 / 00:00", width=104,
                                          font=ctk.CTkFont(size=12, weight="bold"),
                                          text_color=TEXT)
            self.lbl_vtime.pack(side="right", padx=(4, 6))
            self.sld_seek = ctk.CTkSlider(row, from_=0.0, to=1000.0, number_of_steps=1000,
                                          fg_color=CARD2, progress_color=accent,
                                          button_color=accent, button_hover_color=WHITE,
                                          command=self._v14_seek)
            self.sld_seek.pack(side="left", fill="x", expand=True, padx=(6, 4))
            try:
                self.sld_seek.bind("<Button-1>", lambda e: setattr(self, "_v14_drag", True))
                self.sld_seek.bind("<ButtonRelease-1>", self._v14_seek_release)
            except Exception:
                pass

            row2 = ctk.CTkFrame(panel, fg_color="transparent")
            row2.pack(fill="x", padx=8, pady=(0, 2))
            self.var_vloop = ctk.BooleanVar(value=bool(self.video.loop_video) if self.video else True)
            ctk.CTkCheckBox(row2, text="Zapętl nagranie", variable=self.var_vloop,
                            font=ctk.CTkFont(size=12), command=self._on_v14_loop
                            ).pack(side="left", padx=(4, 10))
            ctk.CTkButton(row2, text="−5 s", width=52, height=24, font=ctk.CTkFont(size=11),
                          command=lambda: self._v14_nudge(-5), **GHOST).pack(side="right", padx=2)
            ctk.CTkButton(row2, text="+5 s", width=52, height=24, font=ctk.CTkFont(size=11),
                          command=lambda: self._v14_nudge(5), **GHOST).pack(side="right", padx=2)
            self.lbl_vblend = ctk.CTkLabel(row2, text="płynny szew: 0.35 s",
                                          font=ctk.CTkFont(size=11), text_color=MUTED)
            self.lbl_vblend.pack(side="right", padx=(10, 6))
            self.sld_blend = ctk.CTkSlider(row2, from_=0.0, to=1.2, number_of_steps=24,
                                           width=132, command=self._on_v14_blend)
            self.sld_blend.pack(side="right", padx=(0, 2))
            if self.video:
                self.sld_blend.set(float(self.video.loop_blend))

            # osobny wiersz na diagnostykę — przy waskim oknie nic sie nie rozjedzie
            row3 = ctk.CTkFrame(panel, fg_color="transparent")
            row3.pack(fill="x", padx=10, pady=(0, 8))
            self.lbl_vinfo = ctk.CTkLabel(row3, text="—", font=ctk.CTkFont(size=11),
                                         text_color=MUTED, anchor="w")
            self.lbl_vinfo.pack(side="left")

            self._v14_tick(force=True)
            self._net_attach_ai()
        except Exception as e:
            try:
                self._log("Pasek odtwarzacza: %s" % e)
            except Exception:
                pass

    # ------------------------------------------------------------- transport
    def _v14_toggle(self):
        """▶ / ❚❚ bieżącego nagrania. Zdjęcia nie mają transportu — nic nie robimy."""
        try:
            if not self.video or not self.video.is_video_item():
                return
            on = self.video.toggle_playing()
            self._log("Nagranie: %s" % ("gramy" if on else "pauza"))
            self._v14_tick(force=True)
        except Exception as e:
            self._log("Odtwarzacz: %s" % e)

    def _v14_stop(self):
        try:
            if not self.video or not self.video.is_video_item():
                return
            self.video.stop_video()
            self._log("Nagranie zatrzymane (wróciłem do początku).")
            self._v14_tick(force=True)
        except Exception as e:
            self._log("Odtwarzacz: %s" % e)

    def _v14_nudge(self, delta):
        try:
            if self.video and self.video.is_video_item():
                self.video.nudge(delta)
                self._v14_tick(force=True)
        except Exception:
            pass

    def _v14_seek(self, val):
        try:
            if not self.video or not self.video.is_video_item():
                return
            info = self.video.video_info()
            dur = float(info.get("dur_s") or 0.0)
            if dur <= 0.0:
                return
            self.video.seek(seconds=(float(val) / 1000.0) * dur)
            self.lbl_vtime.configure(text="%s / %s" % (_fmt_clock((float(val) / 1000.0) * dur),
                                                       _fmt_clock(dur)))
        except Exception:
            pass

    def _v14_seek_release(self, _e=None):
        self._v14_drag = False

    def _on_v14_loop(self):
        try:
            on = bool(self.var_vloop.get())
            if self.video:
                self.video.set_loop(on)
            self._log("Pętla nagrania: %s" % ("włączona (płynny szew)" if on
                                              else "wyłączona — stop lub następny slajd"))
        except Exception:
            pass

    def _on_v14_blend(self, val):
        try:
            s = float(val)
            if self.video:
                self.video.set_loop_blend(s)
            self.lbl_vblend.configure(text=("płynny szew: twarde cięcie" if s <= 0.01
                                            else "płynny szew: %.2f s" % s))
        except Exception:
            pass

    # ------------------------------------------------------------ tick (UI->UI)
    def _v14_set_visible(self, on):
        """Pasek tylko przy nagraniach — przy zdjeciach zabieramy wiersz (grid_remove)."""
        if bool(on) == self._v14_shown:
            return
        self._v14_shown = bool(on)
        try:
            if self._v14_shown:
                self._v14_panel.grid(**self._v14_grid)
            else:
                self._v14_panel.grid_remove()
        except Exception:
            pass

    def _v14_tick(self, force=False):
        """Widocznosc paska + pozycja, czas, stan przyciskow."""
        try:
            self._v14_ctr = int(getattr(self, "_v14_ctr", 0)) + 1
            if not force and (self._v14_ctr % 3):
                return
            if self.video is None:
                self._v14_set_visible(False)
                return
            info = self.video.video_info()
            is_vid = bool(info["is_video"])
            self._v14_set_visible(is_vid)
            if not is_vid:
                return
            dur = float(info["dur_s"] or 0.0)
            pos = float(info["pos_s"] or 0.0)
            if dur > 0:
                if not self._v14_drag:
                    try:
                        self.sld_seek.set(max(0.0, min(1000.0, 1000.0 * pos / dur)))
                    except Exception:
                        pass
                self.lbl_vtime.configure(text="%s / %s" % (_fmt_clock(pos), _fmt_clock(dur)))
            else:
                self.lbl_vtime.configure(text="—:— / —:—")
            self.lbl_vinfo.configure(text="%s  •  %s  •  %d kl.  •  %.0f fps%s" % (
                info["name"][:22], "petla" if info["loop"] else "bez pętli",
                int(info["frames"]), float(info["fps"] or 0),
                "  •  PAUZA" if not info["playing"] else ""))
            try:
                self.btn_vplay_sm.configure(text=("❚❚" if info["playing"] else "▶"))
            except Exception:
                pass
        except Exception:
            pass

    def _v14_bind_keys(self):
        try:
            self.bind("<Control-space>", lambda e: self._v14_toggle())
            self.bind("<Control-Right>", lambda e: self._v14_nudge(5))
            self.bind("<Control-Left>", lambda e: self._v14_nudge(-5))
            self.bind("<Control-l>", lambda e: (self.var_vloop.set(not self.var_vloop.get()),
                                                self._on_v14_loop()))
            self.bind("<Control-s>", lambda e: self._save_settings_now())
        except Exception:
            pass

    # =================================================================== TTS
    def _tab_tts(self, tab):
        box = self._scroll_tab(tab)
        self._section(box, "Tekst do wypowiedzenia")
        self.txt_tts = ctk.CTkTextbox(box, height=92, font=ctk.CTkFont(size=12),
                                      fg_color=CARD2, corner_radius=10, border_width=1,
                                      border_color=LINE, text_color=TEXT, wrap="word")
        self.txt_tts.pack(fill="x", padx=16, pady=4)
        try:
            self.txt_tts.insert("1.0", (self.CFG.get("tts") or {}).get("text", "") or "")
        except Exception:
            pass

        row = ctk.CTkFrame(box, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=2)
        self.btn_tts_speak = ctk.CTkButton(row, text="🔊  Mów do mikrofonu", width=160,
                                           command=lambda: self._tts_run("speak"), **PRIMARY)
        self.btn_tts_speak.pack(side="left", padx=3)
        ctk.CTkButton(row, text="➕ Do osi czasu", width=112,
                      command=lambda: self._tts_run("add"), **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row, text="⏹ Stop", width=72,
                      command=self._tts_stop, **GHOST).pack(side="left", padx=3)
        row_b = ctk.CTkFrame(box, fg_color="transparent")
        row_b.pack(fill="x", padx=12, pady=(0, 2))
        ctk.CTkButton(row_b, text="💾 Zapisz WAV…", width=118,
                      command=lambda: self._tts_run("save"), **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row_b, text="Wyczyść tekst", width=104,
                      command=lambda: self.txt_tts.delete("1.0", "end"), **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row_b, text="Folder TTS", width=92,
                      command=self._tts_open_folder, **GHOST).pack(side="left", padx=3)

        self._section(box, "Głos i tempo")
        ctk.CTkLabel(box, text="Głos (zainstalowane w systemie)", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(anchor="w", padx=16, pady=(6, 0))
        self.var_tts_voice = ctk.StringVar(value="(domyślny głos systemu)")
        self.opt_tts_voice = ctk.CTkOptionMenu(box, variable=self.var_tts_voice,
                                               values=["(domyślny głos systemu)"],
                                               width=280, command=self._on_tts_voice)
        self.opt_tts_voice.pack(anchor="w", padx=16, pady=4)
        pct = lambda v: "%d%%" % int(float(v) * 100)
        self.sld_tts_rate, self.val_tts_rate = self._slider_card(
            box, "Tempo mowy", self._tts_rate, -10, 10, 20,
            lambda v: ("%+d" % int(round(float(v)))), self._on_tts_opts)
        self.sld_tts_vol, self.val_tts_vol = self._slider_card(
            box, "Głośność mowy", self._tts_volume / 100.0, 0, 1, 100, pct, self._on_tts_opts)
        self.var_tts_tl = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(box, text="Mowa na osi czasu = miks z szumem mikrofonu (zalecane)",
                        variable=self.var_tts_tl, font=ctk.CTkFont(size=11),
                        command=self._on_tts_opts).pack(anchor="w", padx=16, pady=(6, 2))
        self.lbl_tts_status = ctk.CTkLabel(box, text="Sprawdzam lokalne silniki mowy…",
                                           font=ctk.CTkFont(size=11), text_color=MUTED,
                                           wraplength=290, justify="left")
        self.lbl_tts_status.pack(anchor="w", padx=16, pady=(6, 0))
        self._hint(box, "Calkowicie offline: Windows uzywa wbudowanych glosow SAPI "
                        "(System.Speech), Linux/espeak-ng albo pyttsx3. Nic nie idzie do "
                        "sieci. „Mow do mikrofonu” = mowa leci tym samym kablem co szum, "
                        "wiec rozmowca slyszy ja w Zoomie/Teamsie/Discordzie.")
        try:
            self.after(700, self._tts_probe)
        except Exception:
            pass

    # ------------------------------------------------------------------ TTS logika
    def _tts_probe(self):
        """W watku: ktory silnik jest i jakie glosy ma system."""
        if not HAS_TTS:
            try:
                self.lbl_tts_status.configure(
                    text="Moduł tts_engine.py niedostępny (brak pliku?).")
            except Exception:
                pass
            return

        def work():
            try:
                be = TTS.backend()
                voices = TTS.list_voices() if be else []
                self._tts_backend = be or ""
                self._tts_voices = voices or []
                self._ui_post(self._tts_after_probe)
            except Exception as e:
                self._tts_backend, self._tts_voices = "", []
                msg = str(e)          # e znika po wyjsciu z except — zapamiętujemy tekst
                self._ui_post(lambda: self._tts_status("Silnik mowy: błąd %s" % msg))
        threading.Thread(target=work, daemon=True).start()

    def _tts_after_probe(self):
        try:
            names = ["(domyślny głos systemu)"] + [v[1] for v in self._tts_voices]
            self.opt_tts_voice.configure(values=names)
            want = self._tts_voice
            for i, (vid, lab) in enumerate(self._tts_voices):
                if vid == want:
                    self.var_tts_voice.set(names[i + 1])
                    break
            if self._tts_backend:
                self._tts_status("Silnik: %s  •  głosów w systemie: %d" % (
                    {"windows": "Windows (System.Speech)", "espeak": "espeak-ng",
                     "pyttsx3": "pyttsx3"}.get(self._tts_backend, self._tts_backend),
                    len(self._tts_voices)))
            else:
                self._tts_status("Brak lokalnego silnika mowy. Windows: Ustawienia → Czas "
                                 "i język → Mowa (dodaj głosy). Linux: apt install espeak-ng. "
                                 "Opcjonalnie: pip install pyttsx3.")
        except Exception as e:
            self._tts_status("TTS: nie udało się odświeżyć listy głosów (%s)" % e)

    def _tts_status(self, txt):
        try:
            self.lbl_tts_status.configure(text=txt)
        except Exception:
            pass

    def _tts_voice_id(self):
        try:
            lab = self.var_tts_voice.get()
            for vid, l2 in self._tts_voices:
                if l2 == lab:
                    return vid
        except Exception:
            pass
        return ""

    def _on_tts_voice(self, _lab=None):
        try:
            self._tts_voice = self._tts_voice_id()
            self._tts_status("Wybrano głos: %s" % (self._tts_voice or "(domyślny)"))
        except Exception:
            pass

    def _on_tts_opts(self):
        try:
            self._tts_rate = float(self.sld_tts_rate.get())
            self._tts_volume = float(self.sld_tts_vol.get()) * 100.0
        except Exception:
            pass

    def _tts_run(self, mode="speak"):
        """Generuj mowę w tle → (speak) zagraj do kabla / (add) klip / (save) plik."""
        if not HAS_TTS:
            self._log("TTS: brak modułu tts_engine.py.")
            return
        if self._tts_busy:
            self._log("TTS: poprzednia mowa jeszcze się generuje — chwileczkę.")
            return
        try:
            text = self.txt_tts.get("1.0", "end").strip()
        except Exception:
            text = ""
        if len(text) < 2:
            self._log("TTS: wpisz najpierw tekst.")
            return
        out = os.path.join(APP_DIR, "output", "TTS_%s.wav" % time.strftime("%Y-%m-%d_%H-%M-%S"))
        if mode == "save":
            p = filedialog.asksaveasfilename(title="Zapisz mowę jako WAV", defaultextension=".wav",
                                             initialfile=os.path.basename(out),
                                             filetypes=[("WAV", "*.wav"), ("Wszystkie", "*.*")])
            if not p:
                return
            out = p
        voice = self._tts_voice_id()
        rate = self._tts_rate
        vol = self._tts_volume
        self._tts_busy = True
        try:
            self.btn_tts_speak.configure(state="disabled")
            self._tts_status("Generuję mowę… (%d znaków)" % len(text))
        except Exception:
            pass

        net = self._net_cfg()
        cloud = ""
        try:
            if HAS_NET and NET.enabled(net, "tts"):
                cloud = "przez chmurę (%s → %s)" % (
                    net.get("tts_model"), str(net.get("base_url", "")).split("//")[-1].split("/")[0])
        except Exception:
            cloud = ""
        if cloud:
            self._log("TTS: %s — tekst leci do usługi zewnętrznej." % cloud)

        def work():
            ok, msg, path = (False, "brak silnika", "")
            idx = -1
            try:
                ok, msg, path = TTS.synth(text, out, voice=voice, rate=rate, volume=vol,
                                          net=net)
            except Exception as e:
                ok, msg, path = False, str(e), ""
            if ok and mode in ("speak", "add") and self.timeline is not None \
                    and self.var_tts_tl.get():
                try:
                    clip = self.timeline.add(path)
                    if clip.ok:
                        idx = len(self.timeline.clips) - 1
                    else:
                        msg += "  (do osi czasu nie wszedł: %s)" % clip.error
                except Exception as e:
                    msg += "  (oś czasu: %s)" % e
            self._ui_post(lambda: self._tts_done(mode, ok, msg, path, idx))
        threading.Thread(target=work, daemon=True).start()

    def _tts_done(self, mode, ok, msg, path, idx):
        self._tts_busy = False
        try:
            self.btn_tts_speak.configure(state="normal")
        except Exception:
            pass
        if not ok:
            self._tts_status("TTS: %s" % msg)
            self._log("TTS: %s" % msg)
            return
        self._tts_last_path = path
        dur = 0.0
        try:
            dur = float(self.timeline.clips[idx].duration) if idx >= 0 else 0.0
        except Exception:
            pass
        if mode == "save":
            self._tts_status("Zapisano: %s" % os.path.basename(path))
            self._log("TTS: WAV zapisany → %s" % path)
            return
        if idx >= 0:
            try:
                self._music_sel = idx
                self._refresh_music_list()
                self._draw_timeline()
                self._refresh_ai_music()
            except Exception:
                pass
            if mode == "speak":
                try:
                    if self.timeline is not None:
                        self.timeline.play_clip(idx)
                        self._sync_engine()
                except Exception:
                    pass
                demo = bool(self.audio is not None and getattr(self.audio, "demo_mode", False))
                self._log("TTS: mowa leci do mikrofonu%s (%s)." % (
                    " — UWAGA: tryb demo, dźwięk nie wychodzi" if demo else "",
                    fmt_time(dur)))
                self._tts_status("Gram mowę do kabla (%s). %s" % (
                    fmt_time(dur), "Tryb demo — dźwięk nie wychodzi." if demo else ""))
                try:
                    self.bell()
                except Exception:
                    pass
                return
            self._tts_status("Dodano do osi czasu: klip %d (%s)." % (idx + 1, fmt_time(dur)))
            self._log("TTS: dodano do osi czasu (%s)." % fmt_time(dur))
            return
        # brak osi czasu (brak modułu audio) — otwórz plik w systemowym odtwarzaczu
        self._tts_status("Wygenerowano: %s" % os.path.basename(path))
        self._log("TTS: %s. Brak modułu audio — otwieram plik w systemie." % msg)
        try:
            self._open_path(path)
        except Exception:
            pass

    def _tts_stop(self):
        try:
            if self.timeline is not None:
                self.timeline.stop()
                self._sync_engine()
                self._draw_timeline()
            self._log("TTS: zatrzymany.")
        except Exception:
            pass

    def _tts_open_folder(self):
        try:
            folder = os.path.dirname(self._tts_last_path) if self._tts_last_path \
                else os.path.join(APP_DIR, "output")
            os.makedirs(folder, exist_ok=True)
            self._open_path(folder)
        except Exception:
            pass

    # ============================================ PRYWATNOŚĆ / KLUCZE API (UI)
    def _net_scrub(self, msg):
        """Wycina klucze z kazdego tekstu, ktory idzie do dziennika."""
        try:
            if HAS_NET:
                return NET.scrub(msg, self._net_cfg(raw=True))
        except Exception:
            pass
        return str(msg) if msg is not None else ""

    def _net_cfg(self, raw=False):
        """Sekcja „net” — aktualny stan widgetow (raw=True bez normalizacji)."""
        base = {}
        try:
            base = dict(self.CFG.get("net") or {})
        except Exception:
            base = {}
        for name, attr, kind in (
                ("base_url", "ent_net_base", "txt"),
                ("key_tts", "ent_net_key_tts", "txt"),
                ("key_ai", "ent_net_key_ai", "txt"),
                ("tts_model", "ent_net_tts_model", "txt"),
                ("ai_model", "ent_net_ai_model", "txt"),
                ("tts_voice", "var_net_voice", "txt"),
                ("provider", "var_net_provider", "provider"),
                ("consent_tts", "var_net_ctts", "bool"),
                ("consent_ai", "var_net_cai", "bool"),
                ("ai_send_photos", "var_net_photos", "bool"),
                ("remember_keys", "var_net_remember", "bool"),
                ("timeout_s", "ent_net_timeout", "num"),
        ):
            w = getattr(self, attr, None)
            if w is None:
                continue
            try:
                v = w.get()
            except Exception:
                continue
            if kind == "provider":
                v = PROVIDER_IDS.get(str(v), "offline")
            elif kind == "bool":
                v = bool(v)
            elif kind == "num":
                try:
                    v = float(v)
                except Exception:
                    v = base.get("timeout_s", 30)
            base[name] = v
        if raw:
            return base
        try:
            return NET.norm(base)
        except Exception:
            return base

    def _tab_net(self, tab):
        box = self._scroll_tab(tab)
        net = self._net_cfg()

        self._section(box, "Prywatność — co tu ustawiasz")
        self._hint(box, "Ta aplikacja z założenia nic nie wysyła. Klucz API jest tylko "
                        "dla dwóch opcji: mowy z chmury (TTS) i konsultacji planu filmu "
                        "ze zdjęć. Bez poniższych zgód nic nie opuszcza komputera.")
        row = ctk.CTkFrame(box, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(row, text="ⓘ  Informacja o prywatności", width=214,
                      command=self._open_privacy_info, **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row, text="Wyczyść klucze", width=118,
                      command=self._net_clear_keys, **GHOST).pack(side="left", padx=3)

        self._section(box, "Tryb")
        self.var_net_provider = ctk.StringVar(value=PROVIDER_LABELS.get(
            net.get("provider", "offline"), "Offline (nic nie wychodzi)"))
        self.seg_net_provider = ctk.CTkSegmentedButton(
            box, values=list(PROVIDER_LABELS.values()), variable=self.var_net_provider,
            command=self._on_net_changed)
        self.seg_net_provider.pack(anchor="w", padx=16, pady=4)

        self._label_row(box, "Adres API (endpoint)",
                        "Zostaw https://api.openai.com/v1 albo wpisz własny serwer "
                        "kompatybilny z OpenAI (Ollama, LM Studio, LocalAI, vLLM, LiteLLM). "
                        "Przez czysty http klucz poleciałby jawnie — dlatego pozwalamy na "
                        "to tylko dla localhost.")
        self.ent_net_base = ctk.CTkEntry(box, width=292, font=ctk.CTkFont(size=12),
                                         placeholder_text="https://api.openai.com/v1")
        self.ent_net_base.pack(anchor="w", padx=16, pady=(0, 4))
        self.ent_net_base.insert("0", net.get("base_url", ""))
        self._label_row(box, "Timeout (s)",
                        "Ile sekund czekamy na odpowiedź serwera (5–180). Przy wolnym "
                        "połączeniu zwiększ; krótki timeout = szybka wpadka i powrót do "
                        "silnika lokalnego.")
        self.ent_net_timeout = ctk.CTkEntry(box, width=70, font=ctk.CTkFont(size=12))
        self.ent_net_timeout.pack(anchor="w", padx=16, pady=(0, 4))
        self.ent_net_timeout.insert("0", "%g" % float(net.get("timeout_s", 30)))

        # ---------------- klucze ----------------
        self._section(box, "Klucz API — mowa (TTS)")
        self._key_rows(box, net)

        self._section(box, "Zgody (bez nich nic nie poleci)")
        self.var_net_ctts = ctk.BooleanVar(value=bool(net.get("consent_tts")))
        ctk.CTkCheckBox(box, text="Zgadzam się wysłać TREŚĆ TEKSTU do usługi mowy",
                        variable=self.var_net_ctts, font=ctk.CTkFont(size=12),
                        command=self._on_net_changed).pack(anchor="w", padx=16, pady=(4, 1))
        self.var_net_cai = ctk.BooleanVar(value=bool(net.get("consent_ai")))
        ctk.CTkCheckBox(box, text="Zgadzam się wysłać TREŚĆ PROMPTU do usługi AI",
                        variable=self.var_net_cai, font=ctk.CTkFont(size=12),
                        command=self._on_net_changed).pack(anchor="w", padx=16, pady=1)
        self.var_net_photos = ctk.BooleanVar(value=bool(net.get("ai_send_photos")))
        ctk.CTkCheckBox(box, text="Zgadzam się wysłać MINIATURY zdjęć (max 4, ~384 px)",
                        variable=self.var_net_photos, font=ctk.CTkFont(size=12),
                        command=self._on_net_changed).pack(anchor="w", padx=16, pady=1)
        self.var_net_remember = ctk.BooleanVar(value=bool(net.get("remember_keys")))
        ctk.CTkCheckBox(box, text="Zapamiętuj klucze w config.json (inaczej żyją do zamknięcia)",
                        variable=self.var_net_remember, font=ctk.CTkFont(size=12),
                        command=self._on_net_changed).pack(anchor="w", padx=16, pady=(1, 4))
        self._hint(box, "Klucz w config.json to zwykły plik tekstowy — kto ma plik, ten ma "
                        "klucz. W presetach (udostępnianych ustawieniach) kluczy nigdy nie ma, "
                        "w dzienniku też nie. Miniatury zdjęć są domyślnie WYŁĄCZONE.")

        self.lbl_net_status = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11),
                                           text_color=MUTED, wraplength=292, justify="left")
        self.lbl_net_status.pack(anchor="w", padx=16, pady=(10, 2))
        row2 = ctk.CTkFrame(box, fg_color="transparent")
        row2.pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(row2, text="Testuj połączenie", width=150,
                      command=self._net_test, **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row2, text="💾  Zapisz ustawienia", width=150,
                      command=self._net_save, **PRIMARY).pack(side="left", padx=3)
        self._net_bind_entries()
        self._on_net_changed()

    def _label_row(self, parent, label, help_text):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(6, 0))
        ctk.CTkLabel(row, text=label, font=ctk.CTkFont(size=12),
                     text_color=TEXT).pack(side="left")
        ctk.CTkButton(row, text="ⓘ", width=24, height=20, font=ctk.CTkFont(size=11),
                      command=lambda: self._open_info_popup(label, help_text),
                      **GHOST).pack(side="left", padx=(6, 0))
        if help_text:
            self._hint(parent, help_text)

    def _key_rows(self, box, net):
        self._net_show = False
        self.ent_net_key_tts = ctk.CTkEntry(box, width=240, font=ctk.CTkFont(size=12),
                                            show="•", placeholder_text="sk-…")
        self.ent_net_key_tts.pack(anchor="w", padx=16, pady=(0, 2))
        self.ent_net_key_tts.insert("0", net.get("key_tts", ""))
        r = ctk.CTkFrame(box, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=(0, 4))
        ctk.CTkButton(r, text="Pokaż", width=64, height=22, font=ctk.CTkFont(size=11),
                      command=self._net_toggle_show, **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(r, text="Wklej ze schowka", width=124, height=22,
                      font=ctk.CTkFont(size=11),
                      command=lambda: self._net_paste(self.ent_net_key_tts),
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkLabel(r, text="model:", font=ctk.CTkFont(size=11),
                     text_color=MUTED).pack(side="left", padx=(8, 2))
        self.ent_net_tts_model = ctk.CTkEntry(r, width=130, font=ctk.CTkFont(size=11))
        self.ent_net_tts_model.pack(side="left")
        self.ent_net_tts_model.insert("0", net.get("tts_model", ""))
        ctk.CTkLabel(r, text="głos:", font=ctk.CTkFont(size=11),
                     text_color=MUTED).pack(side="left", padx=(8, 2))
        self.var_net_voice = ctk.StringVar(value=net.get("tts_voice") or "alloy")
        try:
            vals = list(NET.TTS_VOICES)
        except Exception:
            vals = ["alloy"]
        self.opt_net_voice = ctk.CTkOptionMenu(r, variable=self.var_net_voice, values=vals,
                                               width=90, command=self._on_net_changed)
        self.opt_net_voice.pack(side="left", padx=2)

        ctk.CTkLabel(box, text="Klucz API — AI Wideo (konsultacja planu)",
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=MUTED).pack(anchor="w", padx=16, pady=(10, 2))
        self.ent_net_key_ai = ctk.CTkEntry(box, width=240, font=ctk.CTkFont(size=12),
                                           show="•", placeholder_text="sk-…")
        self.ent_net_key_ai.pack(anchor="w", padx=16, pady=(0, 2))
        self.ent_net_key_ai.insert("0", net.get("key_ai", ""))
        r2 = ctk.CTkFrame(box, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=(0, 4))
        ctk.CTkButton(r2, text="Wklej ze schowka", width=124, height=22,
                      font=ctk.CTkFont(size=11),
                      command=lambda: self._net_paste(self.ent_net_key_ai),
                      **GHOST).pack(side="left", padx=3)
        ctk.CTkLabel(r2, text="model:", font=ctk.CTkFont(size=11),
                     text_color=MUTED).pack(side="left", padx=(8, 2))
        self.ent_net_ai_model = ctk.CTkEntry(r2, width=150, font=ctk.CTkFont(size=11))
        self.ent_net_ai_model.pack(side="left")
        self.ent_net_ai_model.insert("0", net.get("ai_model", ""))
        ctk.CTkLabel(box, text="Możesz wkleić ten sam klucz do obu pól — albo inny, jeśli "
                               "usługi masz w dwóch serwisach.", font=ctk.CTkFont(size=11),
                     text_color=DIM, wraplength=292, justify="left").pack(anchor="w", padx=16)

    def _net_bind_entries(self):
        try:
            for w in (self.ent_net_base, self.ent_net_key_tts, self.ent_net_key_ai,
                      self.ent_net_tts_model, self.ent_net_ai_model, self.ent_net_timeout):
                w.bind("<KeyRelease>", lambda e: self._on_net_changed())
                w.bind("<FocusOut>", lambda e: self._on_net_changed())
        except Exception:
            pass

    def _net_toggle_show(self):
        self._net_show = not getattr(self, "_net_show", False)
        for w in (self.ent_net_key_tts, self.ent_net_key_ai):
            try:
                w.configure(show="" if self._net_show else "•")
            except Exception:
                pass

    def _net_paste(self, entry):
        try:
            txt = self.clipboard_get().strip()
        except Exception:
            txt = ""
        if not txt:
            self._log("Schowek pusty — wklej klucz ręcznie (Ctrl+V w polu).")
            return
        try:
            entry.delete("0", "end")
            entry.insert("0", txt)
        except Exception:
            return
        self._on_net_changed()
        self._log("Klucz wklejony ze schowka (%d znaków). Nie zapisujemy go do dziennika."
                  % len(txt))

    def _net_clear_keys(self):
        for w in (self.ent_net_key_tts, self.ent_net_key_ai):
            try:
                w.delete("0", "end")
            except Exception:
                pass
        try:
            self.var_net_provider.set("Offline (nic nie wychodzi)")
        except Exception:
            pass
        for v in (getattr(self, "var_net_ctts", None), getattr(self, "var_net_cai", None),
                  getattr(self, "var_net_photos", None)):
            try:
                v.set(False)
            except Exception:
                pass
        self._on_net_changed()
        self._log("Klucze API wyczyszczone z okna. Tryb: offline — nic nie wychodzi z komputera.")

    def _on_net_changed(self):
        """WIDGETY → CFG + podpis stanu. Bez tego nic nie jest wysyłane."""
        net = self._net_cfg()
        try:
            self.CFG["net"] = dict(net)
        except Exception:
            pass
        txt = ""
        try:
            if HAS_NET:
                if net.get("provider") != "openai":
                    txt = ("Tryb: OFFLINE. Mowa = głosy systemu, film = lokalny "
                           "generator. Żadne dane nie opuszczają komputera.")
                else:
                    host = str(net.get("base_url", "")).split("//")[-1].split("/")[0]
                    loc = NET.is_local(net.get("base_url"))
                    t = NET.enabled(net, "tts")
                    a = NET.enabled(net, "ai")
                    txt = ("Adres: %s%s  •  TTS: %s  •  AI: %s  •  miniatury: %s\n"
                           "Klucze: TTS %s / AI %s  •  w presetach i dzienniku ich nie ma%s" % (
                               host, "  (lokalnie — dane nie opuszczają komputera)" if loc else "",
                               "gotowy" if t else NET.why_off(net, "tts"),
                               "gotowy" if a else NET.why_off(net, "ai"),
                               "włączone" if net.get("ai_send_photos") else "wyłączone",
                               NET.mask(net.get("key_tts")), NET.mask(net.get("key_ai")),
                               "" if net.get("remember_keys") else "  •  NIE zapisywane na dysk"))
                    if not loc and (t or a):
                        txt += "\nUWAGA: dane lecą do serwisu zewnętrznego — tam zostają w ich logach."
            else:
                txt = "Brak modułu cloud_net.py — aplikacja zostaje w pełni offline."
        except Exception:
            txt = "Tryb: OFFLINE."
        try:
            self.lbl_net_status.configure(text=txt)
        except Exception:
            pass
        self._net_refresh_ai_row()

    def _net_save(self):
        ok, msg = True, ""
        try:
            ok, msg = self._save_settings_now()
        except Exception as e:
            ok, msg = False, str(e)
        self._log("Ustawienia: %s" % (msg or ("zapisane" if ok else "nie zapisane")))

    def _net_test(self):
        if not HAS_NET:
            self._log("Test połączenia: brak modułu cloud_net.py.")
            return
        net = self._net_cfg()
        if net.get("provider") != "openai":
            self._log("Test: tryb offline — nie ma czego testować (zmień na „OpenAI-kompatybilne”).")
            return
        self._log("Test połączenia z %s…" % net.get("base_url"))

        def work():
            for which, label in (("tts", "Mowa"), ("ai", "AI Wideo")):
                if not net.get("key_tts" if which == "tts" else "key_ai"):
                    self._ui_post(lambda l=label: self._log("%s: brak klucza — pomijam." % l))
                    continue
                ok, msg = NET.probe(net, which)
                self._ui_post(lambda o=ok, m=msg, l=label: self._log(
                    "%s: %s" % (l, m if o else "nie poszło — %s" % m)))
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------- wiersz chmury w zakładce AI
    def _net_attach_ai(self):
        """Dokleja wiersz „Zapytaj AI o plan” na dół zakładki."""
        try:
            tab = None
            for cand in ["Generator 3D Twarzy", "AI Wideo"]:
                try:
                    tab = self.tabs.tab(cand)
                    if tab is not None: break
                except Exception:
                    pass
            if tab is None:
                return
            box = tab.winfo_children()[0] if tab is not None and tab.winfo_children() else tab
            if box is None:
                return
            row = ctk.CTkFrame(box, fg_color=CARD2, corner_radius=10,
                               border_width=1, border_color=LINE)
            row.pack(fill="x", padx=14, pady=(8, 12))
            ctk.CTkButton(row, text="🌐  Zapytaj AI o plan", width=160, height=28,
                          command=self._net_consult_ai, **PRIMARY).pack(side="left", padx=8, pady=6)
            ctk.CTkButton(row, text="ⓘ", width=28, height=28,
                          command=self._open_privacy_info, **GHOST).pack(side="left", pady=6)
            self.lbl_net_ai = ctk.CTkLabel(row, text="", font=ctk.CTkFont(size=11),
                                          text_color=MUTED, wraplength=150, justify="left")
            self.lbl_net_ai.pack(side="left", fill="x", expand=True, padx=(4, 8), pady=6)
            self._net_ai_row = row
        except Exception:
            self.lbl_net_ai = None
        self._net_refresh_ai_row()

    def _net_refresh_ai_row(self):
        lab = getattr(self, "lbl_net_ai", None)
        if lab is None:
            return
        try:
            if not HAS_NET:
                lab.configure(text="chmura: moduł niedostępny")
                return
            net = self._net_cfg()
            if net.get("provider") != "openai":
                lab.configure(text="chmura: wyłączona (tryb offline)")
            elif NET.enabled(net, "ai"):
                lab.configure(text="chmura: %s — gotowa" % NET.mask(net.get("key_ai")))
            else:
                lab.configure(text="chmura: %s" % NET.why_off(net, "ai"))
        except Exception:
            pass

    def _net_consult_ai(self):
        """Prompt (+ opcjonalnie miniatury) → model zwraca polskie liczby planu."""
        if not HAS_NET:
            self._log("AI Wideo: brak modułu cloud_net.py — zostaje lokalny parser promptu.")
            return
        net = self._net_cfg()
        if not NET.enabled(net, "ai"):
            self._log("AI Wideo: chmura nieaktywna (%s)." % NET.why_off(net, "ai"))
            self._open_privacy_info()
            return
        try:
            prompt = self.txt_prompt.get("1.0", "end").strip()
        except Exception:
            prompt = ""
        if len(prompt) < 3:
            self._log("AI Wideo: wpierw napisz prompt, potem pytaj chmurę.")
            return
        plan = getattr(self, "ai_plan", None)
        if plan is None:
            try:
                plan = AI.default_plan()
            except Exception:
                self._log("AI Wideo: brak modułu ai_video.py.")
                return
        photos = []
        if net.get("ai_send_photos"):
            try:
                photos = [p for p in (self.ai_photos or []) if os.path.isfile(p)]
            except Exception:
                photos = []
        self._log("AI Wideo: pytam %s o plan (%d znaków promptu%s)…" % (
            net.get("ai_model"), len(prompt),
            ", + %d miniatur" % min(4, len(photos)) if photos else ""))
        if getattr(self, "_net_busy", False):
            self._log("AI Wideo: poprzednie zapytanie jeszcze leci.")
            return
        self._net_busy = True

        def work():
            try:
                ok, msg, patch = NET.consult_plan(prompt, plan, net, photos=photos)
            except Exception as e:
                ok, msg, patch = False, NET.scrub("błąd: %s" % e, net), {}
            self._ui_post(lambda: self._net_consult_done(ok, msg, patch, plan))
        threading.Thread(target=work, daemon=True).start()

    def _net_consult_done(self, ok, msg, patch, plan):
        self._net_busy = False
        if not ok:
            self._log("AI Wideo: %s" % msg)
            return
        n = NET.merge_plan(plan, patch)
        try:
            plan["dopisek"] = ("chmura: %s" % ", ".join(sorted(patch)))[:220]
        except Exception:
            pass
        try:
            self.ai_plan = plan
            self._ai_sync_sliders()
            self._ai_update_plan_label()
        except Exception:
            pass
        self._log("AI Wideo: %s  •  zmieniłem %d pól planu — sprawdź i kliknij „Akceptuj prompt”."
                  % (msg, n))

    # --------------------------------------------------------- okienka ⓘ
    def _open_privacy_info(self):
        body = ""
        try:
            body = NET.privacy_lines(self._net_cfg()) if HAS_NET else (
                "Brak modułu cloud_net.py — aplikacja działa tylko lokalnie:\n"
                "  • mowa = głosy systemu (System.Speech / espeak-ng / pyttsx3)\n"
                "  • film ze zdjęć = lokalny silnik ai_video.py\n"
                "Żadne dane nie opuszczają komputera.")
        except Exception as e:
            body = "Nie udało się przygotować opisu: %s" % e
        self._open_info_popup("Prywatność i klucze API", body)

    def _open_info_popup(self, title, body):
        # jedno okno ⓘ naraz — inaczej klikanie mnoży plikające buźki
        prev = getattr(self, "_net_info_win", None)
        if prev is not None:
            try:
                prev.destroy()
            except Exception:
                pass
            self._net_info_win = None
        try:
            win = ctk.CTkToplevel(self)
        except Exception:
            self._log("%s:\n%s" % (title, body))
            return
        try:
            win.title(title)
            win.geometry("470x600")
            win.resizable(False, False)
            win.transient(self)
        except Exception:
            pass
        try:
            ctk.CTkLabel(win, text=title, font=ctk.CTkFont(size=15, weight="bold"),
                         text_color=TEXT).pack(anchor="w", padx=16, pady=(14, 4))
            box = ctk.CTkTextbox(win, font=ctk.CTkFont(family="Consolas", size=11),
                                 fg_color=CARD2, text_color=TEXT, wrap="word",
                                 border_width=1, border_color=LINE)
            box.pack(fill="both", expand=True, padx=14, pady=4)
            box.insert("1.0", body)
            box.configure(state="disabled")
            row = ctk.CTkFrame(win, fg_color="transparent")
            row.pack(fill="x", padx=14, pady=(4, 12))
            ctk.CTkButton(row, text="Skopiuj", width=92, command=lambda: self._copy_text(body),
                          **GHOST).pack(side="left", padx=3)
            ctk.CTkButton(row, text="Zamknij", width=92, command=win.destroy,
                          **PRIMARY).pack(side="right", padx=3)
            self._net_info_win = win
            try:
                win.bind("<Escape>", lambda e: win.destroy())
            except Exception:
                pass
        except Exception as e:
            self._log("%s  (okienko niedostępne: %s)\n%s" % (title, e, self._net_scrub(body)))

    def _copy_text(self, text):
        try:
            self.clipboard_clear()
            self.clipboard_append(text)
            self._log("Skopiowano do schowka.")
        except Exception:
            pass

    def _net_before_save(self):
        """Przed zapisem config.json: pilnuj, co faktycznie wolno zapisać."""
        try:
            net = self._net_cfg()
        except Exception:
            return
        if not net.get("remember_keys"):
            net = dict(net)
            net["key_tts"] = ""
            net["key_ai"] = ""
        try:
            self.CFG["net"] = net
        except Exception:
            pass

    # ==================================================== ZAPIS / WCZYTANIE
    def _collect_cfg(self, for_preset=False):
        """BIEŻĄCY stan widgetów → pełna konfiguracja (do pliku / presetu).

        for_preset=True → klucze API WYCINANE (preset to plik, ktory latwo
        komus podeslac; nie chcemy w nim niczyich tokenow)."""
        cfg = json.loads(json.dumps(self.CFG or {}))
        v = self.video
        if v is not None:
            cfg["video"] = {
                "format_id": v.format_id, "fit_mode": v.fit_mode, "filter": v.filter_id,
                "fps": int(v.fps), "backend": v.vcam_backend,
                "slideshow_mode": v.mode, "slideshow_interval": float(v.interval),
                "transition": v.transition,
                "effect_shake": bool(v.fx_shake), "effect_shake_amount": float(v.fx_shake_amount),
                "effect_grain": bool(v.fx_grain), "effect_grain_amount": float(v.fx_grain_amount),
                "effect_vignette": bool(v.fx_vignette), "effect_autofocus": bool(v.fx_autofocus),
                "overlay_rec": bool(v.ov_rec), "overlay_timestamp": bool(v.ov_timestamp),
                "overlay_brand": bool(v.ov_brand), "overlay_battery": bool(v.ov_battery),
                "mirror": bool(v.mirror), "rotate": int(v.rotate),
                "zoom": float(v.zoom), "pan_x": float(v.pan_x), "pan_y": float(v.pan_y),
                "orientation": v.orientation,
                "loop_video": bool(v.loop_video), "loop_blend": float(v.loop_blend),
                "frames": {k: list(t) for k, t in dict(v.frame_memory or {}).items()},
            }
        cfg.setdefault("audio", {})
        try:
            cfg["audio"].update({
                "profile": self.var_profile.get(), "volume": float(self.sld_volume.get()),
                "noise_level": float(self.sld_noise.get()), "event_rate": float(self.sld_event.get()),
                "bass": float(self.sld_bass.get()),
                "breath_on": bool(self.var_breath.get()),
                "breath_level": float(self.sld_breath.get()),
                "breath_rate": int(float(self.sld_brate.get())),
                "output_device_name": self.var_outdev.get(),
                "cable_only": bool(self.var_cable_only.get()),
                "monitor_on": bool(getattr(self, "_monitor_on", False)),
                "monitor_gain": float(self.sld_mon_gain.get()),
            })
        except Exception:
            pass
        try:
            cfg["audio"]["monitor_device_name"] = self.var_mon_dev.get()
        except Exception:
            pass
        try:
            if self.timeline is not None:
                cfg["audio"]["music_gain"] = float(self.timeline.gain)
                cfg["audio"]["music_loop"] = bool(self.timeline.loop_all)
                cfg["audio"]["music_files"] = [c.path for c in self.timeline.clips if c.ok][:80]
            if self.recorder is not None:
                cfg["audio"]["record_folder"] = self.recorder.folder
        except Exception:
            pass
        try:
            cfg["ai"] = {"prompt": self.txt_prompt.get("1.0", "end").strip()[:600],
                         "photos": list(self.ai_photos)[:200],
                         "quality": self.var_ai_quality.get(),
                         "music_name": self.var_ai_music.get()}
        except Exception:
            pass
        try:
            cfg["tts"] = {"text": self.txt_tts.get("1.0", "end").strip()[:4000],
                          "voice": self._tts_voice, "rate": float(self._tts_rate),
                          "volume": float(self._tts_volume)}
        except Exception:
            pass
        try:
            net = self._net_cfg()
            if not net.get("remember_keys"):
                net = dict(net)
                net["key_tts"] = ""
                net["key_ai"] = ""
            cfg["net"] = NET.redact(net) if for_preset else dict(net)
        except Exception:
            cfg.setdefault("net", {})
        cam_default = getattr(self, "camera_name", "vStudio") or "vStudio"
        cfg.setdefault("device_names", {"camera": cam_default, "microphone": cam_default})
        cfg.setdefault("ui", {})
        try:
            cfg["ui"]["autosave"] = bool(self.var_autosave.get())
        except Exception:
            pass
        return cfg

    def _settings_meta(self):
        return {"_meta": {"app": "vStudio", "version": "1.4",
                          "kiedy": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}}

    def _write_json(self, path, data):
        try:
            d = os.path.dirname(os.path.abspath(path))
            if d:
                os.makedirs(d, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True, "Zapisano: %s" % os.path.basename(path)
        except Exception as e:
            return False, "Nie udało się zapisać: %s" % e

    def _read_json(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                d = json.load(f)
            if not isinstance(d, dict):
                return None, "Plik nie zawiera ustawień (oczekiwano obiektu JSON)."
            return d, ""
        except Exception as e:
            return None, "Nie udało się wczytać: %s" % e

    # ------------------------------------------------------------ zapisy w UI
    def _save_settings_to_file(self):
        try:
            p = filedialog.asksaveasfilename(title="Zapisz ustawienia",
                                             defaultextension=SETTINGS_EXT,
                                             initialdir=PRESET_DIR,
                                             initialfile="realme12pro-ustawienia%s" % SETTINGS_EXT,
                                             filetypes=[("Ustawienia", "*.json"), ("Wszystkie", "*.*")])
            if not p:
                return
            data = self._collect_cfg(for_preset=True)
            data.update(self._settings_meta())
            data["_meta"]["klucze_api"] = "pominięte"
            ok, msg = self._write_json(p, data)
            self._log("Ustawienia: %s  (plik do udostępniania — klucze API wycięte)" % msg)
            self._refresh_settings_window()
        except Exception as e:
            self._log("Ustawienia: %s" % e)

    def _config_path(self):
        A = _app_module()
        return getattr(A, "CONFIG_PATH", None) or os.path.join(APP_DIR, "config.json")

    def _save_settings_now(self):
        """Ctrl+S — szybki zapis do config.json (to samo, co przy zamknięciu)."""
        try:
            cfg = self._collect_cfg()
            for k, val in cfg.items():
                self.CFG[k] = val
            ok, msg = self._write_json(self._config_path(), cfg)
            self._log("Ustawienia: %s" % msg)
        except Exception as e:
            self._log("Zapis ustawień nie wyszedł: %s" % e)

    def _load_settings_from_file(self):
        try:
            p = filedialog.askopenfilename(title="Wczytaj ustawienia",
                                           initialdir=PRESET_DIR if os.path.isdir(PRESET_DIR) else APP_DIR,
                                           filetypes=[("Ustawienia", "*.json"), ("Wszystkie", "*.*")])
            if not p:
                return
            self._apply_settings_file(p)
        except Exception as e:
            self._log("Ustawienia: %s" % e)

    def _apply_settings_file(self, path):
        try:
            live_net = dict(self.CFG.get("net") or {})   # nasz klucz z tej sesji (plik go nie ma)
        except Exception:
            live_net = {}
        data, err = self._read_json(path)
        if data is None:
            self._log(err)
            try:
                messagebox.showerror("vStudio", err)
            except Exception:
                pass
            return
        meta = data.get("_meta") or {}
        applied = self._apply_cfg(data)
        try:
            self._apply_net(data.get("net"), live_net)
        except Exception as e:
            self._log("Ustawienia: sekcja „net” — %s" % e)
        note = ""
        try:
            if not (self.CFG.get("net") or {}).get("key_tts") and \
                    not (self.CFG.get("net") or {}).get("key_ai"):
                note = "  •  klucze API: puste (offline)"
        except Exception:
            pass
        self._log("Wczytano ustawienia z %s  (%d sekcji%s)." % (
            os.path.basename(path), applied,
            (("  •  zapis: %s" % meta.get("kiedy")) if meta.get("kiedy") else "") + note))
        self._refresh_settings_window()

    # --------------------------------------------------------------- presety
    def _preset_files(self):
        try:
            if not os.path.isdir(PRESET_DIR):
                return []
            out = []
            for f in sorted(os.listdir(PRESET_DIR)):
                if f.lower().endswith(SETTINGS_EXT):
                    out.append(os.path.join(PRESET_DIR, f))
            return out
        except Exception:
            return []

    def _preset_save_named(self):
        try:
            name = (self.ent_preset.get() or "").strip()
            if not name:
                self._log("Ustawienia: wpisz nazwę presetu (np. „spotkanie”, „stream wieczór”).")
                return
            data = self._collect_cfg(for_preset=True)
            data.update(self._settings_meta())
            data["_meta"]["nazwa"] = name
            data["_meta"]["klucze_api"] = "pominięte"
            ok, msg = self._write_json(os.path.join(PRESET_DIR, _safe_name(name) + SETTINGS_EXT), data)
            self._log("Preset: %s" % msg)
            self._refresh_settings_window()
        except Exception as e:
            self._log("Preset: %s" % e)

    def _preset_delete(self, path):
        try:
            os.remove(path)
            self._log("Usunięto preset: %s" % os.path.basename(path))
            self._refresh_settings_window()
        except Exception as e:
            self._log("Preset: %s" % e)

    # ----------------------------------------------------------------- okno
    def _open_settings_window(self):
        if getattr(self, "_settings_win", None) is not None:
            try:
                if self._settings_win.winfo_exists():
                    self._settings_win.lift()
                    return
            except Exception:
                pass
        win = ctk.CTkToplevel(self)
        self._settings_win = win
        win.title("Ustawienia — zapis i wczytanie")
        win.geometry("680x630")
        win.configure(fg_color=BG)
        win.protocol("WM_DELETE_WINDOW", lambda: (setattr(self, "_settings_win", None), win.destroy()))

        ctk.CTkLabel(win, text="Ustawienia", font=ctk.CTkFont(size=17, weight="bold"),
                     text_color=TEXT).pack(anchor="w", padx=18, pady=(16, 2))
        ctk.CTkLabel(win, text="Cały stan aplikacji (obraz, kadr, efekty, dźwięk, oś czasu, "
                               "AI, mowa) do pliku JSON. Presety lądują w folderze presets/.",
                     font=ctk.CTkFont(size=11), text_color=MUTED, wraplength=560,
                     justify="left").pack(anchor="w", padx=18)

        body = ctk.CTkFrame(win, fg_color=CARD, corner_radius=14, border_width=1, border_color=LINE)
        body.pack(fill="both", expand=True, padx=16, pady=12)

        theme_row = ctk.CTkFrame(body, fg_color=CARD2, corner_radius=10)
        theme_row.pack(fill="x", padx=14, pady=(14, 5))
        ctk.CTkLabel(theme_row, text="Appearance theme", font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=TEXT).pack(side="left", padx=12, pady=10)
        theme_ids = list(getattr(sys.modules.get("__main__"), "THEME_IDS", ["obsidian"]))
        theme_names = list(getattr(sys.modules.get("__main__"), "THEME_NAMES", ["Obsidian"]))
        current_id = str((self.CFG.get("ui") or {}).get("theme", "obsidian"))
        current_name = theme_names[theme_ids.index(current_id)] if current_id in theme_ids else "Obsidian"
        ctk.CTkOptionMenu(theme_row, values=theme_names, width=190, command=self._change_theme,
                          **OPTION_MENU).pack(side="right", padx=10, pady=8)
        # Set after construction so CustomTkinter keeps the selected theme name.
        for widget in theme_row.winfo_children():
            if isinstance(widget, ctk.CTkOptionMenu):
                widget.set(current_name)

        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=(14, 4))
        ctk.CTkButton(row, text="💾  Zapisz do pliku…", width=170,
                      command=self._save_settings_to_file, **PRIMARY).pack(side="left", padx=3)
        ctk.CTkButton(row, text="📂  Wczytaj z pliku…", width=170,
                      command=self._load_settings_from_file, **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row, text="Ctrl+S", width=80,
                      command=self._save_settings_now, **GHOST).pack(side="left", padx=3)

        row2 = ctk.CTkFrame(body, fg_color="transparent")
        row2.pack(fill="x", padx=14, pady=(6, 2))
        ctk.CTkLabel(row2, text="Szybki preset:", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="left")
        self.ent_preset = ctk.CTkEntry(row2, width=210, fg_color=CARD2, border_color=LINE,
                                       text_color=TEXT, placeholder_text="np. spotkanie")
        self.ent_preset.pack(side="left", padx=8)
        ctk.CTkButton(row2, text="Zapisz preset", width=110,
                      command=self._preset_save_named, **GHOST).pack(side="left", padx=3)

        ctk.CTkLabel(body, text="Zapisane presety:", font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=MUTED).pack(anchor="w", padx=18, pady=(10, 2))
        self.preset_box = ctk.CTkScrollableFrame(body, label_text="", fg_color=CARD2,
                                                  corner_radius=12, height=170)
        self.preset_box.pack(fill="both", expand=True, padx=14, pady=(0, 6))
        self._refresh_settings_window()

        row3 = ctk.CTkFrame(body, fg_color="transparent")
        row3.pack(fill="x", padx=14, pady=(0, 10))
        self.var_autosave = ctk.BooleanVar(value=bool((self.CFG.get("ui") or {}).get("autosave", True)))
        ctk.CTkCheckBox(row3, text="Auto-zapis do config.json przy zamknięciu",
                        variable=self.var_autosave, font=ctk.CTkFont(size=11),
                        command=self._on_autosave_toggle).pack(side="left", padx=4)
        ctk.CTkButton(row3, text="Przywróć ustawienia fabryczne", width=170,
                      command=self._reset_defaults, **GHOST).pack(side="right", padx=4)
        ctk.CTkButton(row3, text="🔑  Klucze API i prywatność", width=170,
                      command=self._goto_net_tab, **GHOST).pack(side="right", padx=4)
        self.lbl_cfgpath = ctk.CTkLabel(win, text="", font=ctk.CTkFont(size=10), text_color=DIM,
                                        wraplength=580, justify="left")
        self.lbl_cfgpath.pack(anchor="w", padx=18, pady=(0, 10))
        try:
            extra = ""
            try:
                if HAS_NET:
                    nn = self._net_cfg()
                    if nn.get("provider") == "openai":
                        extra = "   •   klucze: TTS %s / AI %s (w presetach wycinane)" % (
                            NET.mask(nn.get("key_tts")), NET.mask(nn.get("key_ai")))
                    else:
                        extra = "   •   klucze: brak — pełny offline"
            except Exception:
                pass
            self.lbl_cfgpath.configure(text="config: %s   •   presety: %s%s" % (
                self._config_path(), PRESET_DIR, extra))
        except Exception:
            self.lbl_cfgpath.configure(text="presety: %s" % PRESET_DIR)

    def _goto_net_tab(self):
        try:
            self.tabs.set("Prywatność")
        except Exception:
            pass
        try:
            if self._settings_win is not None:
                self._settings_win.destroy()
                self._settings_win = None
        except Exception:
            pass
        self._open_privacy_info()

    def _on_autosave_toggle(self):
        try:
            self.CFG.setdefault("ui", {})["autosave"] = bool(self.var_autosave.get())
            # Persist the switch itself even when it has just been turned off;
            # previously close-time autosave saw False and discarded the change.
            main = sys.modules.get("__main__")
            if main and hasattr(main, "save_config"):
                main.save_config(self.CFG)
            self._log("Auto-zapis: %s." % ("włączony" if self.var_autosave.get() else "wyłączony"))
        except Exception:
            pass

    def _refresh_settings_window(self):
        try:
            box = getattr(self, "preset_box", None)
            if box is None or not box.winfo_exists():
                return
            for w in box.winfo_children():
                w.destroy()
            files = self._preset_files()
            if not files:
                ctk.CTkLabel(box, text="Jeszcze nic nie zapisane — wpisz nazwę wyżej i kliknij „Zapisz preset”.",
                             text_color=MUTED, font=ctk.CTkFont(size=11),
                             wraplength=430, justify="left").pack(padx=8, pady=10)
                return
            for p in files:
                row = ctk.CTkFrame(box, fg_color="transparent")
                row.pack(fill="x", padx=4, pady=2)
                label = os.path.splitext(os.path.basename(p))[0]
                when = ""
                try:
                    d, _ = self._read_json(p)
                    if d:
                        label = (d.get("_meta") or {}).get("nazwa") or label
                        when = (d.get("_meta") or {}).get("kiedy", "")
                except Exception:
                    pass
                ctk.CTkButton(row, text="%s%s" % (label, ("   (%s)" % when) if when else ""),
                              anchor="w", height=28, font=ctk.CTkFont(size=11),
                              fg_color="transparent", text_color=TEXT, hover_color=CARD2,
                              border_width=1, border_color=LINE, corner_radius=8,
                              command=lambda p=p: self._apply_settings_file(p)).pack(
                                  side="left", fill="x", expand=True, padx=(0, 4))
                ctk.CTkButton(row, text="✕", width=28, height=28, font=ctk.CTkFont(size=11),
                              command=lambda p=p: self._preset_delete(p),
                              **GHOST).pack(side="left", padx=2)
        except Exception:
            pass

    def _reset_defaults(self):
        try:
            if not messagebox.askyesno(
                    "Ustawienia fabryczne",
                    "Przywrócić wszystkie ustawienia do wartości domyślnych?\n\n"
                    "Lista mediów i kadry zdjęć zostają (to Twoje pliki).\n"
                    "UWAGA: klucze API zostaną usunięte (tryb wraca na offline)."):
                return
            A = _app_module()
            if A is None:
                self._log("Nie mam listy ustawień domyślnych (moduł app nie znaleziony).")
                return
            fresh = json.loads(json.dumps(A.DEFAULT_CONFIG))
            keep = {}
            try:
                keep["frames"] = (self.CFG.get("video") or {}).get("frames", {})
            except Exception:
                pass
            fresh["video"].update(keep)
            self._apply_cfg(fresh)
            try:
                self._apply_net(fresh.get("net"), {})   # reset = takze wyzerowane klucze
            except Exception:
                pass
            self._log("Przywrócono ustawienia domyślne.")
        except Exception as e:
            self._log("Ustawienia: %s" % e)

    # ------------------------------------------------- wczytanie → UI + silniki
    def _apply_cfg(self, data):
        """Wduszaj sekcje z pliku ustawień do CFG, widgetów i silników. Zwraca liczbę sekcji."""
        n = 0
        for section in ("device_names", "video", "audio", "ai", "tts", "ui", "net"):
            if isinstance(data.get(section), dict):
                if section != "net":      # „net” ma własną ścieżkę (patrz _apply_net)
                    self.CFG.setdefault(section, {}).update(data[section])
                n += 1
        v = data.get("video") or {}
        a = data.get("audio") or {}

        def lab(mapping, key, default=""):
            """Etykieta pozycji slownika: dict z 'label' (formaty) albo wartosc-bedaca-nazwa."""
            try:
                it = (mapping or {}).get(key)
                if isinstance(it, dict):
                    return it.get("label", default) or default
                if isinstance(it, str):
                    return it
                return default
            except Exception:
                return default

        # ---- obraz / kadr / efekty (widgety + handler, żeby silnik był spójny)
        try:
            if v:
                if "format_id" in v:
                    self._v14_set("var_format", lab(PHONE_FORMATS, v.get("format_id"), ""))
                    self._on_format_change(self.var_format.get())
                if "orientation" in v:
                    want = "Poziomo" if v.get("orientation") == "landscape" else "Pionowo"
                    if self.video and self.video.orientation != ("landscape" if want == "Poziomo" else "portrait"):
                        self.var_orient.set(want)
                        self._on_orient_seg(want)
                if "backend" in v:
                    self._v14_set("var_backend", BACKEND_LABELS.get(v.get("backend"), "Auto"))
                    self._on_backend_change(self.var_backend.get())
                if "fps" in v:
                    self._v14_set("var_fps", str(int(v.get("fps") or 30)))
                    self._on_fps_change(self.var_fps.get())
                if "fit_mode" in v:
                    self._v14_set("var_fit", FIT_MODES.get(v.get("fit_mode"), "Wypełnij (przytnij brzegi)"))
                    self._on_fit_change(self.var_fit.get())
                if "filter" in v:
                    self._v14_set("var_filter", FILTERS.get(v.get("filter"), "Normalny"))
                    self._on_filter_change(self.var_filter.get())
                if "slideshow_mode" in v:
                    self._v14_set("var_mode", SLIDESHOW_MODES.get(v.get("slideshow_mode"), "Auto"))
                    self._on_mode_change(self.var_mode.get())
                if "slideshow_interval" in v:
                    self._v14_set("var_interval", str(v.get("slideshow_interval")))
                    self._on_interval_change(str(v.get("slideshow_interval")))
                if "transition" in v:
                    self._v14_set("var_trans", TRANSITIONS.get(v.get("transition"), "Przenikanie"))
                    self._on_trans_change(self.var_trans.get())
                if "mirror" in v and self.video:
                    self.video.mirror = bool(v.get("mirror"))
                if "rotate" in v and self.video:
                    self.video.rotate = int(v.get("rotate") or 0)
                for varname, key in (("var_mirror", "mirror"), ("var_rec", "overlay_rec"),
                                      ("var_ts", "overlay_timestamp"), ("var_brand", "overlay_brand"),
                                      ("var_batt", "overlay_battery"), ("var_shake", "effect_shake"),
                                      ("var_grain", "effect_grain"), ("var_vig", "effect_vignette"),
                                      ("var_af", "effect_autofocus")):
                    if key in v:
                        self._v14_set_bool(varname, v.get(key))
                if "effect_shake_amount" in v:
                    self._v14_set_sld("sld_shakeamt", "val_shakeamt", float(v.get("effect_shake_amount") or 0),
                                      lambda x: "%.1f" % x)
                if "effect_grain_amount" in v:
                    self._v14_set_sld("sld_grainamt", "val_grainamt", float(v.get("effect_grain_amount") or 0),
                                      lambda x: "%.0f" % x)
                self._on_mirror()
                self._on_fx()
                self._on_fx_sliders()
                for sl, key, fmt in (("sld_zoom", "zoom", "%.2f×"), ("sld_panx", "pan_x", "%+.2f"),
                                     ("sld_pany", "pan_y", "%+.2f")):
                    if key in v:
                        self._v14_set_sld(sl, "val_" + sl.split("_")[1], float(v.get(key) or 0),
                                          (lambda x, f=fmt: f % x))
                if "frames" in v and self.video is not None:
                    try:
                        self.video.frame_memory = dict(v.get("frames") or {})
                    except Exception:
                        pass
                if "loop_video" in v:
                    self._v14_set_bool("var_vloop", bool(v.get("loop_video")))
                    if self.video:
                        self.video.set_loop(bool(v.get("loop_video")))
                if "loop_blend" in v:
                    blend = float(v.get("loop_blend") or 0.0)
                    if self.video:
                        self.video.set_loop_blend(blend)
                    try:
                        self.sld_blend.set(max(0.0, min(1.2, blend)))
                        self._on_v14_blend(blend)
                    except Exception:
                        pass
        except Exception as e:
            self._log("Ustawienia (obraz): %s" % e)

        # ---- dzwiek
        try:
            if a:
                if "profile" in a:
                    self._v14_set("var_profile", a.get("profile"))
                    self._on_profile()
                for sl, key in (("sld_volume", "volume"), ("sld_noise", "noise_level"),
                                ("sld_event", "event_rate"), ("sld_bass", "bass"),
                                ("sld_breath", "breath_level")):
                    if key in a:
                        self._v14_set_sld(sl, "val_" + sl.split("_")[1], float(a.get(key) or 0),
                                          lambda x: "%d%%" % int(x * 100))
                if "breath_rate" in a:
                    self._v14_set_sld("sld_brate", "val_brate", float(a.get("breath_rate") or 13),
                                      lambda x: "%d /min" % int(x))
                if "breath_on" in a:
                    self._v14_set_bool("var_breath", bool(a.get("breath_on")))
                if "cable_only" in a:
                    self._v14_set_bool("var_cable_only", bool(a.get("cable_only")))
                self._on_audio_sliders()
                self._on_breath_toggle()
                self._on_breath_level()
                self._on_breath_rate()
                if "output_device_name" in a:
                    try:
                        self.var_outdev.set(a.get("output_device_name") or "(domyślne)")
                    except Exception:
                        pass
                    self._refresh_devices_combo()
                if "music_gain" in a:
                    self._v14_set_sld("sld_music", "val_music", float(a.get("music_gain") or 0),
                                      lambda x: "%d%%" % int(x * 100))
                    self._on_music_gain()
                if "music_loop" in a:
                    self._v14_set_bool("var_music_loop", bool(a.get("music_loop")))
                    self._on_music_loop()
                if "monitor_gain" in a:
                    self._v14_set_sld("sld_mon_gain", "val_mon_gain",
                                      float(a.get("monitor_gain") or 0), lambda x: "%d%%" % int(x * 100))
                if "monitor_device_name" in a:
                    self._v14_set("var_mon_dev", a.get("monitor_device_name") or "(domyślne)")
                if "monitor_on" in a:
                    want = bool(a.get("monitor_on"))
                    if want != bool(getattr(self, "_monitor_on", False)):
                        try:
                            self.var_monitor.set(want)
                            self._toggle_monitor()
                        except Exception:
                            pass
                # playlista audio (pliki z tej maszyny; brakujace pomijamy)
                files = [p for p in (a.get("music_files") or []) if p]
                if files and self.timeline is not None:
                    try:
                        self.timeline.clear()
                        self._music_load(files)
                    except Exception:
                        pass
        except Exception as e:
            self._log("Ustawienia (dźwięk): %s" % e)

        # ---- AI + mowa
        try:
            ai = data.get("ai") or {}
            if ai:
                if "prompt" in ai:
                    try:
                        self.txt_prompt.delete("1.0", "end")
                        self.txt_prompt.insert("1.0", ai.get("prompt") or "")
                    except Exception:
                        pass
                if "quality" in ai:
                    self._v14_set("var_ai_quality", ai.get("quality") or "1080p")
                    self._on_ai_quality()
                if "photos" in ai:
                    try:
                        self.ai_photos = [p for p in (ai.get("photos") or []) if p]
                        self._refresh_ai_photos()
                    except Exception:
                        pass
        except Exception as e:
            self._log("Ustawienia (AI): %s" % e)
        try:
            t = data.get("tts") or {}
            if t:
                if "text" in t:
                    self.txt_tts.delete("1.0", "end")
                    self.txt_tts.insert("1.0", t.get("text") or "")
                if "rate" in t:
                    self._v14_set_sld("sld_tts_rate", "val_tts_rate", float(t.get("rate") or 0),
                                      lambda x: "%+d" % int(round(x)))
                if "volume" in t:
                    self._v14_set_sld("sld_tts_vol", "val_tts_vol",
                                      float(t.get("volume") or 90) / 100.0,
                                      lambda x: "%d%%" % int(x * 100))
                self._on_tts_opts()
                if "voice" in t:
                    self._tts_voice = t.get("voice") or ""
                    try:
                        for i, (vid, lab2) in enumerate(self._tts_voices):
                            if vid == self._tts_voice:
                                self.var_tts_voice.set(lab2)
                                break
                    except Exception:
                        pass
        except Exception as e:
            self._log("Ustawienia (mowa): %s" % e)

        # ---- motyw + reszta UI
        try:
            ui = data.get("ui") or {}
            if ui.get("theme"):
                ctk.set_appearance_mode(str(ui["theme"]))
            if "autosave" in ui:
                self._v14_set_bool("var_autosave", bool(ui.get("autosave")))
        except Exception:
            pass
        try:
            self._sync_frame_ui()
            self._refresh_playlist_ui()
            self._update_leds()
            self._v14_tick(force=True)
            self._refresh_settings_window()
        except Exception:
            pass
        return n

    # ------------------------------------------------------ male helpery UI
    def _apply_net(self, net, live=None):
        """Wczytuje sekcję „net” do widgetów.

        Preset/plik NIE zawiera kluczy -> wtedy zostawiamy to, co już mamy
        w tej sesji (nie chcemy, żeby wczytanie cudzego pliku zerowało klucz,
        ani żeby cudzy plik podmknął nam własny token)."""
        try:
            src = dict(live or {})
            src.update({k: v for k, v in (net or {}).items()})
        except Exception:
            return
        live = live or {}
        for kk in ("key_tts", "key_ai"):
            if not str(src.get(kk) or "").strip():
                src[kk] = live.get(kk, "")      # plik bez klucza != skasowanie naszego
        try:
            self.CFG["net"] = dict(src)
        except Exception:
            pass
        pairs = [("ent_net_base", "base_url"), ("ent_net_key_tts", "key_tts"),
                 ("ent_net_key_ai", "key_ai"), ("ent_net_tts_model", "tts_model"),
                 ("ent_net_ai_model", "ai_model"), ("ent_net_timeout", "timeout_s")]
        for attr, key in pairs:
            w = getattr(self, attr, None)
            if w is None:
                continue
            try:
                v = src.get(key, "")
                w.delete("0", "end")
                w.insert("0", ("%g" % float(v)) if attr == "ent_net_timeout" else str(v or ""))
            except Exception:
                pass
        try:
            self.var_net_provider.set(PROVIDER_LABELS.get(src.get("provider"), PROVIDER_LABELS["offline"]))
        except Exception:
            pass
        for attr, key, kind in (("var_net_ctts", "consent_tts", "b"), ("var_net_cai", "consent_ai", "b"),
                                ("var_net_photos", "ai_send_photos", "b"),
                                ("var_net_remember", "remember_keys", "b"),
                                ("var_net_voice", "tts_voice", "s")):
            v = getattr(self, attr, None)
            if v is None:
                continue
            try:
                v.set(bool(src.get(key)) if kind == "b" else str(src.get(key) or "alloy"))
            except Exception:
                pass
        self._on_net_changed()

    def _v14_set(self, varname, value):
        try:
            if value in (None, ""):
                return
            getattr(self, varname).set(value)
        except Exception:
            pass

    def _v14_set_bool(self, varname, value):
        try:
            getattr(self, varname).set(bool(value))
        except Exception:
            pass

    def _v14_set_sld(self, sldname, valname, value, fmt=None):
        try:
            s = getattr(self, sldname)
            s.set(float(value))
            if valname and fmt is not None:
                getattr(self, valname).configure(text=fmt(float(value)))
        except Exception:
            pass

    # --------------------------------------------------------- zapis przy exit
    def _v14_on_close(self):
        """Dopisuje to, co zna tylko v1.4 (pętla + TTS) — reszta jest w app/ui_v13."""
        try:
            if self.video is not None:
                self.CFG.setdefault("video", {})["loop_video"] = bool(self.video.loop_video)
                self.CFG.setdefault("video", {})["loop_blend"] = float(self.video.loop_blend)
        except Exception:
            pass
        try:
            self.CFG["tts"] = {"text": (self.txt_tts.get("1.0", "end").strip()[:4000]
                                        if hasattr(self, "txt_tts") else ""),
                               "voice": self._tts_voice, "rate": float(self._tts_rate),
                               "volume": float(self._tts_volume)}
        except Exception:
            pass
        try:
            self.CFG.setdefault("ui", {})["autosave"] = bool(self.var_autosave.get())
        except Exception:
            pass
        try:
            self._net_before_save()      # remember_keys=0 → klucze nie trafią na dysk
        except Exception:
            pass
