# -*- coding: utf-8 -*-
"""
vStudio — wykrywanie i pomoc przy urządzeniach wirtualnych.

Windows:
  KAMERA   = OBS Virtual Camera (z OBS Studio) → zmiana nazwy w rejestrze
             na wybraną nazwę (domyślnie "vStudio") skryptem scripts/rename_devices.ps1
  MIKROFON = VB-CABLE ("CABLE Input" → gramy, "CABLE Output" → słuchają nas)
             → zmiana nazwy urządzenia "CABLE Output" na wybraną nazwę (domyślnie "vStudio").

Ten moduł NIC nie instaluje sam — tylko wykrywa stan, podpowiada i umożliwia
zmianę oraz wybór nazwy kamery wirtualnej.
"""
import os
import shutil
import subprocess
import sys
import threading

CAMERA_NAME = "vStudio"
MIC_NAME = "vStudio"

OBS_GUID = "{A3FCE0F5-3493-419F-958A-ABA1250EC20B}"
CAT_GUID = "{860BB310-5D01-11d0-BD3B-00A0C911CE86}"


def is_windows():
    return sys.platform.startswith("win")


def get_target_camera_name():
    """Zwraca bieżącą docelową nazwę kamery wirtualnej."""
    global CAMERA_NAME
    return CAMERA_NAME


def set_target_camera_name(name: str):
    """Ustawia docelową nazwę kamery wirtualnej w aplikacji."""
    global CAMERA_NAME, MIC_NAME
    cleaned = (name or "").strip()
    if cleaned:
        CAMERA_NAME = cleaned
        MIC_NAME = cleaned
    return CAMERA_NAME


def check_obs_installed():
    """Czy OBS Studio jest zainstalowane?"""
    if not is_windows():
        return shutil.which("obs") is not None
    candidates = [
        r"C:\Program Files\obs-studio\bin\64bit\obs64.exe",
        r"C:\Program Files (x86)\obs-studio\bin\32bit\obs.exe",
    ]
    for c in candidates:
        if os.path.isfile(c):
            return True
    try:
        import winreg
        for hive, path in [
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        ]:
            try:
                with winreg.OpenKey(hive, path) as k:
                    for i in range(winreg.QueryInfoKey(k)[0]):
                        try:
                            name = winreg.EnumKey(k, i)
                            if "obs" in name.lower():
                                return True
                        except OSError:
                            break
            except OSError:
                continue
    except Exception:
        pass
    return False


def check_obs_virtualcam_registered():
    """Czy sterownik wirtualnej kamery OBS jest zarejestrowany (CLSID w rejestrze)?"""
    if not is_windows():
        return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            rf"SOFTWARE\Classes\CLSID\{OBS_GUID}"):
            return True
    except OSError:
        return False


def _open_key(hive, path):
    """Otwórz klucz rejestru (lub None). hive: 'HKLM' lub 'HKCU'."""
    import winreg
    root = winreg.HKEY_LOCAL_MACHINE if hive == "HKLM" else winreg.HKEY_CURRENT_USER
    try:
        return winreg.OpenKey(root, path)
    except OSError:
        return None


def get_obs_virtualcam_name():
    """Odczytaj aktualną nazwę wirtualnej kamery OBS (sprawdza wszystkie widoki rejestru)."""
    if not is_windows():
        return ""
    import winreg
    paths = [
        ("HKLM", rf"SOFTWARE\Classes\CLSID\{{860BB310-5D01-11d0-BD3B-00A0C911CE86}}\Instance\{OBS_GUID}"),
        ("HKLM", rf"SOFTWARE\Classes\WOW6432Node\CLSID\{{860BB310-5D01-11d0-BD3B-00A0C911CE86}}\Instance\{OBS_GUID}"),
        ("HKLM", rf"SOFTWARE\WOW6432Node\Classes\CLSID\{{860BB310-5D01-11d0-BD3B-00A0C911CE86}}\Instance\{OBS_GUID}"),
        ("HKCU", rf"SOFTWARE\Classes\CLSID\{{860BB310-5D01-11d0-BD3B-00A0C911CE86}}\Instance\{OBS_GUID}"),
    ]
    for hive, path in paths:
        k = _open_key(hive, path)
        if k is None:
            continue
        try:
            val, _ = winreg.QueryValueEx(k, "FriendlyName")
            if val:
                return str(val)
        except OSError:
            pass
        finally:
            try:
                winreg.CloseKey(k)
            except Exception:
                pass
    return ""


def _registry_dshow_cameras():
    """Nazwy kamer z rejestru DirectShow (działa bez pygrabbera)."""
    if not is_windows():
        return []
    import winreg
    found = []
    seen = set()
    roots = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Classes\CLSID\{860BB310-5D01-11d0-BD3B-00A0C911CE86}\Instance"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Classes\WOW6432Node\CLSID\{860BB310-5D01-11d0-BD3B-00A0C911CE86}\Instance"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Classes\CLSID\{860BB310-5D01-11d0-BD3B-00A0C911CE86}\Instance"),
    ]
    for root, path in roots:
        try:
            with winreg.OpenKey(root, path) as k:
                n = winreg.QueryInfoKey(k)[0]
                for i in range(n):
                    try:
                        sub = winreg.EnumKey(k, i)
                    except OSError:
                        break
                    try:
                        with winreg.OpenKey(k, sub) as sk:
                            val, _ = winreg.QueryValueEx(sk, "FriendlyName")
                            if val and str(val) not in seen:
                                seen.add(str(val))
                                found.append(str(val))
                    except OSError:
                        continue
        except OSError:
            continue
    return found


def _pnp_cameras():
    """Kamery znane Windows (PnP), nawet gdy DirectShow jeszcze ich nie ma.

    Świeżo podłączona, wyłączona albo zajęta kamera potrafi nie mieć wpisu w
    klasie DirectShow, a system i tak ją widzi. Dopisanie jej do listy jest
    tym, co odróżnia „nie ma żadnej kamery" od „jest, tylko chwilowo zajęta".
    """
    if not is_windows():
        return []
    script = (
        "Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | "
        "Where-Object { $_.Class -in @('Camera','Image') } | "
        "Select-Object -ExpandProperty FriendlyName"
    )
    try:
        done = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True, text=True, timeout=9,
            creationflags=0x08000000,
        )
    except Exception:
        return []
    return [line.strip() for line in (done.stdout or "").splitlines() if line.strip()]


def list_dshow_cameras():
    """Wylistuj WSZYSTKIE kamery, które widzi ten komputer (nazwy przyjazne).

    Kolejność ma znaczenie: pygrabber zwraca urządzenia w tej samej kolejności
    DirectShow, której używa OpenCV i emulator Androida, więc nazwa i indeks
    opisują tę samą kamerę. Rejestr i PnP tylko dopisują to, czego pygrabber
    (albo brak pygrabbera) nie pokazał — dzięki temu lista nigdy nie jest
    pusta, gdy kamera naprawdę istnieje.
    """
    names = []
    if is_windows():
        try:
            from pygrabber.dshow_graph import FilterGraph
            names.extend(FilterGraph().get_input_devices())
        except Exception:
            pass
    names.extend(_registry_dshow_cameras())
    names.extend(_pnp_cameras())
    result = []
    seen = set()
    for name in names:
        text = str(name or "").strip()
        if text and text.lower() not in seen:
            seen.add(text.lower())
            result.append(text)
    return result


def get_selectable_camera_names():
    """Zwraca listę nazw kamer do wyboru w UI: systemowe kamery + gotowe szablony."""
    presets = ["vStudio", "OBS Virtual Camera", "Unity Video Capture", "Realme 12 Pro"]
    system_cams = list_dshow_cameras()
    result = []
    seen = set()
    for name in [CAMERA_NAME] + presets + system_cams:
        s = (name or "").strip()
        if s and s not in seen:
            seen.add(s)
            result.append(s)
    return result


def check_frame_server_mode():
    """EnableFrameServerMode (Windows 11) — None=nie ustawione, True/False."""
    if not is_windows():
        return None
    import winreg
    for path in (r"SOFTWARE\Microsoft\Windows Media Foundation\Platform",
                 r"SOFTWARE\WOW6432Node\Microsoft\Windows Media Foundation\Platform"):
        k = _open_key("HKLM", path)
        if k is None:
            continue
        try:
            val, _ = winreg.QueryValueEx(k, "EnableFrameServerMode")
            try:
                winreg.CloseKey(k)
            except Exception:
                pass
            return bool(val)
        except OSError:
            try:
                winreg.CloseKey(k)
            except Exception:
                pass
    return None


def find_virtualcam_install_bat():
    """Ścieżka do virtualcam-install.bat (re-rejestracja sterownika) lub ''."""
    if not is_windows():
        return ""
    for base in (r"C:\Program Files\obs-studio", r"C:\Program Files (x86)\obs-studio"):
        bat = os.path.join(base, "data", "obs-plugins", "win-dshow", "virtualcam-install.bat")
        if os.path.isfile(bat):
            return bat
    return ""


def check_cable_installed():
    """Czy VB-CABLE jest (po nazwach urządzeń audio)?"""
    try:
        from audio_engine import PhoneNoiseEngine
        for _, name in (PhoneNoiseEngine.list_output_devices()
                        + PhoneNoiseEngine.list_input_devices()):
            low = name.lower()
            if "cable" in low and "vb-audio" in low.replace(" ", "") or \
               ("cable" in low and "vb" in low):
                return True
            if "vb-audio" in low or "virtual cable" in low:
                return True
    except Exception:
        pass
    return False


def detect_vcam_backends():
    """Wykryj dostępne silniki kamery: {'obs': bool, 'unity': bool}."""
    obs = check_obs_virtualcam_registered()
    try:
        unity = any("unity" in c.lower() for c in list_dshow_cameras())
    except Exception:
        unity = False
    return {"obs": obs, "unity": unity}


def list_cameras_opencv(max_index=6):
    """Lista kamer widocznych dla OpenCV (indeksy które da się otworzyć)."""
    found = []
    try:
        import cv2
        try:
            cv2.utils.logging.setLogLevel(cv2.utils.logging.LOG_LEVEL_SILENT)
        except Exception:
            pass
        for i in range(max_index):
            try:
                cap = cv2.VideoCapture(i, cv2.CAP_DSHOW) if is_windows() else cv2.VideoCapture(i)
                if cap is not None and cap.isOpened():
                    found.append(i)
                try:
                    cap.release()
                except Exception:
                    pass
            except Exception:
                continue
        try:
            cv2.utils.logging.setLogLevel(cv2.utils.logging.LOG_LEVEL_WARNING)
        except Exception:
            pass
    except Exception:
        pass
    return found


def devices_status_report(target_camera_name=None):
    """Zwraca listę (nazwa, ok: bool, opis) do wyświetlenia w zakładce Urządzenia."""
    global CAMERA_NAME
    cam_name = (target_camera_name or CAMERA_NAME or "vStudio").strip()
    rows = []
    obs = check_obs_installed()
    rows.append(("OBS Studio", obs,
                 "zainstalowane" if obs else "BRAK — pobierz z obsproject.com (darmowe)"))
    reg = check_obs_virtualcam_registered()
    rows.append(("Sterownik OBS Virtual Camera", reg,
                 "zarejestrowany" if reg else "nie znaleziono — uruchom raz OBS → Start Virtual Camera"))
    backs = detect_vcam_backends()
    rows.append(("Silnik Unity Video Capture", backs["unity"],
                 "wykryty (aplikacja może go użyć)" if backs["unity"]
                 else "nie wykryto (opcjonalny — https://github.com/schellingb/UnityCapture)"))
    nm = get_obs_virtualcam_name()
    if nm:
        ok = nm.strip().lower() == cam_name.lower()
        rows.append(("Nazwa kamery w systemie", ok,
                     f'widnieje jako "{nm}"' + (" (zgodna z wybraną)" if ok else f' — kliknij "Zmień nazwę", aby ustawić "{cam_name}"')))
    else:
        rows.append(("Nazwa kamery w systemie", False,
                     f'nie znaleziono wpisu OBS — kliknij "Zmień nazwę w systemie", aby zarejestrować jako "{cam_name}"'))
    cams = list_dshow_cameras()
    has_target = any(c.strip().lower() == cam_name.lower() for c in cams)
    rows.append(("Kamery DirectShow (widzą je programy)", has_target,
                 ("★ " if has_target else "") + (", ".join(f'"{c}"' for c in cams)
                  if cams else "nie znaleziono żadnych — OBS nie zarejestrował kamery!")))
    fs = check_frame_server_mode()
    rows.append(("Windows 11 FrameServer (EnableFrameServerMode)", fs is True,
                 "włączony" if fs is True else
                 ("WYŁĄCZONY — nowe aplikacje mogą nie widzieć kamery (naprawia skrypt zmiany nazwy)"
                  if fs is False else "nie ustawiony (starszy Windows lub brak klucza)")))
    bat = find_virtualcam_install_bat()
    rows.append(("Naprawa rejestracji (virtualcam-install.bat)", bool(bat),
                 bat if bat else "nie znaleziono — przeinstaluj OBS Studio"))
    cable = check_cable_installed()
    rows.append(("VB-CABLE (wirtualny mikrofon)", cable,
                 "wykryto" if cable else "BRAK — pobierz z vb-audio.com (darmowe)"))
    try:
        from audio_engine import PhoneNoiseEngine
        idx, name = PhoneNoiseEngine.find_cable_device()
        rows.append(("Wyjście audio aplikacji", idx is not None,
                     f'"{name}"' if idx is not None else "nie znaleziono CABLE Input — dźwięk pójdzie na głośniki (tryb testowy)"))
    except Exception:
        rows.append(("Wyjście audio aplikacji", False, "brak modułu audio (sounddevice)"))
    try:
        import pyvirtualcam  # noqa
        rows.append(("pyvirtualcam (most do OBS)", True, "gotowe do nadawania"))
    except Exception:
        rows.append(("pyvirtualcam (most do OBS)", False, "pip install pyvirtualcam"))
    # Host inputs: names only. Opening every index here would fight the live
    # camera for the device and made this report both slow and wrong.
    hosts = list_dshow_cameras()
    rows.append(("Kamery wykryte na tym komputerze", bool(hosts),
                 ", ".join(f'"{c}"' for c in hosts) if hosts
                 else "nie wykryto żadnej kamery hosta — podłącz kamerę i kliknij Skanuj"))
    if hosts:
        rows.append(("Jak wybrać kamerę", True,
                     'Wejście kamery w panelu obok → wybierz pozycję "● nazwa" (działa) albo "○ nazwa" (wykryta, chwilowo niedostępna)'))
    return rows


def set_camera_name_in_registry_direct(new_name: str):
    """Próbuje bezpośrednio zapisać nową nazwę w rejestrze Windows (jeśli są uprawnienia)."""
    if not is_windows():
        return False, "Dostępne tylko na Windows."
    import winreg
    success_count = 0
    targets = [
        ("HKLM", rf"SOFTWARE\Classes\CLSID\{OBS_GUID}", ""),
        ("HKLM", rf"SOFTWARE\Classes\WOW6432Node\CLSID\{OBS_GUID}", ""),
        ("HKLM", rf"SOFTWARE\WOW6432Node\Classes\CLSID\{OBS_GUID}", ""),
        ("HKCU", rf"SOFTWARE\Classes\CLSID\{OBS_GUID}", ""),
        ("HKLM", rf"SOFTWARE\Classes\CLSID\{CAT_GUID}\Instance\{OBS_GUID}", "FriendlyName"),
        ("HKLM", rf"SOFTWARE\Classes\WOW6432Node\CLSID\{CAT_GUID}\Instance\{OBS_GUID}", "FriendlyName"),
        ("HKLM", rf"SOFTWARE\WOW6432Node\Classes\CLSID\{CAT_GUID}\Instance\{OBS_GUID}", "FriendlyName"),
        ("HKCU", rf"SOFTWARE\Classes\CLSID\{CAT_GUID}\Instance\{OBS_GUID}", "FriendlyName"),
    ]
    for hive_str, path, value_name in targets:
        root = winreg.HKEY_LOCAL_MACHINE if hive_str == "HKLM" else winreg.HKEY_CURRENT_USER
        try:
            with winreg.CreateKey(root, path) as k:
                winreg.SetValueEx(k, value_name, 0, winreg.REG_SZ, new_name)
                success_count += 1
        except Exception:
            pass
    if success_count > 0:
        set_target_camera_name(new_name)
        return True, f"Zaktualizowano {success_count} kluczy rejestru bezpośrednio."
    return False, "Wymagane uprawnienia administratora (użyj skryptu UAC)."


def run_powershell_script(script_path, new_name=None):
    """Uruchom skrypt .ps1 z uprawnieniami administratora (Windows) z opcjonalną nową nazwą."""
    if not is_windows():
        return False, "Tylko Windows."
    if not os.path.isfile(script_path):
        return False, f"Nie znaleziono: {script_path}"
    
    arg_list = f"-NoProfile -ExecutionPolicy Bypass -File \"{script_path}\""
    if new_name:
        set_target_camera_name(new_name)
        arg_list += f" -NewName \"{new_name}\""

    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
           "-Command", f"Start-Process powershell -Verb RunAs -ArgumentList '{arg_list}' -Wait"]
    try:
        subprocess.Popen(cmd)
        target = f' na "{new_name}"' if new_name else ""
        return True, f"Uruchomiono konfigurator urządzeń (okno administratora){target}."
    except Exception as e:
        return False, str(e)


def run_diagnose_script(script_path, target_name=None):
    """Uruchom diagnozę kamery (zwykłe okno, bez administratora)."""
    if not is_windows():
        return False, "Tylko Windows."
    if not os.path.isfile(script_path):
        return False, f"Nie znaleziono: {script_path}"
    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script_path]
    if target_name:
        cmd += ["-TargetName", str(target_name)]
    try:
        subprocess.Popen(cmd, cwd=os.path.dirname(os.path.dirname(script_path)))
        return True, "Uruchomiono diagnozę — raport zapisze się w DIAGNOZA_KAMERY.txt."
    except Exception as e:
        return False, str(e)

# ---------------------------------------------------------------- Android bridge
# vStudio can also be opened directly, outside OctoBrowser. In that case it
# discovers the live Android Emulator through adb and adopts its AVD name,
# screen and media routing instead of continuing with a stale phone profile.
def _adb_candidates():
    """Return adb locations without opening a shell or trusting arbitrary text."""
    names = []
    found = shutil.which("adb")
    if found:
        names.append(found)
    homes = [os.environ.get("ANDROID_SDK_ROOT"), os.environ.get("ANDROID_HOME")]
    if is_windows():
        local = os.environ.get("LOCALAPPDATA", "")
        if local:
            homes.append(os.path.join(local, "Android", "Sdk"))
    else:
        homes.extend([os.path.expanduser("~/Android/Sdk"), os.path.expanduser("~/Library/Android/sdk")])
    exe = "adb.exe" if is_windows() else "adb"
    for home in homes:
        if home:
            names.append(os.path.join(home, "platform-tools", exe))
    return list(dict.fromkeys(p for p in names if p and os.path.isfile(p)))


def _adb(adb, args, timeout=4):
    try:
        done = subprocess.run([adb] + list(args), capture_output=True, text=True,
                              timeout=timeout, creationflags=(0x08000000 if is_windows() else 0))
        return (done.stdout or "").strip() if done.returncode == 0 else ""
    except Exception:
        return ""


def _avd_config(avd_name):
    """Read only the harmless AVD config fields needed for media status."""
    if not avd_name or any(c in avd_name for c in "\\/\0"):
        return {}
    avd_home = os.environ.get("ANDROID_AVD_HOME") or os.path.join(os.path.expanduser("~"), ".android", "avd")
    ini = os.path.join(avd_home, avd_name + ".avd", "config.ini")
    result = {}
    try:
        with open(ini, "r", encoding="utf-8", errors="replace") as stream:
            for raw in stream:
                if "=" not in raw:
                    continue
                key, value = raw.split("=", 1)
                if key.strip() in {"hw.camera.front", "hw.camera.back", "hw.audioInput", "hw.lcd.width", "hw.lcd.height", "octobrowser.deviceLabel"}:
                    result[key.strip()] = value.strip()
    except Exception:
        pass
    return result


def detect_running_android(preferred=""):
    """Describe the active Android Emulator, or None when no emulator is ready."""
    for adb in _adb_candidates():
        rows = _adb(adb, ["devices"]).splitlines()
        serials = [line.split()[0] for line in rows if line.startswith("emulator-") and "\tdevice" in line]
        devices = []
        for serial in serials:
            avd_name = _adb(adb, ["-s", serial, "emu", "avd", "name"]).splitlines()[0:1]
            avd_name = avd_name[0].strip() if avd_name else ""
            model = _adb(adb, ["-s", serial, "shell", "getprop", "ro.product.model"])
            manufacturer = _adb(adb, ["-s", serial, "shell", "getprop", "ro.product.manufacturer"])
            size = _adb(adb, ["-s", serial, "shell", "wm", "size"])
            match = __import__("re").search(r"(\d{3,5})x(\d{3,5})", size)
            config = _avd_config(avd_name)
            width = int(match.group(1)) if match else int(config.get("hw.lcd.width", 0) or 0)
            height = int(match.group(2)) if match else int(config.get("hw.lcd.height", 0) or 0)
            reported_label = " ".join(x for x in [manufacturer, model] if x).strip()
            configured_label = config.get("octobrowser.deviceLabel", "").strip()
            # The AVD config is Octo.su's selected handset identity. Prefer it
            # while a writable-system migration is still replacing Google's
            # temporary sdk_gphone* properties; never show that generic model
            # as if it were the selected phone.
            generic = any(word in reported_label.lower() for word in ("sdk_gphone", "android sdk built for"))
            visible_label = configured_label if configured_label and generic else (reported_label or configured_label)
            devices.append({
                "adb": adb, "serial": serial, "avd": avd_name,
                "manufacturer": manufacturer, "model": model,
                "label": visible_label or avd_name or serial,
                "width": width, "height": height,
                "camera_front": config.get("hw.camera.front", ""),
                "camera_back": config.get("hw.camera.back", ""),
                "microphone": config.get("hw.audioInput", ""),
            })
        if devices:
            wanted = (preferred or "").strip().lower()
            return next((d for d in devices if wanted and wanted in {d["avd"].lower(), d["label"].lower()}), devices[0])
    return None


def connect_running_android(preferred=""):
    """Enable host microphone capture and return the live emulator description.

    Camera selection is fixed by the emulator at launch; we report and use that
    mapping rather than pretending adb can hot-swap it.
    """
    device = detect_running_android(preferred)
    if not device:
        return None
    device["host_microphone_enabled"] = "OK" in _adb(
        device["adb"], ["-s", device["serial"], "emu", "avd", "hostmicon"]
    ).upper()
    return device

# ---------------------------------------------------------- live source probes
def _normalized_device_name(value):
    """Comparison key for device names: case, spaces and punctuation ignored."""
    return "".join(ch for ch in str(value or "").lower() if ch.isalnum())


class NamedDirectShowCapture:
    """Small cv2-like reader bound to one exact DirectShow filter name.

    OpenCV's numeric CAP_DSHOW indexes do not always have the same order as
    DirectShow's device-name enumeration (notably with Iriun plus a phone
    camera). Pairing labels[index] with VideoCapture(index) therefore displayed
    Redmi/Realme in the selector but opened Iriun. pygrabber builds the graph
    from the selected DirectShow filter itself, so the name and pixels cannot
    diverge.
    """
    def __init__(self, name, fallback_index=None):
        self.name = str(name or "")
        self.frame = None
        self.lock = threading.Lock()
        self.event = threading.Event()
        self.graph = None
        self.opened = False
        from pygrabber.dshow_graph import FilterGraph
        labels = list(FilterGraph().get_input_devices())
        wanted = self.name.strip().lower()
        index = next((i for i, label in enumerate(labels) if str(label).strip().lower() == wanted), None)
        if index is None:
            # The same camera can be spelled with different spacing, dashes or
            # case by the registry and by DirectShow. Compare a normalised form
            # before giving up on the name.
            normalized = _normalized_device_name(self.name)
            index = next((i for i, label in enumerate(labels)
                          if normalized and _normalized_device_name(label) == normalized), None)
        if index is None:
            loose = [i for i, label in enumerate(labels)
                     if wanted and (wanted in str(label).strip().lower() or str(label).strip().lower() in wanted)]
            index = loose[0] if len(loose) == 1 else None
        if index is None:
            raise RuntimeError("Camera is not in the DirectShow list: %s" % self.name)
        graph = FilterGraph()
        graph.add_video_input_device(index)
        graph.add_sample_grabber(self._frame)
        graph.add_null_render()
        graph.prepare()
        graph.run()
        self.graph = graph
        self.opened = True

    def _frame(self, image):
        with self.lock:
            try:
                self.frame = image.copy()
            except Exception:
                self.frame = image
        self.event.set()

    def isOpened(self):
        return bool(self.opened)

    def read(self):
        self.event.wait(2.0)
        with self.lock:
            frame = None if self.frame is None else self.frame.copy()
            self.event.clear()
        return (frame is not None, frame)

    def release(self):
        self.opened = False
        try:
            if self.graph is not None:
                self.graph.stop()
        except Exception:
            pass
        self.graph = None


def open_camera_exact(index, name):
    """Open a camera by its exact DirectShow name, with a numeric fallback.

    The name is preferred because OpenCV's numeric CAP_DSHOW indexes do not
    always follow DirectShow's order. The numeric path is not a guess about the
    ORDER though - it is the same camera slot the enumeration just returned -
    so falling back to it still shows the camera the user selected instead of
    reporting "no camera" whenever pygrabber is missing or a name shifted.
    """
    import cv2
    if is_windows() and name:
        try:
            return NamedDirectShowCapture(name, index)
        except Exception:
            pass
    return cv2.VideoCapture(index, cv2.CAP_DSHOW) if is_windows() else cv2.VideoCapture(index)


def _own_virtual_camera(name):
    """True for vStudio's own output - feeding it back would loop the picture."""
    low = str(name or "").lower()
    return any(word in low for word in ("unity video capture", "vstudio mobile", "vstudio"))


def _read_first_frame(index, label):
    """Try every way of opening one camera. Returns (ok, width, height, error)."""
    errors = []
    attempts = []
    if is_windows() and label:
        try:
            attempts.append(NamedDirectShowCapture(label, index))
        except Exception as exc:
            errors.append("DirectShow name: %s" % exc)
    try:
        import cv2
        backend = cv2.CAP_DSHOW if is_windows() else cv2.CAP_ANY
        attempts.append(cv2.VideoCapture(index, backend))
    except Exception as exc:
        errors.append("OpenCV: %s" % exc)
    for cap in attempts:
        if cap is None:
            continue
        try:
            if not cap.isOpened():
                errors.append("cannot open")
                continue
            ok, frame = cap.read()
            if ok and frame is not None and getattr(frame, "size", 0):
                height, width = frame.shape[:2]
                return True, int(width), int(height), ""
            errors.append("no frame")
        except Exception as exc:
            errors.append(str(exc))
        finally:
            try:
                cap.release()
            except Exception:
                pass
    text = "; ".join(str(e) for e in errors if e)
    return False, 0, 0, (text[:180] if text else "unavailable")


def probe_all_cameras(max_index=10):
    """Every camera this computer has, with availability and the reason why not.

    Two truths are kept apart on purpose: a listed DirectShow entry is not a
    working camera (busy, stale and disabled endpoints exist), and a camera
    that cannot be opened right now is not a missing camera. Both are returned,
    so the picker always shows the cameras the host really has and the user
    always gets to choose which one is used.
    """
    try:
        labels = list_dshow_cameras()
    except Exception:
        labels = []
    # Cameras whose name never reached a listing are still reachable by their
    # numeric DirectShow slots. Such a slot is reported only when it really
    # produced a frame - a nameless "busy camera" would be a made-up entry.
    named = list(labels[:max_index])
    slots = min(max_index, len(named) + 2)
    result = []
    for index, label in enumerate(named):
        if _own_virtual_camera(label):
            continue          # our own virtual camera is not a host source
        ok, width, height, error = _read_first_frame(index, label)
        result.append({
            "index": int(index), "name": label, "available": bool(ok),
            "width": int(width), "height": int(height), "passed": bool(ok),
            "note": "" if ok else error,
        })
    for index in range(len(named), slots):
        ok, width, height, _error = _read_first_frame(index, "")
        if not ok:
            continue
        result.append({
            "index": int(index), "name": "Camera %d" % (index + 1), "available": True,
            "width": int(width), "height": int(height), "passed": True, "note": "",
        })
    return result


def probe_working_cameras(max_index=10):
    """Only the cameras that produced a real frame right now."""
    return [item for item in probe_all_cameras(max_index) if item.get("available")]


def probe_working_microphones():
    """Return host inputs whose format is accepted and stream can start now."""
    result = []
    try:
        import sounddevice as sd
        devices = sd.query_devices()
        for index, device in enumerate(devices):
            channels = int(device.get("max_input_channels", 0) or 0)
            if channels <= 0:
                continue
            name = str(device.get("name") or "Microphone %d" % index)
            # CABLE Output is Android's receiving endpoint, not a host source.
            # Offering it here creates a silent CABLE Output -> CABLE Input
            # feedback route and was the reason the dashboard showed 0%.
            low = name.lower()
            if "cable output" in low or ("vb-audio" in low and "cable" in low):
                continue
            rate = int(device.get("default_samplerate", 48000) or 48000)
            stream = None
            try:
                sd.check_input_settings(device=index, channels=1, samplerate=rate, dtype="float32")
                # Start briefly: this filters disconnected and already-exclusive
                # endpoints rather than showing every stale Windows entry.
                stream = sd.InputStream(device=index, channels=1, samplerate=rate,
                                        dtype="float32", blocksize=max(64, rate // 100))
                stream.start()
                stream.stop()
                result.append({"index": index, "name": name,
                               "channels": channels, "sample_rate": rate, "passed": True})
            except Exception:
                continue
            finally:
                if stream is not None:
                    try:
                        stream.close()
                    except Exception:
                        pass
    except Exception:
        pass
    return result
