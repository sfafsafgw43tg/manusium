# -*- coding: utf-8 -*-
"""
vStudio — Generator Modeli 3D Twarzy z Animacjami (Face360 3D Head Animator).
W 100% lokalny, w pełni trójwymiarowy silnik i animator modeli 3D głowy.

Zasoby modeli 3D:
1. Modele z folderu models1 (korean_man.obj / korean_man.ma + pjan.png z 4K teksturą).
2. Modele anatomiczne z pełną geometrią (czaszka, szyja, uszy, gałki oczne 3D, fryzura 3D).
3. Brak jakichkolwiek płaskich nakładek 2D — 100% renderingu siatek 3D z buforem Z i oświetleniem studyjnym.
"""
from __future__ import annotations

import base64
import io
import math
import os
from pathlib import Path
import threading
import time
from typing import Optional, Tuple, Dict, Any, List

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageOps

try:
    from .head_3d.head_builder import build_head, Topology
    from .head_3d.face_fit import fit_photo
    from .head_3d.renderer import Head3DRenderer, create_rotation_matrix
    from .ai_texture_generator import AITexture360Generator
except (ImportError, ValueError):
    from head_3d.head_builder import build_head, Topology
    from head_3d.face_fit import fit_photo
    from head_3d.renderer import Head3DRenderer, create_rotation_matrix
    from ai_texture_generator import AITexture360Generator

ROOT = Path(__file__).resolve().parents[1]
ASSETS_DIR = Path(__file__).resolve().parent / "assets" / "models"
MODELS1_DIR = ASSETS_DIR
DATA_DIR = Path(__file__).resolve().parent / "data"


class Face3DAnimator:
    """Zarządza wyłącznie fotorealistycznymi modelami 3D (kolekcja Korean 3D i dedykowane asety)."""

    AVAILABLE_MODELS = [
        "korean_man",
        "korean_woman",
        "korean_studio",
        "korean_cyber",
        "korean_anime",
        "realistic_male",
        "realistic_female",
        "canonical_scan",
    ]

    def __init__(self):
        self.active_model_name = "korean_man"
        self.anim_mode = "natural"  # "natural", "unnatural", "turntable", "nodding", "shaking", "manual"
        self.is_speaking = False
        self.speech_start_time = 0.0
        self.speech_duration = 0.0
        self.current_photo: Optional[Image.Image] = None
        self.head_mesh: Optional[Dict[str, Any]] = None
        self.renderer = Head3DRenderer()
        self.ai_texture_gen = AITexture360Generator()

        # Ręczna manipulacja myszą i D-Pad (Yaw, Pitch, Roll, Zoom, Pan)
        self.manual_yaw = 0.0
        self.manual_pitch = 0.0
        self.manual_roll = 0.0
        self.manual_zoom = 1.0
        self.manual_pan_x = 0.0
        self.manual_pan_y = 0.0

        # Tryb renderowania i komponenty 3D
        self.render_mode = "textured"  # "textured", "wireframe", "textured_wireframe", "clay"
        self.show_hair = True
        self.show_neck = True
        self.show_ears = True

        # Inicjalizacja domyślnym modelem 3D z folderu models1
        self.gender = "male"
        self._korean_base_texture: Optional[Image.Image] = None
        self.korean_overlay_photo: Optional[Image.Image] = None
        self.korean_360_ai_texture: Optional[Image.Image] = None
        self.korean_overlay_settings: Dict[str, Any] = {
            "offset_x": 0.0,
            "offset_y": 0.0,
            "scale": 1.0,
            "opacity": 0.85,
            "feather": 22,
            "match_skin": True,
            "remove_bg": True,
        }

        # Realistyczne tło sceny 3D (studio, biuro, newsroom, loft, cyberpunk itp.)
        self.bg_type: str = "studio_dark"
        self.custom_bg: Optional[Image.Image] = None
        self.bg_blur: int = 0

        self.load_model("korean_man")

    @property
    def available_models(self):
        return list(self.AVAILABLE_MODELS)

    @property
    def available_genders(self):
        return list(self.AVAILABLE_MODELS)

    def load_hd_model(self):
        """Wczytuje fotorealistyczny model 3D korean_man z folderu models1."""
        self.load_model("korean_man")

    def generate_random_face(self, model_name: str = "korean_man"):
        """Przełącza na fotorealistyczny model trójwymiarowy."""
        if model_name in self.AVAILABLE_MODELS:
            self.load_model(model_name)
        else:
            self.load_model("korean_man")
        self.gender = model_name

    def load_model(self, model_name: str, keep_overlay: bool = False):
        """Ładuje wybrany model 3D bez jakichkolwiek elementów 2D ani nakładania się."""
        self.gender = model_name
        self.active_model_name = model_name
        if not keep_overlay:
            self.korean_overlay_photo = None
            self.korean_360_ai_texture = None

        if model_name == "canonical_scan":
            self.head_mesh = build_head("female")
            tex_file = ASSETS_DIR / "realistic_female_texture.png"
            if tex_file.is_file():
                try:
                    self.current_photo = Image.open(tex_file).convert("RGB")
                    self._korean_base_texture = self.current_photo.copy()
                except Exception:
                    pass
        elif model_name in ("korean_woman", "korean_studio", "korean_cyber", "korean_anime", "realistic_male", "realistic_female"):
            self._load_custom_asset_model(model_name)
        else:
            self._load_models1_korean_man()

        if self.head_mesh is not None:
            self.head_mesh["texture"] = self.current_photo

    def _load_custom_asset_model(self, model_name: str):
        """Ładuje fotorealistyczny model 3D z katalogu dedykowanych asetów."""
        obj_file = ASSETS_DIR / f"{model_name}.obj"
        if not obj_file.is_file():
            obj_file = MODELS1_DIR / "korean_man.obj"
        if not obj_file.is_file():
            obj_file = DATA_DIR / "korean_man.obj"

        tex_file = ASSETS_DIR / f"{model_name}_texture.png"
        if not tex_file.is_file():
            tex_file = MODELS1_DIR / "pjan.png"
        if not tex_file.is_file():
            tex_file = DATA_DIR / "korean_man_texture.jpg"

        self._load_custom_obj(obj_file)
        if tex_file.is_file():
            try:
                self.current_photo = Image.open(tex_file).convert("RGB")
                self._korean_base_texture = self.current_photo.copy()
            except Exception:
                pass
        self.active_model_name = model_name

    def cycle_model(self) -> str:
        """Przełącza na kolejny model trójwymiarowy w kolekcji."""
        try:
            curr_idx = self.AVAILABLE_MODELS.index(self.active_model_name)
            next_idx = (curr_idx + 1) % len(self.AVAILABLE_MODELS)
        except ValueError:
            next_idx = 0
        target = self.AVAILABLE_MODELS[next_idx]
        self.load_model(target)
        return target

    def _load_models1_korean_man(self):
        """Ładuje fotorealistyczny model 3D korean_man z folderu models1 (lub kopii zapasowej w data/assets)."""
        obj_file = MODELS1_DIR / "korean_man.obj"
        if not obj_file.is_file():
            obj_file = ASSETS_DIR / "korean_man.obj"
        if not obj_file.is_file():
            obj_file = DATA_DIR / "korean_man.obj"

        png_file = MODELS1_DIR / "pjan.png"
        if not png_file.is_file():
            png_file = ASSETS_DIR / "korean_studio_texture.png"
        if not png_file.is_file():
            png_file = DATA_DIR / "korean_man_texture.jpg"

        if not obj_file.is_file():
            self.head_mesh = build_head("male")
            return

        verts, uvs, faces, face_uvs, quad_edges = [], [], [], [], []
        with open(obj_file, "r", encoding="utf-8") as f:
            for line in f:
                p = line.split()
                if not p:
                    continue
                if p[0] == "v":
                    verts.append([float(x) for x in p[1:4]])
                elif p[0] == "vt":
                    uvs.append([float(x) for x in p[1:3]])
                elif p[0] == "f":
                    indices = [int(x.split("/")[0]) - 1 for x in p[1:]]
                    u_indices = [int(x.split("/")[1]) - 1 if "/" in x else 0 for x in p[1:]]
                    if len(indices) == 4:
                        faces.append([indices[0], indices[1], indices[2]])
                        faces.append([indices[0], indices[2], indices[3]])
                        face_uvs.append([u_indices[0], u_indices[1], u_indices[2]])
                        face_uvs.append([u_indices[0], u_indices[2], u_indices[3]])
                        quad_edges.append((indices[0], indices[1]))
                        quad_edges.append((indices[1], indices[2]))
                        quad_edges.append((indices[2], indices[3]))
                        quad_edges.append((indices[3], indices[0]))
                    elif len(indices) == 3:
                        faces.append(indices)
                        face_uvs.append(u_indices)
                        quad_edges.append((indices[0], indices[1]))
                        quad_edges.append((indices[1], indices[2]))
                        quad_edges.append((indices[2], indices[0]))

        V = np.array(verts, dtype=np.float64)
        ctr = V.mean(axis=0)
        span_y = max(1e-4, V[:, 1].max() - V[:, 1].min())
        V_norm = (V - ctr) * (0.32 / span_y)

        # Generowanie animowalnych wierzchołków ust i powiek dla modelu korean_man
        mouth_mask = (V_norm[:, 1] > -0.065) & (V_norm[:, 1] < -0.015) & (V_norm[:, 2] > 0.025) & (np.abs(V_norm[:, 0]) < 0.035)
        m_idx = np.where(mouth_mask)[0].tolist()
        m_deltas = np.zeros((len(m_idx), 3), dtype=np.float64)
        m_deltas[:, 1] = -0.022
        m_deltas[:, 2] = -0.006

        eye_mask = (V_norm[:, 1] > 0.015) & (V_norm[:, 1] < 0.045) & (V_norm[:, 2] > 0.022) & (np.abs(V_norm[:, 0]) > 0.015) & (np.abs(V_norm[:, 0]) < 0.055)
        b_idx = np.where(eye_mask)[0].tolist()
        b_deltas = np.zeros((len(b_idx), 3), dtype=np.float64)
        b_deltas[:, 1] = -0.014

        self.head_mesh = {
            "gender": "male",
            "positions": V_norm.tolist(),
            "indices": faces,
            "face_uvs": face_uvs,
            "uv_coords": uvs,
            "quad_edges": quad_edges,
            "all_textured": True,
            "skinTone": "#c4a482",
            "center": [0.0, 0.0, 0.0],
            "blink": {"indices": b_idx, "deltas": b_deltas.tolist()},
            "mouth": {"indices": m_idx, "deltas": m_deltas.tolist()},
            "eyeballs": [
                {"center": [-0.032, 0.024, 0.038], "radius": 0.012, "irisColor": "#453229"},
                {"center": [0.032, 0.024, 0.038], "radius": 0.012, "irisColor": "#453229"}
            ]
        }

        if png_file.is_file():
            im = Image.open(png_file).convert("RGB")
            if max(im.size) > 1024:
                im = im.resize((1024, 1024), Image.Resampling.LANCZOS)
            self._korean_base_texture = im.copy()
            if self.korean_overlay_photo is not None:
                self.current_photo = self._blend_korean_photo()
            else:
                self.current_photo = im

    def apply_photo_overlay_korean(self, photo: Optional[Image.Image] = None, **kwargs) -> Image.Image:
        """Nakłada i integruje zdjęcie portretowe na maskę UV modelu Korean 3D."""
        if photo is not None:
            self.korean_overlay_photo = photo.convert("RGB")
        for k, v in kwargs.items():
            if k in self.korean_overlay_settings:
                self.korean_overlay_settings[k] = v
        if self._korean_base_texture is None:
            self._load_models1_korean_man()
        if self.korean_overlay_photo is not None:
            self.current_photo = self._blend_korean_photo()
            self.active_model_name = "korean_man_custom_face"
        return self.current_photo

    def load_korean_photo_file(self, path: str) -> Image.Image:
        """Wczytuje zdjęcie z dysku i nakłada na maskę modelu Korean 3D."""
        p = Path(path)
        img = Image.open(p).convert("RGB")
        return self.apply_photo_overlay_korean(img)

    def reset_korean_texture(self) -> Image.Image:
        """Przywraca oryginalną fabryczną teksturę modelu Korean 3D."""
        self.korean_overlay_photo = None
        self.korean_360_ai_texture = None
        if self._korean_base_texture is not None:
            self.current_photo = self._korean_base_texture.copy()
        else:
            self._load_models1_korean_man()
        if self.head_mesh is not None:
            self.head_mesh["texture"] = self.current_photo
        self.active_model_name = "korean_man"
        return self.current_photo

    def set_background(self, bg_type: str = "studio_dark", custom_image: Optional[Image.Image] = None, blur: int = 0):
        """Ustawia realistyczne tło sceny 3D (studio, biuro, newsroom, loft, cyberpunk itp.)."""
        self.bg_type = bg_type or "studio_dark"
        if custom_image is not None:
            self.custom_bg = custom_image
        self.bg_blur = max(0, int(blur))
        self.renderer.set_background(self.bg_type, self.custom_bg, self.bg_blur)

    def load_background_file(self, path: str, blur: int = 0):
        """Wczytuje własny plik graficzny jako tło sceny 3D."""
        p = Path(path)
        img = Image.open(p).convert("RGB")
        self.set_background("custom", custom_image=img, blur=blur)

    def generate_ai_360_texture(
        self,
        photo: Optional[Image.Image] = None,
        engine: str = "local_neural",
        style: str = "photorealistic",
        api_key: str = "",
        status_callback: Optional[callable] = None,
        progress_callback: Optional[callable] = None,
        **kwargs
    ) -> Image.Image:
        """Generuje pełną mapę tekstury 360 UV ze zdjęcia przodu twarzy za pomocą AI."""
        target_photo = photo or self.korean_overlay_photo or self.current_photo
        if target_photo is None:
            sample = ROOT / "zdj" / "face (1).png"
            if sample.is_file():
                target_photo = Image.open(sample).convert("RGB")
            else:
                target_photo = self._korean_base_texture or Image.new("RGB", (512, 512), (180, 150, 130))

        cb = progress_callback or status_callback
        tex_360 = self.ai_texture_gen.generate_360_texture(
            photo=target_photo,
            engine=engine,
            style=style,
            api_key=api_key or "",
            status_callback=cb,
            progress_callback=cb,
            **kwargs
        )
        self.korean_360_ai_texture = tex_360
        self.current_photo = tex_360
        if self.head_mesh is not None:
            self.head_mesh["texture"] = tex_360
        self.korean_overlay_photo = target_photo
        self.active_model_name = f"korean_ai_360_{style}"
        return self.current_photo

    def export_current_texture(self, filepath: str) -> bool:
        """Zapisuje bieżącą teksturę 360 UV jako plik graficzny (PNG / JPG)."""
        if self.current_photo:
            self.ai_texture_gen.export_texture(self.current_photo, filepath)
            return True
        return False

    def _blend_korean_photo(self) -> Image.Image:
        """Płynnie integruje nałożone zdjęcie z anatomiczną maską UV modelu Korean 3D."""
        if self._korean_base_texture is None or self.korean_overlay_photo is None:
            return self._korean_base_texture or Image.new("RGB", (1024, 1024), (180, 150, 130))

        base = self._korean_base_texture
        photo = self.korean_overlay_photo
        W, H = base.size

        s = self.korean_overlay_settings
        ox = float(s.get("offset_x", 0.0))
        oy = float(s.get("offset_y", 0.0))
        sc = float(s.get("scale", 1.0))
        op = float(s.get("opacity", 0.85))
        feather = max(1, int(s.get("feather", 22)))
        match_skin = bool(s.get("match_skin", True))
        remove_bg = bool(s.get("remove_bg", True))

        # Przygotowanie obrazu zdjęcia
        pw, ph = photo.size
        photo_cv = cv2.cvtColor(np.array(photo), cv2.COLOR_RGB2BGR)

        # 1. Wykrycie punktów odniesienia portretu wejściowego (detekcja twarzy i oczu)
        s_left_eye, s_right_eye, s_mouth = self.ai_texture_gen._detect_landmarks(photo_cv)

        # 2. Dokładne punkty oczu w przestrzeni UV modelu Korean 3D (1024x1024)
        dst_center = np.array([422.5 + ox, 314.5 + oy], dtype=np.float32)
        dst_dist = 69.8 * sc

        src_dx = s_right_eye[0] - s_left_eye[0]
        src_dy = s_right_eye[1] - s_left_eye[1]
        src_dist = max(1e-4, float(np.hypot(src_dx, src_dy)))
        src_angle = float(np.degrees(np.arctan2(src_dy, src_dx)))
        src_center = (s_left_eye + s_right_eye) / 2.0

        scale = dst_dist / src_dist
        M = cv2.getRotationMatrix2D(tuple(src_center), -src_angle, scale)
        M[0, 2] += dst_center[0] - src_center[0]
        M[1, 2] += dst_center[1] - src_center[1]

        warped_cv = cv2.warpAffine(photo_cv, M, (W, H), flags=cv2.INTER_LANCZOS4, borderMode=cv2.BORDER_REFLECT)

        # 3. Anatomiczny kontur owalu twarzy modelu Korean 3D (omijający uszy i skronie)
        face_polygon_1024 = np.array([
            [422, 220], [380, 235], [345, 275], [330, 330],
            [335, 390], [365, 435], [400, 465], [425, 475],
            [455, 465], [485, 435], [515, 390], [520, 330],
            [505, 275], [470, 235],
        ], dtype=np.float32)

        poly_pts = []
        for pt in face_polygon_1024:
            px = 422.5 + (pt[0] - 422.5) * sc + ox
            py = 314.5 + (pt[1] - 314.5) * sc + oy
            poly_pts.append([int(px), int(py)])

        uv_geom_mask = np.zeros((H, W), dtype=np.float32)
        cv2.fillPoly(uv_geom_mask, [np.array(poly_pts, dtype=np.int32)], 1.0)
        k_size = feather * 2 + 1
        combined_mask = cv2.GaussianBlur(uv_geom_mask, (k_size, k_size), 0)
        m_arr = (combined_mask * op)[:, :, None]

        # 4. Automatyczne dopasowanie karnacji skóry
        base_cv = cv2.cvtColor(np.array(base), cv2.COLOR_RGB2BGR)
        warped_adj = warped_cv.astype(np.float32)
        if match_skin:
            face_mask = m_arr[:, :, 0] > 0.35
            if np.any(face_mask):
                base_patch = base_cv[280:350, 370:470]
                base_med = np.median(base_patch, axis=(0, 1)) if len(base_patch) > 0 else np.array([160, 130, 110])
                photo_med = np.median(warped_cv[face_mask], axis=0)
                ratio = np.clip(base_med / (photo_med + 1e-4), 0.70, 1.40)
                warped_adj = np.clip(warped_adj * (ratio * 0.40 + 0.60), 0, 255)

        blended_cv = np.clip(base_cv.astype(np.float32) * (1.0 - m_arr) + warped_adj * m_arr, 0, 255).astype(np.uint8)
        blended_rgb = cv2.cvtColor(blended_cv, cv2.COLOR_BGR2RGB)
        return Image.fromarray(blended_rgb)

    def fit_photo_file(self, path: str):
        """Mapuje zdjęcie portretowe na trójwymiarową głowę (opcja dodatkowa)."""
        p = Path(path)
        raw = p.read_bytes()
        img = Image.open(io.BytesIO(raw)).convert("RGB")
        self.current_photo = img
        try:
            fitted = fit_photo(raw, gender="female")
            if fitted:
                self.head_mesh = fitted
                self.active_model_name = f"Photo_3D_{p.stem[:14]}"
        except Exception:
            pass

    def load_photo_file(self, path: str):
        """Wczytuje plik zdjęcia portretowego (opcja dodatkowa)."""
        self.fit_photo_file(path)

    def load_model_file(self, path: str):
        """Wczytuje model 3D (OBJ/MA) lub dopasowuje siatkę 3D do zdjęcia portretowego."""
        p = Path(path)
        ext = p.suffix.lower()

        if ext == ".obj":
            self._load_custom_obj(p)
        elif ext in (".png", ".jpg", ".jpeg", ".bmp"):
            self.fit_photo_file(path)

    def _load_custom_obj(self, obj_path: Path):
        """Parsuje plik Wavefront OBJ i tworzy pełną strukturę trójwymiarową."""
        verts, uvs, faces, face_uvs, quad_edges = [], [], [], [], []
        with open(obj_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                p = line.split()
                if not p:
                    continue
                if p[0] == "v":
                    verts.append([float(x) for x in p[1:4]])
                elif p[0] == "vt":
                    uvs.append([float(x) for x in p[1:3]])
                elif p[0] == "f":
                    indices = [int(x.split("/")[0]) - 1 for x in p[1:]]
                    u_indices = [int(x.split("/")[1]) - 1 if "/" in x else 0 for x in p[1:]]
                    if len(indices) == 4:
                        faces.append([indices[0], indices[1], indices[2]])
                        faces.append([indices[0], indices[2], indices[3]])
                        if u_indices:
                            face_uvs.append([u_indices[0], u_indices[1], u_indices[2]])
                            face_uvs.append([u_indices[0], u_indices[2], u_indices[3]])
                        quad_edges.append((indices[0], indices[1]))
                        quad_edges.append((indices[1], indices[2]))
                        quad_edges.append((indices[2], indices[3]))
                        quad_edges.append((indices[3], indices[0]))
                    elif len(indices) == 3:
                        faces.append(indices)
                        if u_indices:
                            face_uvs.append(u_indices)
                        quad_edges.append((indices[0], indices[1]))
                        quad_edges.append((indices[1], indices[2]))
                        quad_edges.append((indices[2], indices[0]))

        if not verts or not faces:
            return

        V = np.array(verts, dtype=np.float64)
        ctr = V.mean(axis=0)
        span_y = max(1e-4, V[:, 1].max() - V[:, 1].min())
        V_norm = (V - ctr) * (0.32 / span_y)

        # Generowanie animowalnych wierzchołków ust i powiek dla modeli OBJ
        mouth_mask = (V_norm[:, 1] > -0.065) & (V_norm[:, 1] < -0.015) & (V_norm[:, 2] > 0.025) & (np.abs(V_norm[:, 0]) < 0.035)
        m_idx = np.where(mouth_mask)[0].tolist()
        m_deltas = np.zeros((len(m_idx), 3), dtype=np.float64)
        m_deltas[:, 1] = -0.022
        m_deltas[:, 2] = -0.006

        eye_mask = (V_norm[:, 1] > 0.015) & (V_norm[:, 1] < 0.045) & (V_norm[:, 2] > 0.022) & (np.abs(V_norm[:, 0]) > 0.015) & (np.abs(V_norm[:, 0]) < 0.055)
        b_idx = np.where(eye_mask)[0].tolist()
        b_deltas = np.zeros((len(b_idx), 3), dtype=np.float64)
        b_deltas[:, 1] = -0.014

        self.head_mesh = {
            "gender": "custom",
            "positions": V_norm.tolist(),
            "indices": faces,
            "face_uvs": face_uvs if face_uvs else None,
            "uv_coords": uvs if uvs else None,
            "quad_edges": quad_edges,
            "all_textured": bool(uvs and face_uvs),
            "skinTone": "#d2a884",
            "center": [0.0, 0.0, 0.0],
            "blink": {"indices": b_idx, "deltas": b_deltas.tolist()},
            "mouth": {"indices": m_idx, "deltas": m_deltas.tolist()},
        }
        self.active_model_name = f"Custom_OBJ_{obj_path.stem}"

    # =========================================================================
    # Kontrola shaderów i komponentów 3D
    # =========================================================================
    def set_render_mode(self, mode: str):
        if mode in ("textured", "wireframe", "textured_wireframe", "clay"):
            self.render_mode = mode

    def toggle_hair(self, state: Optional[bool] = None):
        self.show_hair = not self.show_hair if state is None else state

    def toggle_neck(self, state: Optional[bool] = None):
        self.show_neck = not self.show_neck if state is None else state

    def toggle_ears(self, state: Optional[bool] = None):
        self.show_ears = not self.show_ears if state is None else state

    # =========================================================================
    # Ręczna kontrola pozycji, obrotu i przybliżenia (mysz / D-Pad)
    # =========================================================================
    def rotate_by_delta(self, dyaw: float, dpitch: float):
        self.manual_yaw = max(-3.14, min(3.14, self.manual_yaw + dyaw))
        self.manual_pitch = max(-1.1, min(1.1, self.manual_pitch + dpitch))

    def roll_by_delta(self, droll: float):
        self.manual_roll = max(-1.2, min(1.2, self.manual_roll + droll))

    def zoom_by_delta(self, factor: float):
        self.manual_zoom = max(0.35, min(3.0, self.manual_zoom * factor))

    def pan_by_delta(self, dx: float, dy: float):
        self.manual_pan_x += dx
        self.manual_pan_y += dy

    def rotate_left(self, amount: float = 0.20):
        self.rotate_by_delta(-amount, 0.0)

    def rotate_right(self, amount: float = 0.20):
        self.rotate_by_delta(amount, 0.0)

    def rotate_up(self, amount: float = 0.16):
        self.rotate_by_delta(0.0, -amount)

    def rotate_down(self, amount: float = 0.16):
        self.rotate_by_delta(0.0, amount)

    def tilt_left(self, amount: float = 0.14):
        self.roll_by_delta(-amount)

    def tilt_right(self, amount: float = 0.14):
        self.roll_by_delta(amount)

    def zoom_in(self, factor: float = 1.15):
        self.zoom_by_delta(factor)

    def zoom_out(self, factor: float = 0.87):
        self.zoom_by_delta(factor)

    def reset_pose(self):
        self.manual_yaw = 0.0
        self.manual_pitch = 0.0
        self.manual_roll = 0.0
        self.manual_zoom = 1.0
        self.manual_pan_x = 0.0
        self.manual_pan_y = 0.0

    # =========================================================================
    # Synteza mowy TTS & Lip-Sync
    # =========================================================================
    def trigger_speech(self, text: str, duration_estimate: float = 3.0):
        self.is_speaking = True
        self.speech_start_time = time.time()
        self.speech_duration = max(1.0, duration_estimate)

    def stop_speech(self):
        self.is_speaking = False

    # =========================================================================
    # Matematyka animacji
    # =========================================================================
    def get_angles_for_time(self, t: float) -> Tuple[float, float, float, float, float]:
        yaw = self.manual_yaw
        pitch = self.manual_pitch
        roll = self.manual_roll
        blink = 0.0
        mouth = 0.0

        if self.anim_mode == "natural":
            cycle = t % 8.0
            if cycle < 3.5:
                progress = math.sin((cycle / 3.5) * math.pi * 0.5)
                yaw += progress * 0.38
                pitch += -0.06 * progress
            elif cycle < 5.0:
                saccade = 0.025 * math.sin(t * 7.5)
                yaw += 0.38 + saccade
                pitch += -0.06 + 0.015 * math.cos(t * 6.0)
            else:
                back_prog = math.sin(((cycle - 5.0) / 3.0) * math.pi * 0.5)
                yaw += 0.38 * (1.0 - back_prog)
                pitch += -0.06 * (1.0 - back_prog)

            b_phase = t % 3.6
            if b_phase < 0.22:
                blink = math.sin((b_phase / 0.22) * math.pi)

            pitch += 0.015 * math.sin(t * 1.8)

        elif self.anim_mode == "unnatural":
            cycle = t % 6.0
            if cycle < 1.0:
                step = math.floor((cycle / 1.0) * 4) / 4.0
                yaw += -0.55 * step
                pitch += 0.12 * step
                roll += -0.08 * step
            elif cycle < 3.5:
                jitter = 0.015 if (int(t * 20) % 2 == 0) else -0.015
                yaw += -0.55 + jitter
                pitch += 0.12
                roll += -0.08
                blink = 0.0
            elif cycle < 4.2:
                tilt_p = (cycle - 3.5) / 0.7
                yaw += -0.55 * (1.0 - tilt_p)
                pitch += 0.12 + 0.18 * math.sin(tilt_p * math.pi)
                roll += -0.08 + 0.25 * math.sin(tilt_p * math.pi)

        elif self.anim_mode == "turntable":
            yaw += (t * 0.8) % (2.0 * math.pi)

        elif self.anim_mode == "nodding":
            pitch += 0.22 * math.sin(t * 4.5)
            b_phase = t % 4.0
            if b_phase < 0.22:
                blink = math.sin((b_phase / 0.22) * math.pi)

        elif self.anim_mode == "shaking":
            yaw += 0.32 * math.sin(t * 5.0)

        if self.is_speaking:
            elapsed = time.time() - self.speech_start_time
            if elapsed < self.speech_duration:
                mouth = abs(math.sin(elapsed * 12.0)) * 0.75 + abs(math.sin(elapsed * 7.5)) * 0.25
            else:
                self.is_speaking = False
                mouth = 0.0

        return yaw, pitch, roll, blink, mouth

    # =========================================================================
    # Ultra-realistyczny rendering 3D (100% 3D)
    # =========================================================================
    def render_frame(self, t: float, width: int = 480, height: int = 640) -> Image.Image:
        """Renderuje pełnowymiarowy model 3D głowy z oświetleniem, animacją i HUD."""
        yaw, pitch, roll, blink, mouth = self.get_angles_for_time(t)

        frame = self.renderer.render(
            head_mesh=self.head_mesh,
            photo=self.current_photo,
            yaw=yaw,
            pitch=pitch,
            roll=roll,
            zoom=self.manual_zoom,
            pan_x=self.manual_pan_x,
            pan_y=self.manual_pan_y,
            blink=blink,
            mouth=mouth,
            width=width,
            height=height,
            wireframe=(self.render_mode == "wireframe"),
            render_mode=self.render_mode,
            show_hair=self.show_hair,
            show_neck=self.show_neck,
            show_ears=self.show_ears,
            bg_type=self.bg_type,
            custom_bg=self.custom_bg,
            bg_blur=self.bg_blur
        )

        draw = ImageDraw.Draw(frame)

        mode_names = {
            "natural": "Naturalny (obrot / mruganie / oddech)",
            "unnatural": "Nienaturalny (glitch / szarpniecie)",
            "turntable": "Turntable 360",
            "nodding": "Skinienie (Tak)",
            "shaking": "Krecenie (Nie)",
            "manual": "Reczny obrot mysza"
        }
        render_names = {
            "textured": "3D Tekstura",
            "wireframe": "3D Quad Wireframe",
            "textured_wireframe": "3D Hybryda",
            "clay": "3D Clay"
        }
        model_label = f"Model 3D: {self.active_model_name}"
        status_txt = f"{model_label} | {mode_names.get(self.anim_mode, self.anim_mode)} | {render_names.get(self.render_mode, self.render_mode)}"
        if self.is_speaking:
            status_txt += " | [LIP-SYNC: MOWI]"
        draw.text((16, height - 32), status_txt, fill=(160, 175, 195))

        hud_angles = f"Yaw: {math.degrees(yaw):+.0f} deg   Pitch: {math.degrees(pitch):+.0f} deg   Roll: {math.degrees(roll):+.0f} deg   Zoom: {self.manual_zoom:.1f}x"
        draw.text((16, 16), hud_angles, fill=(120, 140, 165))

        return frame
