# 🎥 vStudio (wcześniej Realme 12 Pro Studio)

**Wirtualna kamera + wirtualny mikrofon „vStudio”** — projekcja zdjęć i nagrań
w formatach telefonowych (DirectShow / OBS Virtual Camera / Unity Capture) + **losowe szumy mikrofonu telefonu**
generowane na żywo. **W 100% OFFLINE.** Start przez dwuklik pliku `START_VSTUDIO.bat`. 🖥️

---

## ✨ Nowe funkcje w vStudio

- **Większy podgląd i składane ustawienia**: biblioteka, prawa szyna ustawień i dziennik mają własne przełączniki, a każda grupa ustawień jest akordeonem. Zakładka dźwięku używa jednego wspólnego obszaru przewijania zamiast dwóch pasków.
- **Pewna trasa mikrofonu**: vStudio odróżnia fizyczne wejście od odbiorczego `CABLE Output`, automatycznie wybiera `CABLE Input` jako wyjście do Androida i pokazuje gotowość VB-CABLE. Octo.su próbuje przygotować brakujący sterownik podczas uruchamiania vStudio; obowiązkowy monit UAC systemu Windows może pozostać widoczny.
- **Wybór i zmiana nazwy kamery wirtualnej na żywo**:
  - W aplikacji w górnym pasku kliknij przycisk `📷 [Nazwa]` lub wejdź w `Urządzenia`.
  - Wybierz gotową nazwę z listy (np. `vStudio`, `OBS Virtual Camera`, `Unity Video Capture`, `Realme 12 Pro`) lub wpisz **dowolną własną nazwę**.
  - Przycisk **„Ustaw w vStudio”** zapisuje wybór w aplikacji i konfiguracji.
  - Przycisk **„Zmień nazwę w systemie (Admin)”** automatycznie aktualizuje wpisy w rejestrze Windows (DirectShow), dzięki czemu programy zewnętrzne (Zoom, Teams, Discord, Meet) widzą kamerę pod Twoją wybraną nazwą!
- **Pełna modułowość**: vStudio stanowi w pełni samodzielny moduł projektu, który można aktualizować niezależnie od aplikacji PrOximAl editor.

---

## ✨ Co potrafi aplikacja

### 📷 Projektor obrazu (jak OBS Virtual Cam)
- Wczytuje **zdjęcia** (JPG/PNG/WebP/BMP) i **nagrania** (MP4/AVI/MKV/MOV/WebM)
- Formaty telefonowe: **vStudio 1080×2412 (20:9, natywny)**, Full HD pion,
  HD, QHD, 4K pion, Full HD poziom, kwadrat, Story
- Pokaz slajdów: ręczny / auto / **losowy**, z przejściami (przenikanie, przez czerń)
- Efekty „żywego telefonu”: drganie ręki, ziarno, winieta, animowany **autofocus**
- Nakładka aparatu: REC, data/godzina, podpis wybranej kamery („vStudio 50MP OIS”), bateria
- Filtry: Żywy, Nocny, B&W, Sepia, Chłodny, Ciepły • obrót, lustro, FPS
- **Wybór silnika kamery**: Auto / OBS Studio / Unity Capture (działa też bez OBS)
- **Kadrowanie ręczne**: chwyć zdjęcie myszką i ustaw w kadrze, kółko = zoom,
  suwaki Zoom/X/Y, szybkie pozycje (środek/góra/dół/lewo/prawo) — każde zdjęcie
  **pamięta własny kadr**; tryb **telefonu na długość** (poziomo/panorama)

### 🎬 Odtwarzacz nagrania (pod podglądem)
- Pasek sterowania jest **tylko dla nagrań** (`mp4/avi/mkv/mov`)
- **⏮ ▶/❚❚ ⏹ ⏭** — poprzedni materiał, start/pauza, stop (powrót na 0), następny materiał;
  pauza nie gasi kamery — rozmówca widzi **zamrożoną ostatnią klatkę**
- **Suwak czasu** z podpisem `00:04 / 00:10` — kliknij lub przeciągnij, skok w dowolne miejsce
- **−5 s / +5 s** — skoki w tył i w przód
- **🔁 Zapętl nagranie** + **„Płynny szew” (0–1,2 s)** — ostatnie klatki **rozpływają się**
  w pierwsze, więc powtórka nie trzaska cięciem

### 🎙 Generator szumu mikrofonu (losowy, jak z telefonu)
- Szum własny mikrofonu + przydźwięk 50 Hz + otoczenie — syntezowane na żywo (48 kHz)
- Scenerie: 🏠 pokój, 🏙️ ulica, 🍃 wiatr, ☕ tłum, 🚗 samochód, 🌧️ deszcz, 🌙 noc, 🎲 losowy AI
- Losowe zdarzenia: trzaski, puknięcia, tarcie o ubranie, podmuchy wiatru,
  przejeżdżające auta, gwar, kierunkowskaz, daleki grzmot…
- Regulacja: głośność, poziom szumu, częstotliwość zdarzeń, basy, wyciszenie
- Wskaźnik poziomu **VU meter** na żywo
- **Oddech**: cichy, naturalny oddech jak z telefonu blisko ust + westchnięcia i sapnięcia

### 🎵 Oś czasu audio — muzyka, dźwięki, głos (zakładka **Audio**)
- Dodajesz **pliki audio** (mp3, wav, ogg, flac, m4a…) — pokazują się jako bloki na **osi czasu**
- **▶ Odtwarzaj / ❚❚ Pauza / ■ Stop**, pętla i miks z szumem mikrofonu
- **🔊 Odsłuch**: słyszysz to u siebie (głośniki/słuchawki) z własną głośnością
- **⏺ Nagrywanie** dokładnie tego, co leci na wirtualny mikrofon → plik WAV (16 bit)

### 🗣 Mowa z tekstu (TTS) — zakładka **Mowa (TTS)**
- Wpisujesz tekst → aplikacja **wypowiada go** do wirtualnego mikrofonu
- Silniki 100% offline: Windows `System.Speech`, `espeak-ng`, `pyttsx3`
- Opcjonalne klucze API w zakładce **Prywatność** (domyślnie 100% wyłączone)

### 🤖 AI Wideo — film ze zdjęć, darmowe i OFFLINE (zakładka **AI Wideo**)
- **Prompt po polsku** → AI zamienia na plan montażowy i renderuje film ze zdjęć
- Biblioteka 12 gotowych stylów, uczenie się lokalnych preferencji w `ai_learning.json`

---

## 🚀 Szybki start (Windows)

| Krok | Co zrobić |
|------|-----------|
| 1 | Uruchom **`INSTALUJ.bat` → opcja 1** — pełna instalacja (Python, OBS, VB-CABLE, nazwy, skrót) |
| 2 | Zainstaluj **OBS Studio** (obsproject.com) → kliknij raz **Start Virtual Camera** |
| 3 | Zainstaluj **VB-CABLE** (vb-audio.com/Cable/) |
| 4 | Uruchom **`USTAW_URZADZENIA.bat`** (jako Administrator) → wybierz nazwę kamery (np. `vStudio`) |
| 5 | Na co dzień: dwuklik **`START_VSTUDIO.bat`** → dodaj media → **▶ START NADAWANIA** |
| 6 | W komunikatorze wybierz kamerę i mikrofon **„vStudio”** |

## 📁 Struktura plików modułu

```
vStudio/
├── START_VSTUDIO.bat        ← codzienny start (DWUKLIK)
├── START_REALME_CAM.bat     ← alias kompatybilności wstecznej
├── INSTALUJ.bat             ← instalator bibliotek i narzędzi
├── USTAW_URZADZENIA.bat     ← konfigurator nazw kamer i mikrofonu
├── DIAGNOZUJ_KAMERE.bat     ← narzędzie diagnostyczne DirectShow
├── app.py                   ← główny interfejs vStudio (CustomTkinter)
├── video_engine.py          ← silnik renderowania wideo i nakładek
├── audio_engine.py          ← silnik szumów telefonu i miksu audio
├── audio_timeline.py        ← oś czasu audio
├── virtual_devices.py       ← wykrywanie, wybór i zmiana nazwy kamery wirtualnej
├── phone_formats.py         ← formaty telefonowe i proporcje
├── tts_engine.py            ← generator mowy offline
├── cloud_net.py             ← opcjonalna integracja sieciowa
├── ui_v13.py                ← rozszerzenia UI (Audio + AI)
├── ui_v14.py                ← rozszerzenia UI (odtwarzacz + TTS + ustawienia)
├── scripts/
│   ├── rename_devices.ps1   ← skrypt zmiany nazwy w rejestrze Windows
│   ├── diagnose_camera.ps1  ← skrypt diagnostyki rejestru i kamer
│   └── full_install.ps1     ← pełny skrypt instalacyjny
├── media/                   ← folder na zdjęcia i filmy
├── assets/                  ← ikony i grafiki
├── config.example.json      ← wzorcowa konfiguracja (opis wszystkich pól)
├── config.json              ← Twoja konfiguracja (tworzona automatycznie, poza Git)
└── requirements.txt         ← biblioteki Pythona
```

## Automatyczne połączenie z emulatorem Androida

vStudio Mobile przy starcie i następnie co 5 sekund sprawdza `adb devices`.
Gdy działa Android Emulator, automatycznie odczytuje jego nazwę AVD, prawdziwą
nazwę producenta/modelu raportowaną przez Androida, rozdzielczość oraz mapowanie
kamery z `config.ini`. Włącza też obsługę mikrofonu hosta poleceniem konsoli
emulatora. Zielony pasek pod nagłówkiem pokazuje konkretny port `emulator-*`,
model, kamerę i stan mikrofonu.

Kamera Android Emulatora jest wybierana podczas uruchamiania AVD i nie może być
uczciwie przełączona przez adb w trakcie działania. vStudio wykrywa aktualne
mapowanie zamiast udawać hot-swap; OctoBrowser uruchamia AVD od razu z kamerą
Unity Capture oraz kieruje wybrany mikrofon przez VB-CABLE. Przed startem AVD
OctoBrowser czeka na potwierdzenie, że Unity Capture rzeczywiście publikuje
klatki. Transport kamery ma zgodny z emulatorem format 1280×720; pionowy podgląd
720×1280 jest obracany tylko na wyjściu. Jeden endpoint DirectShow jest przypisany
tylko do jednej kamery Androida, a druga korzysta z bezpiecznej sceny emulowanej.

Interfejs Mobile ma teraz kompaktowy układ 1080 px z priorytetem dla pionowego
podglądu telefonu, jednym przyciskiem urządzeń i stale widocznym stanem
połączenia. Nadal można go powiększyć na większym monitorze.

## Dashboard źródeł na żywo

Główny ekran ma teraz dwa duże kafelki w stylu nowoczesnego dashboardu:
**Kamera na żywo** i **Mikrofon na żywo**. Lista nie pokazuje martwych wpisów
z rejestru. Kamera musi się otworzyć i zwrócić prawdziwą klatkę, a mikrofon musi
zaakceptować format i uruchomić strumień. Dopiero wtedy pojawia się z zielonym
statusem „działa”. Przycisk Skanuj powtarza test na żądanie.

Wybrana kamera jest prawdziwym źródłem podglądu i wyjścia Unity Capture — nie
jest to tylko kosmetyczna lista. Własne wyjście Unity/vStudio jest odfiltrowane,
żeby nie utworzyć pętli obrazu; inne działające kamery wirtualne, np. OBS, mogą
być źródłem. Wybrany mikrofon przełącza silnik audio na wejście duplex i trafia
przez skonfigurowany wirtualny kabel do emulatora. Wybór jest zapisywany.
