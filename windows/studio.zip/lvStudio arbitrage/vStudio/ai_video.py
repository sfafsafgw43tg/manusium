# -*- coding: utf-8 -*-
"""
vStudio — AI WIDEO (v1.3)
======================================
DARMOWE, W 100% OFFLINE AI do robienia filmow ze zdjec.

Jak to dziala (bez internetu, bez chmury):
  • SILNIK EFEKTOW — ken burns (najazd/odjazd), panoramy, obroty, ziarno
    filmowe, winieta, migotanie, sepia/B&W/kinowy look, przejscia
    (przenikanie, przesuw, blysk, glitch) — wszystko liczone lokalnie.
  • ROZUMIENIE PROMPTU — tekst PL -> plan filmu. Zamiana slow ("spokojny",
    "kinowy", "tiktok", "w rytm muzyki", "30 sekund") na konkretne liczby.
  • NAUKA — kazdy zaakceptowany prompt zapisuje sie w `ai_learning.json`.
    Przy kolejnych promptach AI podciaga wartosci ze wzorcow, ktore juz
    znasz (im czesciej uzywane, tym wiekszy wplyw). To lokalna pamiec stylu,
    ktora rosnie z kazdym renderem — i dziala offline.
  • UDERZENIA — ciecia zdjec w rytm muzyki z osi czasu (detektor energii).

Zero platnych API, zero pobierania modeli, zero polaczen sieciowych.
"""
import json
import math
import os
import random
import time

try:
    import numpy as np
    HAS_NUMPY = True
except Exception:
    HAS_NUMPY = False
    np = None

try:
    import cv2
    HAS_CV2 = True
except Exception:
    HAS_CV2 = False
    cv2 = None

try:
    from audio_timeline import decode_audio, beat_times, AUDIO_EXTS
    HAS_AT = True
except Exception:
    HAS_AT = False
    decode_audio = beat_times = None
    AUDIO_EXTS = (".wav", ".mp3", ".ogg", ".flac", ".m4a")

APP_DIR = os.path.dirname(os.path.abspath(__file__))
LEARN_PATH = os.path.join(APP_DIR, "ai_learning.json")

PHOTO_EXTS = (".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff")


# ======================================================================= PLAN
def default_plan():
    return {
        "nazwa": "Neutralny",
        "klip_s": 4.0,               # dlugosc jednego zdjecia (s)
        "ruch": {"typ": "kenburns", "amp": 0.12, "obrot": 0.0, "shak": 0.0},
        "obraz": {
            "ziarno": 5.0, "winieta": 0.22, "rozmycie": 0.0,
            "jasnosc": 1.0, "kontrast": 1.0, "nasycenie": 1.0,
            "kol": "normal", "migotanie": 0.0,
        },
        "przejscia": {"typ": "fade", "czas": 0.8},
        "fps": 30,
        "cel_s": 0.0,                # 0 = dlugosc wynika z liczby zdjec/klipu
        "beat_sync": False,
        "beat_plik": "",
        "muzyka_gain": 0.9,
        "rozmiar": [1080, 1920],
        "dopasowanie": "fill",
        "napisy": [],
        "dopisek": "",               # co AI dopisalo (komunikat dla uzytkownika)
        "wzorce": [],                # rozpoznane wzorce z promptu
    }


# ============================================================ BIBLIOTEKA STYLOW
PRESETS = {
    "Kinowy spokojny": {
        "opis": "Wolne najazdy, delikatne ziarno, przenikanie. Uniwersalny film z wakacji.",
        "prompt": "kinowy spokojny film 30 sekund, wolne najazdy, delikatne ziarno, przenikanie, lekka winieta",
    },
    "TikTok / Reels": {
        "opis": "Pion, szybkie ciecia, mocny ruch kamery, ciecia w rytm muzyki.",
        "prompt": "tiktok reels pion szybkie ciecia dynamika 20 sekund, w rytm muzyki, mocny zoom, kontrast",
    },
    "Retro VHS 1998": {
        "opis": "Stary film z kasety: sepia, ziarno, migotanie, glitch.",
        "prompt": "retro stary film vhs z 1998, sepia, mocne ziarno, migotanie, glitch, winieta",
    },
    "Czarno-biale kino": {
        "opis": "Klasyka B&W: kontrast, winieta, wolny ruch, przenikanie.",
        "prompt": "czarno biale kino klasyczne, wysoki kontrast, winieta, wolny ruch, przenikanie",
    },
    "Sen / oniryczny": {
        "opis": "Rozmycie, wolne tempo, jasny look, lagodne przejscia.",
        "prompt": "sen oniryczny marzenie, rozmycie, wolno, jasny look, lagodne przenikanie",
    },
    "Mroczny thriller": {
        "opis": "Ciemno, mocna winieta, glitch, nerwowy ruch kamery.",
        "prompt": "mroczny thriller tajemniczy, ciemno, mocna winieta, glitch, nerwowa kamera",
    },
    "Vlog dzienny": {
        "opis": "Naturalnie, jasno i cieplo, rytmiczne ciecia, bez przesady.",
        "prompt": "vlog dzienny naturalny jasny cieply, rytmiczne ciecia 3 sekundy, lekki ruch",
    },
    "Konstruktywny wywiad": {
        "opis": "Stabilnie i spokojnie — idealne pod mowionego materialu.",
        "prompt": "spokojny stabilny wywiad, bardzo wolny ruch, bez ziarna, przenikanie, naturalne kolory",
    },
    "Nostalgia / wspomnienia": {
        "opis": "Sepia, wolno, migotanie jak ze starego projektora.",
        "prompt": "nostalgia wspomnienia album rodzinny, sepia, wolne tempo, migotanie projektora",
    },
    "Wakacje na plazy": {
        "opis": "Cieplo, jasno, nasycone kolory, panoramy.",
        "prompt": "wakacje plaza lato, cieply jasny nasycony, panoramy, spokojne tempo",
    },
    "Sport / energia": {
        "opis": "Bardzo szybkie ciecia, mocny ruch, wysoki kontrast.",
        "prompt": "sport energia dynamika, bardzo szybkie ciecia 1 sekunda, mocny ruch, wysoki kontrast",
    },
    "Glitch cyber": {
        "opis": "Neonowo-cyfrowo: glitch, przesuw, mocne ziarno, zimne kolory.",
        "prompt": "glitch cyber cyfrowy neon, przejscia glitch, zimne kolory, mocne ziarno, szybkie ciecia",
    },
}


# ================================================================ NAUKA (LOKALNA)
class AILearning:
    """
    Lokalna pamiec stylu. Kazdy zaakceptowany prompt wzmacnia wzorce,
    ktore w nim rozpoznano. Przy nastepnych promptach AI podciaga wartosci
    w strone tego, co uzytkownik juz wybieral (im wiecej razy, tym mocniej,
    ale z sufitem 35%, zeby nie zabetonowac stylu).
    """

    def __init__(self, path=LEARN_PATH):
        self.path = path
        self.data = {"wzorce": {}, "historia": []}
        self.load()

    def load(self):
        try:
            if os.path.isfile(self.path):
                with open(self.path, "r", encoding="utf-8") as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    self.data["wzorce"] = d.get("wzorce", {}) or {}
                    self.data["historia"] = d.get("historia", []) or []
        except Exception:
            pass

    def save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def reinforce(self, plan, prompt=""):
        """Zapamietuje zaakceptowany prompt i jego plan."""
        try:
            flat = _flatten_plan(plan)
            for w in plan.get("wzorce", []) or []:
                rec = self.data["wzorce"].setdefault(w, {"uzycia": 0, "efekty": {}})
                rec["uzycia"] = int(rec.get("uzycia", 0)) + 1
                eff = rec.setdefault("efekty", {})
                for k, v in flat.items():
                    if isinstance(v, (int, float)) and not isinstance(v, bool):
                        eff[k] = float(eff.get(k, 0.0)) + float(v)
            self.data["historia"].append({
                "kiedy": time.strftime("%Y-%m-%d %H:%M"),
                "prompt": (prompt or plan.get("_prompt", ""))[:300],
                "nazwa": plan.get("nazwa", ""),
                "wzorce": plan.get("wzorce", []),
            })
            self.data["historia"] = self.data["historia"][-120:]
            self.save()
        except Exception:
            pass

    def learned_values(self, patterns):
        """Srednie wartosci efektow z wzorcow, ktore uzytkownik juz akceptowal."""
        out, weight = {}, 0.0
        try:
            for w in patterns or []:
                rec = self.data["wzorce"].get(w)
                if not rec:
                    continue
                uses = int(rec.get("uzycia", 0))
                eff = rec.get("efekty", {}) or {}
                if uses <= 0 or not eff:
                    continue
                wgt = min(0.35, 0.08 * uses)
                for k, s in eff.items():
                    out[k] = out.get(k, 0.0) + (float(s) / uses) * wgt
                weight += wgt
        except Exception:
            pass
        if weight > 0:
            out = {k: v / weight for k, v in out.items()}
        return out, min(0.35, weight)

    def apply_learning(self, plan):
        """Podciaga plan w strone wyuczonych wartosci (lokalna pamiec stylu)."""
        try:
            vals, wgt = self.learned_values(plan.get("wzorce", []))
            if not vals or wgt <= 0:
                return plan
            alpha = min(0.35, wgt)
            applied = []
            for key, val in vals.items():
                cur, ok = _get_path(plan, key)
                if not ok or not isinstance(cur, (int, float)) or isinstance(cur, bool):
                    continue
                new = float(cur) * (1.0 - alpha) + float(val) * alpha
                _set_path(plan, key, new)
                applied.append(key.split(".")[-1])
            if applied:
                plan["dopisek"] = ("AI dopasowalo do Twoich wczesniejszych wyborow: "
                                   + ", ".join(sorted(set(applied))[:6]))
        except Exception:
            pass
        return plan

    def stats(self):
        try:
            n = len(self.data.get("wzorce", {}))
            h = len(self.data.get("historia", []))
            top = sorted(self.data.get("wzorce", {}).items(),
                         key=lambda kv: -int(kv[1].get("uzycia", 0)))[:3]
            top_s = ", ".join("%s (%d)" % (k.split("|")[0], int(v.get("uzycia", 0)))
                              for k, v in top) or "brak"
            return "Wyuczone wzorce: %d  •  akceptacji w historii: %d\nNajczestsze: %s" % (n, h, top_s)
        except Exception:
            return "Brak danych nauki."

    def reset(self):
        self.data = {"wzorce": {}, "historia": []}
        self.save()


def _flatten_plan(plan, prefix=""):
    out = {}
    try:
        for k, v in plan.items():
            if k.startswith("_"):
                continue
            key = (prefix + "." + k) if prefix else k
            if isinstance(v, dict):
                out.update(_flatten_plan(v, key))
            elif isinstance(v, (int, float)) and not isinstance(v, bool):
                out[key] = float(v)
            elif isinstance(v, list) and v and isinstance(v[0], (int, float)):
                for i, x in enumerate(v):
                    out["%s[%d]" % (key, i)] = float(x)
    except Exception:
        pass
    return out


def _get_path(plan, path):
    cur = plan
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None, False
    return cur, True


def _set_path(plan, path, value):
    parts = path.split(".")
    cur = plan
    for p in parts[:-1]:
        if not isinstance(cur.get(p), dict):
            return False
        cur = cur[p]
    cur[parts[-1]] = value
    return True


# ============================================================== PROMPT -> PLAN
# wzorce: (nazwa, [slowa-klucze])
WZORCE = [
    ("szybko",       ["szybk", "dynamik", "energi", "zyw", "mocn tempo"]),
    ("wolno",        ["woln", "spokojn", "leniw", "lagodn", "powol", "relaks", "medytac"]),
    ("cieply",       ["ciepl", "zlot", "sloneczn", "zolty", "warm", "pomaran"]),
    ("zimny",        ["zimn", "niebiesk", "chlodn", "blue", "stalow"]),
    ("kinowy",       ["kinow", "filmow", "cinematic", "kino", "hollywood"]),
    ("vlog",         ["vlog", "dzien", "naturaln", "codzienn"]),
    ("tiktok",       ["tiktok", "reels", "shorts", "rolk", "instagram", "pion"]),
    ("retro",        ["retro", "vhs", "stary film", "kaseta", "199", "198", "lata 8", "lata 9"]),
    ("bw",           ["czarno", "b&w", "bw", "monochrom", "bez kolor"]),
    ("sepia",        ["sepia", "nostalgi", "wspomnien", "album", "projektor"]),
    ("mrok",         ["mroczn", "ciemn", "thriller", "tajemnic", "horror", "noc"]),
    ("jasno",        ["jasn", "swietl", "slonecz", "rado", "pozytyw", "wakacj", "plaza", "lato"]),
    ("sen",          ["sen", "senn", "oniryczn", "marzen", "dream", "mgla", "mgieln"]),
    ("glitch",       ["glitch", "cyber", "neon", "cyfrow", "pixel", "awari"]),
    ("sport",        ["sport", "trening", "silown", "bieg", "rower", "gory", "wspinaczk"]),
    ("portret",      ["portret", "twarz", "ludzi", "osob", "wesele", "urodzin"]),
    ("zoom",         ["zoom", "najazd", "przybli", "oddal"]),
    ("panorama",     ["panoram", "przesuw", "pan", "obrot", "kolow"]),
    ("przenikanie",  ["przenikan", "fade", "crossfade", "miekki", "miekko", "plynnie"]),
    ("ciecie",       ["cieci", "cut", "ostro", "tward", "bez przejsc"]),
    ("blysk",        ["blysk", "flash", "stroboskop", "błysk"]),
    ("ziarno",       ["ziarno", "grain", "film grain", "szum obrazu"]),
    ("czysto",       ["czysto", "bez ziarna", "gladk", "gładk", "steryl"]),
    ("muzyka",       ["w rytm", "beat", "muzyka", "rytm", "piosenk", "soundtrack"]),
]

KOLORY = {
    "bw": "bw", "sepia": "sepia", "retro": "vintage", "kinowy": "kinowy",
    "mrok": "zimny", "jasno": "cieply", "glitch": "zimny", "vlog": "cieply",
    "sen": "sen", "nostalgia": "sepia", "sport": "kinowy",
    "cieply": "cieply", "zimny": "zimny",
}


def _num_after(text, unit_pattern, default=None, lo=1.0, hi=600.0, mult=1.0):
    """
    Liczba przed jednostka, tolerancyjnie na polska odmiane:
    '30 sekund', '4 sekundy', '2 minuty', '20 s', '1 godzina'.
    unit_pattern to wyrazenie regularne jednostki, np. 'sek.+|s'.
    """
    import re
    try:
        m = re.search(r"(\d{1,3}(?:[.,]\d)?)\s*(?:" + unit_pattern + r")\b", text or "")
        if m:
            v = float(m.group(1).replace(",", ".")) * float(mult)
            if v > lo * 0.2:
                return max(lo, min(hi, v))
    except Exception:
        pass
    return default


def _extract_cut_interval(text):
    """'ciecia co 2 sekundy' / '2 s na zdjecie' / 'klip 3 s' -> (sekundy, tekst bez tego fragmentu)."""
    import re
    t = text or ""
    wzory = (
        r"co\s*(\d{1,2}(?:[.,]\d)?)\s*(?:sek\w*|s)\b",
        r"(\d{1,2}(?:[.,]\d)?)\s*(?:sek\w*|s)\s*(?:na\s*)?(?:jedno\s*)?(?:zdj\w*|fot\w*)",
        r"klip\w*\s*(?:po\s*)?(\d{1,2}(?:[.,]\d)?)\b",
    )
    for w in wzory:
        m = re.search(w, t)
        if m:
            try:
                val = float(m.group(1).replace(",", "."))
                val = max(0.4, min(20.0, val))
                return val, (t[:m.start()] + " " + t[m.end():])
            except Exception:
                continue
    return None, t


def match_patterns(text):
    t = (text or "").lower()
    hits = []
    for name, keys in WZORCE:
        for k in keys:
            if k in t:
                hits.append(name)
                break
    # kolejnosc jak w WZORCE, bez duplikatow
    seen, out = set(), []
    for h in hits:
        if h not in seen:
            seen.add(h)
            out.append(h)
    return out


def parse_prompt(text, n_photos=1, has_music=False, orientation="portrait"):
    """Prompt PL -> plan filmu. To serce 'AI rozumie, co chcesz'."""
    plan = default_plan()
    plan["_prompt"] = text or ""
    t = (text or "").lower()
    wz = match_patterns(t)
    plan["wzorce"] = wz
    pod = []          # co AI dopisalo (komunikat)

    # --- pion / poziom / format
    if "poziom" in t or "16:9" in t or "landscape" in t:
        plan["rozmiar"] = [1920, 1080]
        pod.append("format poziomy 16:9")
    elif "kwadrat" in t or "1:1" in t:
        plan["rozmiar"] = [1080, 1080]
        pod.append("format kwadratowy 1:1")
    elif "4:5" in t:
        plan["rozmiar"] = [1080, 1350]
        pod.append("format 4:5")
    else:
        plan["rozmiar"] = ([1080, 1920] if orientation == "portrait" else [1920, 1080])

    # --- ciecie co ile sekund (wycinamy ten fragment, zeby nie mylil dlugosci)
    rytm, t_len = _extract_cut_interval(t)

    # --- dlugosc filmu
    cel = _num_after(t_len, r"sek\w*|s", None, 3.0, 900.0)
    if cel is None:
        cel = _num_after(t_len, r"min\w*", None, 10.0, 3600.0, mult=60.0)
    if cel is None:
        cel = _num_after(t_len, r"godz\w*|h", None, 30.0, 7200.0, mult=3600.0)
    if cel:
        plan["cel_s"] = float(cel)
        pod.append("dlugosc %.0f s" % cel)

    # --- tempo / dlugosc klipu
    if "sport" in wz or "szybko" in wz:
        plan["klip_s"] = 1.6
        plan["ruch"]["shak"] = 0.35
        plan["przejscia"] = {"typ": "ciecie", "czas": 0.12}
    if rytm and rytm <= 2.5:
        plan["przejscia"] = {"typ": "ciecie", "czas": 0.15}
        plan["ruch"]["shak"] = max(plan["ruch"].get("shak", 0.0), 0.18)
    elif "tiktok" in wz:
        plan["klip_s"] = 1.8
        plan["ruch"]["shak"] = 0.25
        plan["przejscia"] = {"typ": "ciecie", "czas": 0.15}
        plan["beat_sync"] = True
    elif "wolno" in wz or "portret" in wz:
        plan["klip_s"] = 5.5
        plan["przejscia"] = {"typ": "fade", "czas": 1.2}
    elif "vlog" in wz:
        plan["klip_s"] = 3.0

    if rytm:
        plan["klip_s"] = float(rytm)
        pod.append("ciecie co %.1f s" % rytm)

    # --- ruch kamery
    if "zoom" in wz and "najazd" in t:
        plan["ruch"]["typ"] = "zoom_in"
    if "przybli" in t:
        plan["ruch"]["typ"] = "zoom_in"
    if "oddal" in t:
        plan["ruch"]["typ"] = "zoom_out"
    if "panoram" in wz:
        plan["ruch"]["typ"] = "pan_lr"
    if "obrot" in t or "kolow" in t:
        plan["ruch"]["typ"] = "orbit"
        plan["ruch"]["obrot"] = 1.4
    if "stabiln" in t or "statyczn" in t or "bez ruchu" in t:
        plan["ruch"] = {"typ": "static", "amp": 0.0, "obrot": 0.0, "shak": 0.0}
        pod.append("kamera stabilna")
    if "szybko" in wz or "sport" in wz:
        plan["ruch"]["amp"] = 0.22
        plan["ruch"]["shak"] = max(plan["ruch"]["shak"], 0.35)
    if "wolno" in wz:
        plan["ruch"]["amp"] = 0.09
        plan["ruch"]["shak"] = min(plan["ruch"]["shak"], 0.06)
    if "sen" in wz:
        plan["ruch"]["typ"] = "kenburns"
        plan["ruch"]["amp"] = 0.08

    # --- kolory / look
    kol = "normal"
    for w in ("glitch", "mrok", "kinowy", "retro", "bw", "sepia", "jasno",
              "cieply", "zimny", "sen", "vlog"):
        if w in wz:
            kol = KOLORY.get(w, "normal")
            break
    if "czarno" in t or "monochrom" in t or "b&w" in t:
        kol = "bw"
    if "sepia" in t:
        kol = "sepia"
    plan["obraz"]["kol"] = kol
    if kol != "normal":
        pod.append("look: " + kol)

    # --- ziarno / winieta / rozmycie / kontrast
    if "ziarno" in wz or "retro" in wz:
        plan["obraz"]["ziarno"] = 16.0 if "retro" in wz else 9.0
    if "czysto" in wz:
        plan["obraz"]["ziarno"] = 0.0
        pod.append("bez ziarna")
    if "winieta" in t:
        plan["obraz"]["winieta"] = 0.45
    if "retro" in wz or "mrok" in wz:
        plan["obraz"]["winieta"] = max(plan["obraz"]["winieta"], 0.45)
    if "mrok" in wz or "ciemn" in t:
        plan["obraz"]["jasnosc"] = 0.82
        plan["obraz"]["kontrast"] = 1.18
    if "jasn" in wz or "wakacj" in wz:
        plan["obraz"]["jasnosc"] = 1.12
        plan["obraz"]["nasycenie"] = 1.18
    if "sen" in wz:
        plan["obraz"]["rozmycie"] = 1.6
        plan["obraz"]["jasnosc"] = 1.08
        plan["obraz"]["winieta"] = 0.18
    if "kontrast" in t or "sport" in wz:
        plan["obraz"]["kontrast"] = 1.2
        plan["obraz"]["nasycenie"] = 1.15
    if "retro" in wz or "nostalgi" in t:
        plan["obraz"]["migotanie"] = 0.05
    if "vhs" in t or "projektor" in t:
        plan["obraz"]["migotanie"] = 0.09

    # --- przejscia
    if "glitch" in wz:
        plan["przejscia"] = {"typ": "glitch", "czas": 0.35}
    elif "sport" in wz or "tiktok" in wz or "szybko" in wz:
        plan["przejscia"] = {"typ": "ciecie", "czas": 0.12}
    elif rytm and rytm <= 2.5 and plan["przejscia"]["typ"] == "fade":
        plan["przejscia"] = {"typ": "ciecie", "czas": 0.15}
    elif "blysk" in wz:
        plan["przejscia"] = {"typ": "flash", "czas": 0.3}
    elif "przenikanie" in wz or "wolno" in wz or "sen" in wz or "kinowy" in wz:
        plan["przejscia"] = {"typ": "fade", "czas": 1.0 if "wolno" in wz else 0.8}
    elif "panoram" in wz:
        plan["przejscia"] = {"typ": "wipe", "czas": 0.6}

    # --- muzyka / rytm
    if "muzyka" in wz and has_music:
        plan["beat_sync"] = True

    # --- fps
    fps = _num_after(t, r"fps|kl/s|klatek na sekund\w*", None, 12.0, 60.0)
    if fps:
        plan["fps"] = int(fps)
        pod.append("%d fps" % int(fps))

    # --- dopasowanie kadru
    if "rozciagn" in t or "stretch" in t:
        plan["dopasowanie"] = "stretch"
    elif "calosc" in t or "całe" in t or "cale" in t or "letterbox" in t or "czarne pasy" in t:
        plan["dopasowanie"] = "contain"
        pod.append("cale zdjecie (bez przycinania)")

    # --- nazwa planu
    czesci = []
    for w in ("kinowy", "tiktok", "retro", "bw", "sepia", "mrok", "jasno", "sen",
              "glitch", "sport", "vlog", "nostalgi", "portret"):
        if w in wz:
            czesci.append(w.upper())
    plan["nazwa"] = " ".join(czesci[:3]) if czesci else "Wlasny"
    plan["dopisek"] = ("AI rozpoznalo: " + ", ".join(wz[:8])) if wz else "AI nie znalazlo slow-kluczy — uzywam ustawien neutralnych."

    # --- nauka lokalna: podciagnij w strone wczesniejszych wyborow
    plan = _LEARNING.apply_learning(plan)

    plan["klip_s"] = float(max(0.4, min(20.0, plan["klip_s"])))
    plan["przejscia"]["czas"] = float(max(0.08, min(2.5, plan["przejscia"]["czas"])))
    plan["fps"] = int(max(12, min(60, plan["fps"])))
    return plan


def plan_text(plan, n_photos=1, music=""):
    """Czytelny opis planu — to widzi uzytkownik przy akceptacji promptu."""
    try:
        seg = plan["klip_s"] * max(1, n_photos)
        if plan.get("cel_s"):
            seg = plan["cel_s"]
        lines = [
            "Styl: %s" % plan.get("nazwa", "-"),
            "Ruch kamery: %s (sila %.2f%s)" % (
                plan["ruch"]["typ"], plan["ruch"]["amp"],
                ", obrot %.1f st." % plan["ruch"]["obrot"] if plan["ruch"]["obrot"] else ""),
            "Ciecie co: %.1f s   •   Przejscie: %s (%.1f s)" % (
                plan["klip_s"], plan["przejscia"]["typ"], plan["przejscia"]["czas"]),
            "Obraz: kolory %s, ziarno %.0f, winieta %.0f%%, rozmycie %.1f" % (
                plan["obraz"]["kol"], plan["obraz"]["ziarno"],
                plan["obraz"]["winieta"] * 100, plan["obraz"]["rozmycie"]),
            "Format: %dx%d @ %d fps" % (plan["rozmiar"][0], plan["rozmiar"][1], plan["fps"]),
            "Dlugosc: ok. %s" % _fmt(seg),
            "Rytm: %s" % ("ciecia w rytm muzyki" + (" (%s)" % os.path.basename(music) if music else "")
                          if plan.get("beat_sync") else "rowne ciecia"),
            "Zdjec: %d" % n_photos,
        ]
        if plan.get("dopisek"):
            lines.append(plan["dopisek"])
        return "\n".join(lines)
    except Exception:
        return "Plan podstawowy."


def _fmt(s):
    try:
        s = int(round(float(s)))
        return "%d:%02d" % (s // 60, s % 60)
    except Exception:
        return "0:00"


_LEARNING = AILearning()


def learning():
    return _LEARNING


# ================================================================ UDERZENIA/CUTS
def build_segments(n_photos, plan, music_path="", music_duration=0.0):
    """
    Zwraca liste (index_zdjecia, start_s, dlugosc_s) — ciecia w rytm muzyki,
    a gdy w muzyce nie ma wyraznych uderzen (albo nie ma muzyki) — rowne ciecia.
    """
    n = max(1, int(n_photos))
    total_target = float(plan.get("cel_s") or 0.0)
    if not total_target:
        total_target = float(plan["klip_s"]) * n
    total_target = max(0.6, total_target)

    def _even_cuts():
        step = (max(0.4, total_target / float(n)) if not plan.get("cel_s")
                else max(0.4, float(plan["klip_s"])))
        k = max(1, int(round(total_target / step)))
        return [i * (total_target / k) for i in range(k + 1)]

    def _dedupe(vals, min_gap):
        out = []
        for v in sorted(set(round(float(x), 4) for x in vals)):
            if not out or v - out[-1] >= min_gap:
                out.append(v)
        return out

    def _segs_from(cuts):
        cuts = sorted(set([0.0] + [float(c) for c in cuts if c < total_target - 0.05]))
        cuts.append(total_target)
        out = []
        for i in range(len(cuts) - 1):
            a, b = cuts[i], cuts[i + 1]
            if b - a < 0.15:
                continue
            out.append((i % n, a, b - a))
        if not out:
            out = [(0, 0.0, total_target)]
        return out

    # --- proba: ciecia w rytm muzyki ---
    beat_marks = []
    if plan.get("beat_sync") and music_path and HAS_AT and decode_audio is not None:
        try:
            data, sr = decode_audio(music_path)
            if data is not None and len(data):
                beat_marks = beat_times(data, sr, max_beats=400)
                music_duration = music_duration or (len(data) / float(sr))
        except Exception:
            beat_marks = []

    if beat_marks and music_duration > 0:
        scale = total_target / float(music_duration)
        gap = max(0.35, min(1.2, float(plan["klip_s"]) * 0.45))
        cuts = _dedupe([b * scale for b in beat_marks], gap) + [total_target]
        segs = _segs_from(cuts)
        if len(segs) >= 2:
            return segs
        # muzyka bez wyraznych uderzen → rowne ciecia
    return _segs_from(_even_cuts())


# ==================================================================== OBRAZ
def _imread_unicode(path):
    """cv2.imread nie radzi sobie z polskimi znakami w sciezce."""
    if not HAS_CV2:
        return None
    try:
        buf = np.fromfile(path, dtype=np.uint8)
        return cv2.imdecode(buf, cv2.IMREAD_COLOR)
    except Exception:
        try:
            return cv2.imread(path, cv2.IMREAD_COLOR)
        except Exception:
            return None


def _fit(img, W, H, mode="fill"):
    ih, iw = img.shape[:2]
    if mode == "stretch":
        return cv2.resize(img, (W, H), interpolation=cv2.INTER_AREA)
    sx, sy = W / float(iw), H / float(ih)
    s = max(sx, sy) if mode == "fill" else min(sx, sy)
    nw, nh = max(1, int(round(iw * s))), max(1, int(round(ih * s)))
    r = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_LINEAR)
    if mode == "fill":
        x = max(0, (nw - W) // 2)
        y = max(0, (nh - H) // 2)
        return r[y:y + H, x:x + W].copy()
    canvas = np.zeros((H, W, 3), dtype=np.uint8)
    y = max(0, (H - nh) // 2)
    x = max(0, (W - nw) // 2)
    canvas[y:y + nh, x:x + nw] = r[:min(nh, H), :min(nw, W)]
    return canvas


def prepare_photo(path, W, H, mode="fill", overscan=1.0):
    """Wczytuje i skaluje zdjecie (z zapasem na ruch kamery)."""
    img = _imread_unicode(path)
    if img is None:
        return None
    try:
        if overscan and overscan > 1.001:
            base = _fit(img, W, H, mode)
            bw, bh = int(W * overscan), int(H * overscan)
            img2 = _fit(img, bw, bh, mode)
            x = max(0, (bw - W) // 2)
            y = max(0, (bh - H) // 2)
            return img2[y:y + H, x:x + W].copy()
        return _fit(img, W, H, mode)
    except Exception:
        return None


def _vignette_mask(W, H, strength):
    if strength <= 0:
        return None
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    cx, cy = W / 2.0, H / 2.0
    d = np.sqrt(((xx - cx) / cx) ** 2 + ((yy - cy) / cy) ** 2)
    m = 1.0 - strength * np.clip(d / 1.42, 0.0, 1.0) ** 1.6
    return np.clip(m, 0.0, 1.0)[:, :, None]


# wzmocnienia kanalow (B, G, R) — realizowane tablica LUT (bardzo szybko)
_KOL_GAIN = {
    "cieply": (0.93, 1.00, 1.10),
    "zimny": (1.14, 1.00, 0.90),
    "kinowy": (1.06, 0.98, 1.06),
    "jasno": (0.98, 1.02, 1.08),
}
# mieszanie kanalow dla sepii/wintage (wiersze: B, G, R)
_KOL_MIX = {
    "sepia": ((0.272, 0.534, 0.131), (0.349, 0.686, 0.168), (0.393, 0.769, 0.189)),
    "vintage": ((0.31, 0.60, 0.15), (0.36, 0.63, 0.19), (0.44, 0.72, 0.26)),
}


def _gain_lut(gains):
    lut = np.zeros((1, 256, 3), dtype=np.uint8)
    for c, k in enumerate(gains):
        lut[0, :, c] = np.clip(np.arange(256, dtype=np.float32) * float(k), 0, 255).astype(np.uint8)
    return lut


_LUT_CACHE = {}


def _color_look(img, kind):
    """Look liczony operacjami uint8 (LUT / addWeighted) — szybko i bez psucia jakosci."""
    try:
        if kind in (None, "", "normal"):
            return img
        if kind == "bw":
            g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            return cv2.cvtColor(g, cv2.COLOR_GRAY2BGR)
        if kind in _KOL_GAIN:
            lut = _LUT_CACHE.get(kind)
            if lut is None:
                lut = _gain_lut(_KOL_GAIN[kind])
                _LUT_CACHE[kind] = lut
            return cv2.LUT(img, lut)
        if kind in _KOL_MIX:
            mix = _KOL_MIX[kind]
            b, g, r = cv2.split(img)
            out_b = cv2.addWeighted(b, mix[0][0], g, mix[0][1], 0.0)
            out_b = cv2.addWeighted(out_b, 1.0, r, mix[0][2], 0.0)
            out_g = cv2.addWeighted(b, mix[1][0], g, mix[1][1], 0.0)
            out_g = cv2.addWeighted(out_g, 1.0, r, mix[1][2], 0.0)
            out_r = cv2.addWeighted(b, mix[2][0], g, mix[2][1], 0.0)
            out_r = cv2.addWeighted(out_r, 1.0, r, mix[2][2], 0.0)
            out = cv2.merge([out_b, out_g, out_r])
            if kind == "vintage":
                out = cv2.add(out, np.array([12, 8, 4], dtype=np.uint8))
            return out
        if kind == "sen":
            blur = cv2.GaussianBlur(img, (0, 0), 2.2)
            return cv2.addWeighted(img, 0.55, blur, 0.45, 12)
    except Exception:
        pass
    return img


class PostFX:
    """Ziarno, winieta, rozmycie, kolor, jasnosc, migotanie — liczone lokalnie."""

    def __init__(self, ob, W, H, seed=1234):
        """ob = sekcja 'obraz' planu: ziarno, winieta, kolory, rozmycie."""
        self.W, self.H = W, H
        self.ziarno = float(ob.get("ziarno", 0.0))
        self.winieta = float(ob.get("winieta", 0.0))
        self.rozmycie = float(ob.get("rozmycie", 0.0))
        self.jasnosc = float(ob.get("jasnosc", 1.0))
        self.kontrast = float(ob.get("kontrast", 1.0))
        self.nasycenie = float(ob.get("nasycenie", 1.0))
        self.kol = ob.get("kol", "normal")
        self.migotanie = float(ob.get("migotanie", 0.0))
        self.mask = _vignette_mask(W, H, self.winieta) if self.winieta > 0 else None
        self.mask8 = None
        if self.mask is not None:
            try:
                self.mask8 = (self.mask * 255.0).astype(np.uint8)
            except Exception:
                self.mask8 = None
        # tablica LUT dla jasnosci i kontrastu (zamiast operacji na float)
        self.lut = None
        if self.jasnosc != 1.0 or self.kontrast != 1.0:
            x = np.arange(256, dtype=np.float32) / 255.0
            y = (x - 0.5) * self.kontrast + 0.5
            y *= self.jasnosc
            self.lut = np.clip(y * 255.0, 0, 255).astype(np.uint8).reshape(1, 256)
        self.rng = np.random.default_rng(seed)
        self._grain_shape = (max(2, H // 2), max(2, W // 2))

    def apply(self, img):
        """Klatka po klatce: look → rozmycie → jasnosc/kontrast → nasycenie →
        migotanie → winieta → ziarno. Wszystko na uint8 (szybko, bez float)."""
        try:
            if self.kol != "normal":
                img = _color_look(img, self.kol)
            if self.rozmycie > 0:
                img = cv2.GaussianBlur(img, (0, 0), self.rozmycie)
            if self.lut is not None:
                img = cv2.LUT(img, self.lut)
            if self.nasycenie != 1.0:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                gray3 = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
                img = cv2.addWeighted(img, self.nasycenie, gray3,
                                      1.0 - self.nasycenie, 0.0)
            if self.migotanie > 0:
                k = 1.0 + self.rng.uniform(-self.migotanie, self.migotanie)
                img = cv2.convertScaleAbs(img, alpha=float(k), beta=0.0)
            if self.mask8 is not None:
                img = cv2.multiply(img, self.mask8, scale=1.0 / 255.0)
            if self.ziarno > 0:
                z = int(round(self.ziarno))
                small = self.rng.integers(0, 2 * z + 1, self._grain_shape,
                                          dtype=np.uint8)
                n1 = cv2.resize(small, (self.W, self.H),
                                interpolation=cv2.INTER_LINEAR)
                n3 = cv2.cvtColor(n1, cv2.COLOR_GRAY2BGR).astype(np.int16) - z
                pos = np.clip(n3, 0, 255).astype(np.uint8)
                neg = np.clip(-n3, 0, 255).astype(np.uint8)
                img = cv2.subtract(cv2.add(img, pos), neg)
        except Exception:
            pass
        return img


_WRITER_CHOICE = {"combo": None}


def _candidate_combos():
    """Kolejnosc prob: H.264 (Windows Media Foundation) → mp4v → MJPG."""
    combos = []
    try:
        if hasattr(cv2, "CAP_MSMF"):
            combos.append((cv2.CAP_MSMF, "H264", ".mp4"))
            combos.append((cv2.CAP_MSMF, "mp4v", ".mp4"))
    except Exception:
        pass
    combos.append((None, "mp4v", ".mp4"))
    combos.append((None, "MJPG", ".avi"))
    return combos


def _probe_combo(api, fourcc, ext, size, fps):
    """Szybki test (3 klatki): czy kodek naprawde dziala i daje czytelny plik."""
    import tempfile
    W, H = size
    path = os.path.join(tempfile.gettempdir(), "r12probe" + ext)
    try:
        try:
            cv2.utils.logging.setLogLevel(cv2.utils.logging.LOG_LEVEL_SILENT)
        except Exception:
            pass
        four = cv2.VideoWriter_fourcc(*fourcc)
        w = (cv2.VideoWriter(path, api, four, float(fps), (W, H)) if api
             else cv2.VideoWriter(path, four, float(fps), (W, H)))
        if w is None or not w.isOpened():
            try:
                w.release()
            except Exception:
                pass
            return False
        blank = np.zeros((H, W, 3), dtype=np.uint8)
        for _ in range(3):
            w.write(blank)
        w.release()
        if not os.path.isfile(path) or os.path.getsize(path) < 300:
            return False
        cap = cv2.VideoCapture(path)
        n = 0
        while n < 10:
            ok, _f = cap.read()
            if not ok:
                break
            n += 1
        cap.release()
        try:
            os.remove(path)
        except Exception:
            pass
        return n >= 3
    except Exception:
        try:
            if os.path.isfile(path):
                os.remove(path)
        except Exception:
            pass
        return False
    finally:
        try:
            cv2.utils.logging.setLogLevel(cv2.utils.logging.LOG_LEVEL_WARNING)
        except Exception:
            pass


def _open_writer(path, fps, size):
    """Otwiera zapis video mozliwie najmniejszym/najlepszym kodekiem.

    H.264 z Windows Media Foundation daje kilkanascie razy mniejsze pliki niz
    mp4v — dlatego probujemy go najpierw, a gdy nie ma — schodzimy nizej.
    Wybor kodeka jest testowany 3 klatkami i zapamietywany na dalsze rendery.
    """
    W, H = size
    wybrany = _WRITER_CHOICE.get("combo")
    combos = _candidate_combos()
    if isinstance(wybrany, tuple) and wybrany in combos:
        combos = [wybrany] + [c for c in combos if c != wybrany]
    for api, fourcc, ext in combos:
        p = os.path.splitext(path)[0] + ext
        try:
            if not _probe_combo(api, fourcc, ext, (W, H), fps):
                continue
            four = cv2.VideoWriter_fourcc(*fourcc)
            w = (cv2.VideoWriter(p, api, four, float(fps), (W, H)) if api
                 else cv2.VideoWriter(p, four, float(fps), (W, H)))
            if w is not None and w.isOpened():
                _WRITER_CHOICE["combo"] = (api, fourcc, ext)
                return w, p, fourcc
            try:
                w.release()
            except Exception:
                pass
        except Exception:
            continue
    return None, path, ""


def render(photos, plan, out_path, progress=None, cancel=None, log=None):
    """
    Renderuje film. Zwraca (ok, komunikat, sciezka, statystyki).
    Wszystko offline, w tle (progress / cancel obsluguje UI).
    """
    def _log(m):
        try:
            if callable(log):
                log(m)
        except Exception:
            pass

    if not HAS_CV2 or not HAS_NUMPY:
        return False, "Brak OpenCV/numpy — uruchom INSTALUJ.bat", "", {}
    photos = [p for p in photos if os.path.isfile(p)]
    if not photos:
        return False, "Nie wybrano zdjec.", "", {}

    W, H = plan["rozmiar"]
    fps = int(plan["fps"])
    mg = float(plan["ruch"].get("amp", 0.12))
    overscan = 1.0 + max(0.12, mg * 1.6) + (0.06 if plan["ruch"].get("shak") else 0.0)

    segs = build_segments(len(photos), plan, plan.get("beat_plik", ""))
    total = segs[-1][1] + segs[-1][2]
    total_frames = max(1, int(round(total * fps)))
    _log("Render: %d zdjec, %d klatek, %.1f s, %dx%d @ %dfps" % (
        len(photos), total_frames, total, W, H, fps))
    if plan.get("beat_sync"):
        _log("Ciecia: %d segmentow (%s)" % (
            len(segs), "w rytm muzyki" if plan.get("beat_plik") else "rowne"))

    imgs = []
    for i, p in enumerate(photos):
        im = prepare_photo(p, W, H, plan.get("dopasowanie", "fill"), overscan)
        if im is None:
            _log("Pominieto (nie moge wczytac): " + os.path.basename(p))
        imgs.append(im)
    if all(im is None for im in imgs):
        return False, "Zadnego zdjecia nie udalo sie wczytac.", "", {}

    fx = PostFX(plan["obraz"], W, H)
    tr = plan["przejscia"]
    tr_type, tr_t = tr.get("typ", "fade"), float(tr.get("czas", 0.8))
    rng = np.random.default_rng(7)

    writer, real_path, codec = _open_writer(out_path, fps, (W, H))
    if writer is None:
        return False, "Nie moge utworzyc pliku video (kodek).", "", {}
    _log("Zapis: %s (kodek %s)" % (os.path.basename(real_path), codec))

    seg_for = [s for s in segs if imgs[s[0]] is not None]
    if not seg_for:
        try:
            writer.release()
        except Exception:
            pass
        return False, "Brak zdjec do renderu.", "", {}

    def frame_of(photo_idx, local):
        """Klatka pojedynczego zdjecia z ruchem kamery (local 0..1)."""
        img = imgs[photo_idx]
        if img is None:
            return np.zeros((H, W, 3), dtype=np.uint8)
        typ = plan["ruch"].get("typ", "kenburns")
        amp = float(plan["ruch"].get("amp", 0.0))
        if typ == "static" or amp <= 0.0:
            return img.copy()
        t = max(0.0, min(1.0, float(local)))
        s = 1.0 + amp * 0.5
        dx = dy = 0.0
        ang = 0.0
        if typ == "zoom_in":
            s = 1.0 + amp * t
        elif typ == "zoom_out":
            s = 1.0 + amp * (1.0 - t)
        elif typ == "kenburns":
            s = 1.0 + amp * (0.35 + 0.65 * t)
            dx = (t - 0.5) * amp * 0.7 * W
            dy = (0.5 - t) * amp * 0.4 * H
        elif typ == "pan_lr":
            s = 1.0 + amp * 0.7
            dx = (t - 0.5) * amp * 1.5 * W
        elif typ == "pan_rl":
            s = 1.0 + amp * 0.7
            dx = (0.5 - t) * amp * 1.5 * W
        elif typ == "orbit":
            s = 1.0 + amp * 0.5
            ang = float(plan["ruch"].get("obrot", 1.2)) * (t - 0.5)
            dx = (t - 0.5) * amp * 0.8 * W
        shak = float(plan["ruch"].get("shak", 0.0))
        if shak > 0:
            ph = t * 24.0
            dx += math.sin(ph * 2.3) * shak * 0.012 * W
            dy += math.cos(ph * 3.1) * shak * 0.012 * H
            ang += math.sin(ph * 1.7) * shak * 0.5
        M = cv2.getRotationMatrix2D((W / 2.0, H / 2.0), ang, s)
        M[0, 2] += dx
        M[1, 2] += dy
        return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LINEAR,
                              borderMode=cv2.BORDER_REFLECT101)

    def blend(a, b, alpha):
        return cv2.addWeighted(a, 1.0 - alpha, b, alpha, 0)

    def trans_frame(fa, fb, a):
        """Przejscie: fade / wipe / flash / glitch / ciecie."""
        try:
            if tr_type == "wipe":
                cut = int(W * a)
                out = fa.copy()
                if cut < W:
                    out[:, cut:] = fb[:, cut:]
                if 0 < cut < W:
                    out[:, max(0, cut - 3):cut + 3] = 200
                return out
            if tr_type == "flash":
                base = blend(fa, fb, a)
                k = 1.0 - abs(a - 0.5) * 2.0
                return np.clip(base.astype(np.float32) + 255.0 * k * 0.85, 0, 255).astype(np.uint8)
            if tr_type == "glitch":
                if a < 0.5:
                    out = fa.copy()
                else:
                    out = fb.copy()
                for _ in range(4):
                    y = int(rng.integers(0, max(1, H - 8)))
                    h = int(rng.integers(3, 26))
                    sh = int(rng.integers(-40, 40))
                    out[y:y + h] = np.roll(out[y:y + h], sh, axis=1)
                b, g, r = cv2.split(out)
                r = np.roll(r, int(rng.integers(3, 9)), axis=1)
                b = np.roll(b, -int(rng.integers(3, 9)), axis=1)
                return cv2.merge([b, g, r])
            if tr_type == "ciecie":
                return fb if a >= 0.5 else fa
            return blend(fa, fb, a)          # fade (domyslnie)
        except Exception:
            return fb if a > 0.5 else fa

    def render_frame():
        raise RuntimeError("nieuzywane")

    t0 = time.time()
    written = 0
    for f in range(total_frames):
        if cancel is not None and cancel():
            _log("Render przerwany przez uzytkownika.")
            break
        t = f / float(fps)
        # segment biezacy
        idx = 0
        for i, (pi, st, du) in enumerate(seg_for):
            if st <= t < st + du:
                idx = i
                break
            idx = i
        pi, st, du = seg_for[idx]
        local = (t - st) / du if du > 0 else 0.0
        fa = frame_of(pi, local)

        # przejscie z nastepnym segmentem
        nxt = seg_for[idx + 1] if idx + 1 < len(seg_for) else None
        if nxt is not None and tr_type != "ciecie":
            npi, nst, ndu = nxt
            tt = tr_t
            if t >= st + du - tt and nst - st <= du + 0.001:
                a = (t - (st + du - tt)) / max(1e-3, tt)
                a = max(0.0, min(1.0, a))
                nlocal = max(0.0, (t - nst) / ndu) if ndu > 0 else 0.0
                fb = frame_of(npi, nlocal)
                fa = trans_frame(fa, fb, a)

        frame = fx.apply(fa)
        writer.write(frame)
        written += 1
        if progress is not None and (f % 5 == 0 or f == total_frames - 1):
            try:
                progress(f + 1, total_frames)
            except Exception:
                pass

    try:
        writer.release()
    except Exception:
        pass
    dt = time.time() - t0
    stats = {"klatki": written, "sekundy": written / float(fps),
             "czas_renderu": dt, "sciezka": real_path, "kodek": codec,
             "zdjec": len(photos), "segmenty": len(seg_for),
             "fps_real": (written / dt) if dt > 0 else 0.0}
    try:
        stats["rozmiar_mb"] = round(os.path.getsize(real_path) / (1024.0 * 1024.0), 1)
    except Exception:
        stats["rozmiar_mb"] = 0.0
    if written == 0:
        return False, "Nic nie zapisano.", real_path, stats
    return True, "Gotowe: %s (%d klatek, %.1f s filmu, %.1f MB, render %.0f s)" % (
        os.path.basename(real_path), written, stats["sekundy"],
        stats.get("rozmiar_mb", 0.0), dt), real_path, stats


# ============================================================== SUGESTIA PROMPTU
def suggest_prompt(n_photos=6, has_music=False, music_name="", orientation="portrait"):
    """AI proponuje gotowy prompt, gdy uzytkownik nie ma pomyslu."""
    try:
        if has_music:
            return ("film z %d zdjec w rytm muzyki, szybkie ciecia, mocny zoom, "
                    "kontrast i winieta, pion, 30 sekund" % n_photos)
        if n_photos <= 4:
            return ("kinowy spokojny film z %d zdjec, wolne najazdy, delikatne ziarno, "
                    "przenikanie, lekka winieta, 20 sekund" % n_photos)
        if n_photos >= 12:
            return ("energetyczny film z %d zdjec, ciecia co 2 sekundy, panoramy, "
                    "kontrast, cieply look, 40 sekund" % n_photos)
        return ("vlog dzienny z %d zdjec, naturalne kolory, rytmiczne ciecia 3 sekundy, "
                "lekki ruch kamery" % n_photos)
    except Exception:
        return "kinowy film ze zdjec"


def preset_prompt(name):
    try:
        return PRESETS.get(name, {}).get("prompt", "")
    except Exception:
        return ""


if __name__ == "__main__":
    print("Modul ai_video OK. cv2:", HAS_CV2, "| numpy:", HAS_NUMPY, "| audio_timeline:", HAS_AT)
    for n, p in list(PRESETS.items())[:3]:
        pl = parse_prompt(p["prompt"], 8, True)
        print(" -", n, "->", pl["nazwa"], "klip %.1fs" % pl["klip_s"], pl["przejscia"]["typ"])
