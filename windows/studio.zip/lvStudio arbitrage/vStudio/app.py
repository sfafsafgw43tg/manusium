# -*- coding: utf-8 -*-
"""
vStudio Mobile  •  v1.5  •  wirtualna KAMERA + MIKROFON dla telefonow i
emulatorow Androida (Android Studio)  •  100% OFFLINE.

Tryb mobilny wlacza OctoBrowser, zapisujac sekcje "mobile" w config.json:
nazwa urzadzenia, nazwy kamery i mikrofonu oraz rozdzielczosc telefonu. Gdy
jest wlaczony, aplikacja nazywa sie "vStudio Mobile", kadr jest dopasowany do
ekranu telefonu, a na gorze widac dokladnie te nazwy, ktore trzeba wybrac
w Androidzie.

Start (Windows): dwuklik START_VSTUDIO.bat
"""
import json
import os
import sys
import threading
import time
import traceback
import webbrowser
from datetime import datetime
from pathlib import Path

APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)
os.chdir(APP_DIR)

CONFIG_PATH = os.path.join(APP_DIR, "config.json")

DEFAULT_CONFIG = {
    "device_names": {"camera": "vStudio", "microphone": "vStudio"},
    # Tryb mobilny (emulator Androida). Ustawiany przez OctoBrowser.
    "mobile": {
        "enabled": False, "device": "", "handset": "",
        "camera": "", "microphone": "", "width": 0, "height": 0,
        "target": "", "fps": 0, "media_folder": "",
    },
    # One-shot command written by Octo.su. A unique token prevents the polling
    # loop from undoing a manual Stop after it has handled the request once.
    "octobrowser": {"broadcastRequest": ""},
    "video": {
        "format_id": "realme12pro", "fit_mode": "fill", "filter": "normal",
        "fps": 30, "backend": "auto",
        "slideshow_mode": "auto", "slideshow_interval": 6.0,
        "transition": "fade", "effect_shake": True, "effect_shake_amount": 4.0,
        "effect_grain": True, "effect_grain_amount": 6.0,
        "effect_vignette": True, "effect_autofocus": True,
        "overlay_rec": True, "overlay_timestamp": True,
        "overlay_brand": True, "overlay_battery": True,
        "mirror": False, "rotate": 0,
        "zoom": 1.0, "pan_x": 0.0, "pan_y": 0.0,
        "orientation": "portrait", "frames": {},
        "input_camera_index": None, "input_camera_name": "",
        "input_rotation": 0, "input_mirror": False,
        "loop_video": True, "loop_blend": 0.35,
    },
    "audio": {
        "profile": "pokoj", "volume": 0.8, "noise_level": 0.5,
        "event_rate": 0.5, "bass": 0.5, "sample_rate": 48000,
        "monitor_locally": False, "auto_random_profile": False,
        "breath_on": True, "breath_level": 0.45, "breath_rate": 13,
        "output_device_name": "", "cable_only": True,
        "music_gain": 0.9, "music_loop": False, "music_files": [],
        "monitor_on": False, "monitor_device_name": "", "monitor_gain": 0.8,
        "record_folder": "", "input_device_name": "", "passthrough_input": False,
    },
    "ai": {"prompt": "", "photos": [], "quality": "1080p", "music_name": ""},
    "tts": {"text": "", "voice": "", "rate": 0, "volume": 90},
    # klucze API — DOMYŚLNIE offline (patrz cloud_net.DEFAULTS; trzymamy je
    # tylko w config.json, nigdy w presetach ani w dzienniku)
    "net": {
        "provider": "offline", "base_url": "https://api.openai.com/v1",
        "key_tts": "", "key_ai": "",
        "tts_model": "gpt-4o-mini-tts", "tts_voice": "alloy", "ai_model": "gpt-4o-mini",
        "consent_tts": False, "consent_ai": False, "ai_send_photos": False,
        "ai_thumb_px": 384, "remember_keys": True, "timeout_s": 30,
    },
    # Interfejs: angielski jest podstawa, polski do wyboru w Ustawieniach.
    "ui": {"theme": "obsidian", "language": "en", "autosave": True},
}


def load_config():
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    try:
        if os.path.isfile(CONFIG_PATH):
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                user = json.load(f)
            # scalamy kazda sekcje opisana w DEFAULT_CONFIG (w tym "ai" —
            # dawniej pomijana, przez co ustawienia zakladki AI Wideo
            # zapisywane przy zamknieciu przepadaly przy nastepnym starcie)
            for section, defaults in DEFAULT_CONFIG.items():
                if isinstance(defaults, dict) and isinstance(user.get(section), dict):
                    cfg.setdefault(section, {}).update(user[section])
    except Exception:
        pass
    return cfg


def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


CFG = load_config()

# When vStudio is started directly, discover the live emulator before the
# mobile format is built. OctoBrowser's saved selection remains preferred.
AUTO_ANDROID = None
try:
    import virtual_devices as VD
    HAS_VD = True
    _preferred = str((CFG.get("mobile", {}) or {}).get("device", "") or "")
    AUTO_ANDROID = VD.connect_running_android(_preferred)
    if AUTO_ANDROID:
        mobile = CFG.setdefault("mobile", {})
        mobile["enabled"] = True
        mobile["device"] = AUTO_ANDROID.get("avd") or mobile.get("device", "")
        mobile["handset"] = AUTO_ANDROID.get("label") or mobile.get("handset", "")
        if AUTO_ANDROID.get("width") and AUTO_ANDROID.get("height"):
            mobile["width"], mobile["height"] = AUTO_ANDROID["width"], AUTO_ANDROID["height"]
        save_config(CFG)
except Exception:
    VD = None
    HAS_VD = False

# ------------------------------------------------------------------ jezyk UI
# Angielski jest jezykiem podstawowym; polski wlacza sie w Ustawieniach
# (ui.language = "pl"). Tlumaczenie dziala przez slownik nakladany na teksty
# widgetow, wiec nie trzeba przepisywac calego pliku - a napis, ktorego nie ma
# w slowniku, zostaje taki jak byl.
LANG = str((CFG.get("ui", {}) or {}).get("language", "en") or "en").lower()

UI_PL_EN = {
    # pasek gorny / ogolne
    "Kamera": "Camera", "Mikrofon": "Microphone", "nadaje": "live", "wyłączony": "off",
    "Urządzenia": "Devices", "Pomoc": "Help", "⚙ Ustawienia": "⚙ Settings", "Ustawienia": "Settings",
    "▶   Start nadawania": "▶   Start streaming", "■   Stop nadawania": "■   Stop streaming",
    "Start nadawania": "Start streaming", "Stop nadawania": "Stop streaming",
    # biblioteka
    "Biblioteka": "Library", "+ Dodaj": "+ Add", "Folder": "Folder",
    "Pusto.": "Empty.", "Dodaj zdjęcia lub nagrania.": "Add photos or videos.",
    "◀  Poprzednie": "◀  Previous", "Następne  ▶": "Next  ▶",
    "Usuń zaznaczony": "Remove selected", "Wyczyść listę": "Clear list",
    # podglad
    "Podgląd": "Preview", "brak mediów": "no media", "Pionowo": "Portrait", "Poziomo": "Landscape",
    "Silnik:": "Engine:", "Dziennik": "Log",
    # zakladki
    "Dźwięk": "Sound", "Audio": "Audio", "Mowa (TTS)": "Speech", "Prywatność": "Privacy",
    "Obraz": "Picture", "Kadr": "Framing", "Efekty": "Effects",
    "Dźwięk i audio": "Sound and music",
    # okna pomocnicze
    "Wybór i zmiana nazwy kamery wirtualnej": "Choose and rename the virtual camera",
    "Wybór i zmiana nazwy kamery wirtualnej (DirectShow / OBS / Unity) oraz mikrofonu":
        "Choose and rename the virtual camera (Unity Capture) and the microphone",
    "Nazwa kamery w systemie": "Camera name in Windows",
    "Kamery DirectShow (widzą je programy)": "Cameras other programs can see",
    "Sterownik OBS Virtual Camera": "OBS Virtual Camera driver",
    "Silnik Unity Video Capture": "Unity Capture engine",
    "VB-CABLE (wirtualny mikrofon)": "VB-CABLE (virtual microphone)",
    "zainstalowane": "installed", "zarejestrowany": "registered", "wykryto": "found",
    "nie wykryto": "not found", "włączony": "on", "wyłączony": "off",
    # sekcje dzwieku
    "SCENERIA": "SCENE", "POZIOMY": "LEVELS", "Głośność": "Volume", "Poziom szumu": "Noise level",
    "Częstotliwość zdarzeń": "Event rate", "Niskie tony": "Bass",
    "Cichy pokój": "Quiet room", "Ulica / miasto": "Street / city", "Wiatr": "Wind",
    "Tłum / kawiarnia": "Crowd / cafe", "Samochód / jazda": "Car / driving", "Deszcz": "Rain",
    "Noc / sypialnia": "Night / bedroom", "Losowy AI (zmienia scenerię)": "Random AI (changes the scene)",
    # urzadzenia wirtualne
    "Urządzenia wirtualne": "Virtual devices",
    "Odśwież status": "Refresh status", "Diagnozuj kamerę (raport TXT)": "Diagnose camera (TXT report)",
    "Wybierz z listy:": "Pick from the list:", "Wpisz / edytuj nazwę:": "Type / edit the name:",
    "💾  Ustaw w vStudio": "💾  Apply in vStudio Mobile",
    "⚡ Zmień nazwę w systemie (Admin)": "⚡ Rename in Windows (Admin)",
    "Zamknij": "Close", "Anuluj": "Cancel", "Zapisz": "Save", "OK": "OK",
}


def tr(text):
    """Przetlumacz napis interfejsu na angielski (jesli jezyk = en)."""
    if LANG.startswith("pl") or not isinstance(text, str) or not text:
        return text
    return UI_PL_EN.get(text.strip(), text)


# ------------------------------------------------------------------ tryb mobilny
MOBILE = CFG.get("mobile", {}) or {}
MOBILE_ON = bool(MOBILE.get("enabled"))
# Jedna nazwa, zawsze - niezaleznie od tego, czy OctoBrowser zdazyl juz
# przypisac urzadzenie. Krotka forma idzie tam, gdzie nie ma miejsca.
APP_NAME = "vStudio Mobile"
APP_SHORT = "vS Mobile"
APP_SUBTITLE = ("KAMERA + MIKROFON DLA TELEFONOW I EMULATOROW ANDROIDA  \u2022  OFFLINE"
                if LANG.startswith("pl")
                else "CAMERA + MICROPHONE FOR ANDROID PHONES AND EMULATORS  \u2022  OFFLINE")


def mobile_device_name():
    """Nazwa urzadzenia, ktora widzi Android (np. "Google-Pixel-9")."""
    return str(MOBILE.get("device") or MOBILE.get("handset") or "").strip()


def mobile_camera_name():
    return str(MOBILE.get("camera") or mobile_device_name() or "vStudio Mobile").strip()


def mobile_microphone_name():
    return str(MOBILE.get("microphone") or mobile_device_name() or "vStudio Mobile").strip()


def mobile_resolution():
    """Rozdzielczosc ekranu telefonu z config.json, albo None."""
    try:
        w, h = int(MOBILE.get("width") or 0), int(MOBILE.get("height") or 0)
    except Exception:
        return None
    return (w, h) if w >= 240 and h >= 240 else None

try:
    from phone_formats import PHONE_FORMATS, FIT_MODES, FILTERS, TRANSITIONS, SLIDESHOW_MODES
    try:
        from phone_formats import register_custom_format
    except Exception:
        register_custom_format = None
except Exception:
    PHONE_FORMATS, FIT_MODES, FILTERS, TRANSITIONS, SLIDESHOW_MODES = {}, {}, {}, {}, {}
    register_custom_format = None

# Android's host-webcam bridge models a landscape camera sensor, not the
# handset display. Feeding a 1080x2412 screen-sized DirectShow stream exceeded
# Unity Capture's supported height on several Pixel profiles and CameraProvider
# then failed to open it. Render the editor preview as a conventional 720x1280
# portrait camera frame and rotate only the DirectShow output to 1280x720.
def mobile_stream_resolution():
    # The editor keeps a portrait composition, while DirectShow publishes the
    # conservative VGA sensor format negotiated by Android CameraProvider.
    # Keeping these concerns separate avoids an implicit quarter-turn and the
    # Camera app crashes seen with producer-sized 1280x720 frames.
    display = mobile_resolution()
    if display and display[0] > display[1]:
        return (640, 480)
    return (480, 640)


# Jedyny silnik kamery wirtualnej w trybie mobilnym.
VCAM_BACKEND = "unitycapture" if sys.platform.startswith("win") else "v4l2loopback" if sys.platform.startswith("linux") else "obs"
MOBILE_FORMAT_ID = ""
if MOBILE_ON and register_custom_format:
    _res = mobile_stream_resolution()
    MOBILE_FORMAT_ID = register_custom_format(
        "octo_mobile", _res[0], _res[1],
        "%s  •  %d × %d  (Android camera)" % (mobile_device_name() or "Telefon", _res[0], _res[1]),
        "Webcam-compatible Android camera frame; the phone display size is metadata only.")

try:
    from audio_engine import PhoneNoiseEngine, AUDIO_PROFILES
    HAS_AUDIO = True
except Exception:
    HAS_AUDIO = False
    PhoneNoiseEngine, AUDIO_PROFILES = None, {}

try:
    from video_engine import VideoEngine
    HAS_VIDEO = True
except Exception:
    HAS_VIDEO = False
    VideoEngine = None

try:
    from ui_v13 import V13Mixin, HAS_TIMELINE, HAS_AI
except Exception:
    HAS_TIMELINE = HAS_AI = False
    class V13Mixin(object):
        def _init_v13(self): pass
        def _v13_on_close(self): pass
        def _v13_shutdown(self): pass
        def _v13_restore_music(self): pass
        def _v13_bind_keys(self): pass
        def _v13_tick(self): pass
        def _tab_music(self, tab): pass
        def _tab_ai(self, tab): pass

try:
    from ui_v14 import V14Mixin, HAS_TTS
    HAS_V14 = True
except Exception:
    HAS_TTS = HAS_V14 = False
    class V14Mixin(object):
        def _init_v14(self): pass
        def _build_v14_ui(self): pass
        def _v14_tick(self, force=False): pass
        def _v14_bind_keys(self): pass
        def _v14_on_close(self): pass
        def _tab_tts(self, tab): pass
        def _tab_net(self, tab): pass
        def _open_settings_window(self): pass
        def _open_privacy_info(self): pass

        def _net_scrub(self, msg):
            return msg


try:
    import cloud_net as NET
    HAS_NET = True
except Exception:
    HAS_NET = False
    NET = None

if not HAS_VD:
    try:
        import virtual_devices as VD
        HAS_VD = True
    except Exception:
        HAS_VD = False
        VD = None

HAS_CTK = False
try:
    import customtkinter as ctk
    from tkinter import filedialog, messagebox
    HAS_CTK = True
    BaseTkClass = ctk.CTk
except Exception as e:
    # Automatyczna próba instalacji brakującej biblioteki customtkinter (tylko przy bezpośrednim uruchomieniu)
    if __name__ == "__main__":
        try:
            import subprocess
            print("[vStudio] Sprawdzanie i instalowanie biblioteki customtkinter...")
            subprocess.run([sys.executable, "-m", "pip", "install", "customtkinter", "darkdetect", "--disable-pip-version-check"], check=True)
            import customtkinter as ctk
            from tkinter import filedialog, messagebox
            HAS_CTK = True
            BaseTkClass = ctk.CTk
        except Exception:
            pass
    if not HAS_CTK:
        ctk = None
        class DummyTk:
            def __init__(self, *args, **kwargs): pass
            def title(self, *args, **kwargs): pass
            def geometry(self, *args, **kwargs): pass
            def minsize(self, *args, **kwargs): pass
            def configure(self, *args, **kwargs): pass
            def mainloop(self, *args, **kwargs): pass
            def destroy(self, *args, **kwargs): pass
            def bind(self, *args, **kwargs): pass
            def after(self, *args, **kwargs): pass
            def winfo_children(self): return []
        BaseTkClass = DummyTk
        if __name__ == "__main__":
            print("\n" + "=" * 60)
            print("BLAD: brak biblioteki customtkinter lub srodowiska graficznego.")
            print("Uruchom INSTALUJ.bat lub recznie: pip install -r requirements.txt")
            print("Szczegoly bledu:", e)
            print("=" * 60 + "\n")
            try:
                input("Nacisnij ENTER, aby zamknac...")
            except Exception:
                pass
            sys.exit(1)

try:
    from PIL import Image
    HAS_PIL = True
except Exception:
    HAS_PIL = False
    Image = None

# --- themes shared with Octo.su; Obsidian is the base theme ---
THEMES = {
    "obsidian":    ("#080A0E", "#11141A", "#171B22", "#2B313D", "#9CACBF", "#F1F4F8", "#626D7E", "#DCE4ED", "#8EA2B8"),
    "midnight":    ("#111827", "#1B2740", "#233252", "#35496F", "#91A9D8", "#EDF1FA", "#74819A", "#C2D2F3", "#7088B5"),
    "slate":       ("#20252B", "#303740", "#3A434D", "#53606D", "#A9BAC8", "#F1F3F5", "#8D98A3", "#D5E2EC", "#8499AA"),
    "harbor":      ("#27333B", "#3A4B56", "#455863", "#647A86", "#9EC0C8", "#F3F7F8", "#95A7AD", "#D2EAEE", "#7FAAB3"),
    "silver-fog":  ("#616971", "#7B838B", "#899097", "#A8AEB3", "#E3EEF0", "#FFFFFF", "#D0D5D8", "#FFFFFF", "#C5D6D9"),
    "octo-violet": ("#171325", "#2A2240", "#342A4E", "#50416D", "#AE8FE8", "#F2EFF8", "#9185AC", "#D7C6FF", "#8E6FD0"),
    "porcelain":   ("#F5F6F7", "#FFFFFF", "#F2F4F6", "#D2D8DD", "#5077A1", "#1E2730", "#798692", "#345B85", "#D8E6F2"),
    "aurora":      ("#102226", "#1E3A42", "#274952", "#3F6C75", "#71C8C5", "#ECF8F8", "#7FA4A8", "#B1EEEE", "#55AAA8"),
    "forest-dusk": ("#182119", "#2A382B", "#354635", "#526952", "#A8C78A", "#EFF5ED", "#91A38E", "#D8F0C2", "#89AE6A"),
}
THEME_NAMES = ["Obsidian", "Midnight", "Slate", "Harbor", "Silver Fog", "Octo Violet", "Porcelain", "Aurora", "Forest Dusk"]
THEME_IDS = ["obsidian", "midnight", "slate", "harbor", "silver-fog", "octo-violet", "porcelain", "aurora", "forest-dusk"]

def _activate_palette(theme_id):
    global BG, CARD, CARD2, LINE, MUTED, TEXT, DIM, WHITE, WHITE_HOVER
    selected = str(theme_id or "obsidian").lower()
    if selected == "dark":
        selected = "obsidian"
    if selected not in THEMES:
        selected = "obsidian"
    BG, CARD, CARD2, LINE, MUTED, TEXT, DIM, WHITE, ACCENT_COLOR = THEMES[selected]
    WHITE_HOVER = MUTED
    GHOST.update(fg_color="transparent", border_width=1, border_color=LINE,
                 text_color=TEXT, corner_radius=10, hover_color=CARD2)
    PRIMARY.update(fg_color=WHITE, text_color=BG, hover_color=MUTED, corner_radius=10)
    ACCENT.update(fg_color=ACCENT_COLOR, text_color=BG, hover_color=MUTED, corner_radius=10)
    OPTION_MENU.update(fg_color=WHITE, text_color=BG, button_color=MUTED,
                       button_hover_color=DIM, dropdown_fg_color=CARD,
                       dropdown_text_color=TEXT, dropdown_hover_color=CARD2,
                       corner_radius=10)
    # ui_v13/ui_v14 are mixins with their own module-level palette constants.
    # Keep them on exactly the same Octo theme before they create any widgets.
    for module_name in ("ui_v13", "ui_v14"):
        module = sys.modules.get(module_name)
        if not module:
            continue
        for key in ("BG", "CARD", "CARD2", "LINE", "MUTED", "TEXT", "DIM", "WHITE"):
            setattr(module, key, globals()[key])
        for key in ("GHOST", "PRIMARY", "ACCENT", "OPTION_MENU"):
            if hasattr(module, key):
                getattr(module, key).update(globals()[key])
    return selected

# Dicts are updated in place because mixins import and retain these objects.
GHOST, PRIMARY, ACCENT, OPTION_MENU = {}, {}, {}, {}
THEME_ID = _activate_palette((CFG.get("ui") or {}).get("theme", "obsidian"))
CFG.setdefault("ui", {})["theme"] = THEME_ID

BACKEND_LABELS = {"auto": "Auto", "obs": "OBS Studio", "unitycapture": "Unity Capture"}

if HAS_CTK:
    try:
        ctk.set_appearance_mode("dark")
        _theme = os.path.join(APP_DIR, "assets", "theme_mono.json")
        if os.path.isfile(_theme):
            ctk.set_default_color_theme(_theme)
        else:
            ctk.set_default_color_theme("green")
    except Exception:
        pass


# Angielski interfejs bez przepisywania kazdego okna: napisy widgetow ida
# przez slownik. Polski (ui.language = "pl") omija go w calosci.
def _translate_ctk_widgets():
    if LANG.startswith("pl"):
        return
    for attr in ("CTkLabel", "CTkButton", "CTkCheckBox", "CTkRadioButton", "CTkSwitch"):
        base = getattr(ctk, attr, None)
        if base is None or getattr(base, "_octo_tr", False):
            continue

        class Translated(base):          # noqa: N801  (nazwa klasy jak w ctk)
            _octo_tr = True

            def __init__(self, *args, **kwargs):
                if "text" in kwargs:
                    kwargs["text"] = tr(kwargs["text"])
                super().__init__(*args, **kwargs)

            def configure(self, *args, **kwargs):
                if "text" in kwargs:
                    kwargs["text"] = tr(kwargs["text"])
                return super().configure(*args, **kwargs)

        setattr(ctk, attr, Translated)


_translate_ctk_widgets()


# ================================================================== APLIKACJA
class VStudioApp(V14Mixin, V13Mixin, BaseTkClass):
    def __init__(self):
        super().__init__()
        device = mobile_device_name()
        self.title("%s  \u2022  %s" % (APP_NAME, device if device else ("OFFLINE" if not LANG.startswith("pl") else "OFFLINE")))
        # Mobile mode is a compact phone console, not a three-monitor editor.
        # It still scales up, but remains usable on a normal 1080p laptop.
        self.geometry("1180x920" if MOBILE_ON else "1440x920")
        self.minsize(1040 if MOBILE_ON else 1280, 780 if MOBILE_ON else 820)
        self.configure(fg_color=BG)

        self.CFG = CFG          # wspolny slownik konfiguracji (dla ui_v13)
        self.camera_name = self.CFG.get("device_names", {}).get("camera", "vStudio") or "vStudio"
        if MOBILE_ON:
            # W trybie mobilnym nazwy pochodza z urzadzenia, ktore obsluguja.
            self.camera_name = mobile_camera_name()
            self.microphone_name = mobile_microphone_name()
            self.CFG.setdefault("device_names", {})["camera"] = self.camera_name
            self.CFG["device_names"]["microphone"] = self.microphone_name
        if HAS_VD:
            VD.set_target_camera_name(self.camera_name)
        self.audio = PhoneNoiseEngine(sample_rate=CFG["audio"].get("sample_rate", 48000)) if HAS_AUDIO else None
        self.video = VideoEngine() if HAS_VIDEO else None
        if self.video:
            self.video.camera_name = self.camera_name
            self.video.brand_title = APP_NAME
        self.broadcasting = False
        self._closing = False
        self._last_broadcast_request = ""
        self._sel_idx = 0
        self._dev_map = {"(domyślne)": None}

        if self.audio:
            a = CFG["audio"]
            self.audio.set_profile(a.get("profile", "pokoj"))
            self.audio.set_volume(a.get("volume", 0.8))
            self.audio.set_noise_level(a.get("noise_level", 0.5))
            self.audio.set_event_rate(a.get("event_rate", 0.5))
            self.audio.set_bass(a.get("bass", 0.5))
            self.audio.set_breath(a.get("breath_on", True))
            self.audio.set_breath_level(a.get("breath_level", 0.45))
            self.audio.set_breath_rate(a.get("breath_rate", 13))
            # Octo.su stores only the local device label. Resolve it inside
            # sounddevice and pass that microphone through to VB-CABLE.
            wanted_input = str(a.get("input_device_name", "") or "").strip().lower()
            if wanted_input and a.get("passthrough_input", False):
                for idx, input_name in self.audio.list_input_devices():
                    low = str(input_name).lower()
                    if wanted_input == low or wanted_input in low or low in wanted_input:
                        self.audio.input_device = idx
                        break

        if self.video:
            v = CFG["video"]
            self.video.format_id = MOBILE_FORMAT_ID or v.get("format_id", "realme12pro")
            self.video.fit_mode = v.get("fit_mode", "fill")
            self.video.filter_id = v.get("filter", "normal")
            self.video.fps = int(MOBILE.get("fps") or v.get("fps", 30) or 30) if MOBILE_ON else int(v.get("fps", 30))
            if MOBILE_ON:
                # Preview keeps the phone orientation. DirectShow always gets
                # a supported 640x480 sensor frame with no hidden rotation;
                # source orientation is controlled explicitly below.
                self.video.virtual_output_size = (640, 480)
                self.video.virtual_output_rotation = 0
            # vStudio Mobile nadaje wylacznie przez Unity Capture: jeden
            # silnik, ten sam na kazdym uruchomieniu, wiec kamera w Androidzie
            # nazywa sie zawsze tak samo i nie zalezy od tego, czy OBS akurat
            # dziala. Tryb desktopowy zachowuje wybor uzytkownika.
            # vStudio Mobile nadaje wylacznie przez Unity Capture - jeden
            # silnik, ta sama nazwa kamery w Androidzie przy kazdym starcie.
            self.video.vcam_backend = VCAM_BACKEND
            self.video.mode = v.get("slideshow_mode", "auto")
            self.video.interval = float(v.get("slideshow_interval", 6.0))
            self.video.transition = v.get("transition", "fade")
            self.video.fx_shake = bool(v.get("effect_shake", True))
            self.video.fx_shake_amount = float(v.get("effect_shake_amount", 4.0))
            self.video.fx_grain = bool(v.get("effect_grain", True))
            self.video.fx_grain_amount = float(v.get("effect_grain_amount", 6.0))
            self.video.fx_vignette = bool(v.get("effect_vignette", True))
            self.video.fx_autofocus = bool(v.get("effect_autofocus", True))
            self.video.ov_rec = bool(v.get("overlay_rec", True))
            self.video.ov_timestamp = bool(v.get("overlay_timestamp", True))
            self.video.ov_brand = bool(v.get("overlay_brand", True))
            self.video.ov_battery = bool(v.get("overlay_battery", True))
            self.video.mirror = bool(v.get("mirror", False))
            self.video.rotate = int(v.get("rotate", 0))
            input_rotation = int(v.get("input_rotation", 0) or 0) % 360
            self.video.input_rotation = input_rotation if input_rotation in (0, 90, 180, 270) else 0
            self.video.input_mirror = bool(v.get("input_mirror", False))
            self.video.zoom = float(v.get("zoom", 1.0))
            self.video.pan_x = float(v.get("pan_x", 0.0))
            self.video.pan_y = float(v.get("pan_y", 0.0))
            self.video.orientation = v.get("orientation", "portrait")
            try:
                self.video.frame_memory = dict(v.get("frames", {}) or {})
            except Exception:
                pass
            self.video.on_slide_change = self._on_slide_change
            # Pusty start: zadne przykladowe zdjecia nie sa doladowywane.
            # Jesli OctoBrowser wskazal folder dla konkretnego urzadzenia
            # (mobile.media_folder), ladujemy wlasnie ten.
            try:
                folder = str(MOBILE.get("media_folder") or "").strip()
                if folder and os.path.isdir(folder):
                    self.video.add_folder(folder)
            except Exception:
                pass
            self.video.start()

        self._init_v13()
        self._init_v14()
        self._camera_sources = {}
        self._microphone_sources = {}
        self._source_scan_running = False
        self._build_ui()
        self._android_device = AUTO_ANDROID
        self._refresh_android_connection()
        self._scan_live_sources()
        self._refresh_devices_combo()
        self._refresh_playlist_ui()
        self._sync_frame_ui()
        self._tick_preview()
        self._tick_meters()
        if LANG.startswith("pl"):
            self._log("%s - wirtualna kamera i mikrofon dla Androida." % APP_NAME)
            self._log("Kamera: '%s'   Mikrofon: '%s'   Silnik: Unity Capture" % (
                self.camera_name, getattr(self, "microphone_name", self.camera_name)))
            self._log("1) Dodaj zdjecia lub filmy   2) Ustaw kadr   3) Start nadawania.")
            if MOBILE_ON:
                self._log("Urzadzenie: %s. W Androidzie wybierz te same nazwy kamery i mikrofonu." % (mobile_device_name() or "?"))
        else:
            self._log("%s - virtual camera and microphone for Android." % APP_NAME)
            self._log("Camera: '%s'   Microphone: '%s'   Engine: Unity Capture" % (
                self.camera_name, getattr(self, "microphone_name", self.camera_name)))
            self._log("1) Add photos or videos   2) Set the frame   3) Start streaming.")
            if MOBILE_ON:
                self._log("Device: %s. Pick the same camera and microphone names inside Android." % (mobile_device_name() or "?"))
        if self.video and self.video.playlist:
            self._log("Wczytano %d plików z folderu media/." % len(self.video.playlist))
        if self.audio and self.audio.demo_mode:
            self._log("Uwaga: brak modułu audio (sounddevice) — tryb demo. Uruchom INSTALUJ.bat.")
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.bind("<Left>", lambda e: self._slide_prev())
        self.bind("<Right>", lambda e: self._slide_next())
        self._v13_bind_keys()
        self._v14_bind_keys()
        self.after(250, self._poll_octobrowser_command)
        self.after(400, self._v13_restore_music)
        self.after(5000, self._poll_android_connection)

    def _runtime_status_path(self):
        return os.path.join(APP_DIR, ".octo-runtime.json")

    def _write_runtime_status(self):
        """Atomic heartbeat consumed by Octo.su before it boots Android."""
        try:
            requested_input = str((CFG.get("video", {}) or {}).get("input_camera_name", "") or "").strip()
            input_active = bool(self.video and self.video.live_camera_working())
            payload = {
                "pid": os.getpid(),
                "broadcastRequest": self._last_broadcast_request,
                "broadcasting": bool(self.broadcasting),
                "cameraActive": bool(self.video and self.video.vcam_active),
                "cameraDevice": str(self.video.vcam_device if self.video else ""),
                "cameraError": str(self.video.vcam_error if self.video else ""),
                "inputCameraRequested": bool(requested_input),
                "inputCameraActive": input_active,
                "inputCameraName": requested_input,
                "inputCameraError": str(self.video.input_camera_error if self.video else ""),
                "updatedAt": int(time.time() * 1000),
            }
            target = self._runtime_status_path()
            temporary = target + ".tmp-%d" % os.getpid()
            with open(temporary, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, ensure_ascii=False)
            os.replace(temporary, target)
        except Exception:
            pass

    def _poll_octobrowser_command(self):
        """Handle each external start/stop token exactly once.

        This works both at startup and when an already-open vStudio window is
        asked to publish. Merely opening the optional plugin never invents a
        request; Octo.su writes one only after the user's explicit action.
        """
        if self._closing:
            return
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as stream:
                live = json.load(stream)
            control = live.get("octobrowser", {}) or {}
            request = str(control.get("broadcastRequest") or "")
            if request and request != self._last_broadcast_request:
                self._last_broadcast_request = request
                CFG["octobrowser"] = dict(control)
                if request.startswith("start:"):
                    if not self.broadcasting or not (self.video and self.video.vcam_active):
                        self._start_broadcast()
                elif request.startswith("stop:") and self.broadcasting:
                    self._stop_broadcast()
            self._write_runtime_status()
        except Exception as exc:
            if self.video and not self.video.vcam_error:
                self.video.vcam_error = str(exc)
            self._write_runtime_status()
        self.after(500, self._poll_octobrowser_command)

    def _change_theme(self, display_name):
        """Apply an Octo theme live, save it, and use a short soft fade."""
        try:
            index = THEME_NAMES.index(str(display_name))
        except ValueError:
            index = 0
        theme_id = THEME_IDS[index]
        old = {key: globals().get(key) for key in ("BG", "CARD", "CARD2", "LINE", "MUTED", "TEXT", "DIM", "WHITE", "WHITE_HOVER")}
        _activate_palette(theme_id)
        CFG.setdefault("ui", {})["theme"] = theme_id
        save_config(CFG)
        mapping = {str(value).lower(): str(globals().get(key)) for key, value in old.items() if value}
        properties = ("fg_color", "bg_color", "hover_color", "border_color", "text_color",
                      "button_color", "button_hover_color", "dropdown_fg_color",
                      "dropdown_hover_color", "dropdown_text_color")

        def recolor(widget):
            for prop in properties:
                try:
                    value = widget.cget(prop)
                    replacement = mapping.get(str(value).lower())
                    if replacement:
                        widget.configure(**{prop: replacement})
                except Exception:
                    pass
            try:
                children = widget.winfo_children()
            except Exception:
                children = []
            for child in children:
                recolor(child)

        recolor(self)
        try:
            self.configure(fg_color=BG)
            # 180 ms fade: fast enough to feel direct, visible enough to make
            # the theme change intentional rather than a redraw glitch.
            self.attributes("-alpha", 0.88)
            for step in range(1, 7):
                self.after(step * 30, lambda n=step: self.attributes("-alpha", 0.88 + n * 0.02))
        except Exception:
            pass
        self._log("Theme: %s" % THEME_NAMES[index])

    def _refresh_android_connection(self):
        device = getattr(self, "_android_device", None)
        if not hasattr(self, "lbl_android_link"):
            return
        if device:
            camera = device.get("camera_back") or device.get("camera_front") or "-"
            mic = "host on" if device.get("host_microphone_enabled") else "host routing"
            self.lbl_android_link.configure(
                text=("●  %s  ·  %s  ·  camera %s  ·  mic %s" %
                      (device.get("label") or device.get("avd"), device.get("serial"), camera, mic)),
                text_color="#4ADE80")
        else:
            self.lbl_android_link.configure(
                text=("○  Brak uruchomionego emulatora" if LANG.startswith("pl") else "○  No running emulator"),
                text_color=MUTED)

    def _poll_android_connection(self):
        if self._closing:
            return
        try:
            if HAS_VD:
                self._android_device = VD.connect_running_android(mobile_device_name())
                self._refresh_android_connection()
        except Exception:
            pass
        self.after(5000, self._poll_android_connection)

    # ---------------------------------------------------------- pomocnicze
    def _label_of(self, mapping, key):
        try:
            return mapping.get(key, next(iter(mapping.values())))
        except Exception:
            return "-"

    def _key_of(self, mapping, label):
        for k, v in mapping.items():
            if v == label:
                return k
        return next(iter(mapping.keys()), "")

    def _section(self, parent, text):
        """Create a compact accordion heading for the controls that follow it.

        Settings used to be one unbroken column, so a tab containing both sound
        and music created two nested scroll areas.  A heading discovers its
        packed siblings up to the next heading and can hide/restore that group.
        The first group in a tab is open; the rest start folded.
        """
        count = int(getattr(parent, "_vstudio_section_count", 0))
        parent._vstudio_section_count = count + 1
        button = ctk.CTkButton(
            parent, text="▾  " + text.upper(), anchor="w", height=34,
            font=ctk.CTkFont(size=11, weight="bold"), fg_color=CARD2,
            hover_color="#252C3A", text_color=TEXT, corner_radius=9)
        button._vstudio_section_header = True
        button._vstudio_expanded = True
        button._vstudio_hidden = []
        button.pack(fill="x", padx=10, pady=(10, 2))

        def members():
            children = list(parent.winfo_children())
            try:
                start = children.index(button) + 1
            except ValueError:
                return [], None
            selected = []
            following = None
            for child in children[start:]:
                if getattr(child, "_vstudio_section_header", False):
                    following = child
                    break
                selected.append(child)
            return selected, following

        def toggle():
            if button._vstudio_expanded:
                selected, _ = members()
                hidden = []
                for child in selected:
                    try:
                        info = dict(child.pack_info())
                        info.pop("in", None)
                        hidden.append((child, info))
                        child.pack_forget()
                    except Exception:
                        pass
                button._vstudio_hidden = hidden
                button._vstudio_expanded = False
                button.configure(text="▸  " + text.upper())
            else:
                _, following = members()
                for child, info in button._vstudio_hidden:
                    try:
                        if following is not None:
                            child.pack(before=following, **info)
                        else:
                            child.pack(**info)
                    except Exception:
                        child.pack(fill="x")
                button._vstudio_hidden = []
                button._vstudio_expanded = True
                button.configure(text="▾  " + text.upper())

        button.configure(command=toggle)
        if count > 0:
            self.after_idle(toggle)
        return button

    def _hint(self, parent, text):
        ctk.CTkLabel(parent, text=text, font=ctk.CTkFont(size=11),
                     text_color=MUTED, wraplength=280, justify="left").pack(
                         anchor="w", padx=16, pady=(2, 4))

    def _slider_card(self, parent, label, value, frm, to, steps, fmt, cmd):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="x", padx=16, pady=(10, 0))
        ctk.CTkLabel(box, text=label, font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        val = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT)
        val.pack(side="right")
        s = ctk.CTkSlider(parent, from_=frm, to=to, number_of_steps=steps,
                          command=lambda v: (val.configure(text=fmt(float(v))), cmd()))
        s.pack(fill="x", padx=16, pady=(4, 2))
        s.set(value)
        val.configure(text=fmt(float(value)))
        return s, val

    def _status_pill(self, parent, col):
        pill = ctk.CTkFrame(parent, fg_color=CARD2, corner_radius=18,
                            border_width=1, border_color=LINE)
        pill.grid(row=0, column=col, padx=6, pady=10, sticky="w")
        dot = ctk.CTkLabel(pill, text="●", font=ctk.CTkFont(size=11),
                           text_color=DIM, width=14)
        dot.pack(side="left", padx=(12, 2), pady=7)
        txt = ctk.CTkLabel(pill, text="", font=ctk.CTkFont(size=12, weight="bold"),
                           text_color=TEXT)
        txt.pack(side="left", padx=(2, 12), pady=7)
        return pill, dot, txt

    def _log(self, msg):
        try:
            ts = datetime.now().strftime("%H:%M:%S")
            msg = self._net_scrub(msg)     # klucz API nigdy nie trafi do dziennika
            self.txt_log.insert("end", "[%s] %s\n" % (ts, msg))
            self.txt_log.see("end")
        except Exception:
            print(msg)

    # --------------------------------------------------------- tryb mobilny
    def _build_mobile_bar(self, parent):
        """Pasek dla emulatora: urzadzenie, nazwy kamery i mikrofonu, kadr.

        Siedzi bezposrednio pod paskiem gornym, bo odpowiada na pierwsze
        pytanie przy emulatorze: co wybrac w Androidzie.
        """
        bar = ctk.CTkFrame(parent, fg_color=CARD2, corner_radius=10,
                           border_width=1, border_color=LINE)
        bar.grid(row=1, column=0, columnspan=9, sticky="ew", padx=18, pady=(0, 12))
        bar.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(bar, text="ANDROID", font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=MUTED).grid(row=0, column=0, padx=(14, 10), pady=10, sticky="w")
        res = mobile_resolution()
        if LANG.startswith("pl"):
            text = "Urzadzenie: %s     Kamera w Androidzie: %s     Mikrofon: %s" % (
                mobile_device_name() or "-", self.camera_name, getattr(self, "microphone_name", self.camera_name))
            if res:
                text += "     Kadr: %d × %d" % (res[0], res[1])
            text += "     Silnik: Unity Capture"
        else:
            text = "Device: %s     Camera in Android: %s     Microphone: %s" % (
                mobile_device_name() or "-", self.camera_name, getattr(self, "microphone_name", self.camera_name))
            if res:
                text += "     Frame: %d × %d" % (res[0], res[1])
            text += "     Engine: Unity Capture"
        self.lbl_mobile = ctk.CTkLabel(bar, text=text, font=ctk.CTkFont(size=12), text_color=TEXT)
        self.lbl_mobile.grid(row=0, column=1, padx=6, pady=10, sticky="w")
        ctk.CTkButton(bar, text=("Dopasuj kadr do telefonu" if LANG.startswith("pl") else "Match the phone frame"),
                      width=200, height=32, command=self._mobile_match_frame, **GHOST).grid(row=0, column=2, padx=6, pady=8)
        ctk.CTkButton(bar, text=("Kopiuj nazwy" if LANG.startswith("pl") else "Copy names"),
                      width=130, height=32, command=self._mobile_copy_names, **GHOST).grid(row=0, column=3, padx=(6, 14), pady=8)
        # Live adb state: green means the app found the currently running AVD.
        self.lbl_android_link = ctk.CTkLabel(bar, text="", font=ctk.CTkFont(size=11), text_color=MUTED)
        self.lbl_android_link.grid(row=1, column=1, columnspan=3, padx=6, pady=(0, 9), sticky="w")

    def _mobile_match_frame(self):
        """Ustawia kadr i orientacje dokladnie na ekran emulowanego telefonu."""
        res = mobile_resolution()
        if not (res and self.video):
            self._log("Tryb mobilny: brak rozdzielczosci telefonu w config.json.")
            return
        if MOBILE_FORMAT_ID:
            self.video.format_id = MOBILE_FORMAT_ID
        self.video.orientation = "portrait" if res[1] >= res[0] else "landscape"
        self.video.fit_mode = "fill"
        stream = mobile_stream_resolution()
        self._log("Kadr kamery Android: %d × %d (ekran telefonu: %d × %d)." % (
            stream[0], stream[1], res[0], res[1]))
        try:
            self._sync_frame_ui()
        except Exception:
            pass

    def _mobile_copy_names(self):
        """Kopiuje nazwy kamery i mikrofonu - do wklejenia w ustawieniach aplikacji."""
        names = "%s / %s" % (self.camera_name, getattr(self, "microphone_name", self.camera_name))
        try:
            self.clipboard_clear()
            self.clipboard_append(names)
            self._log("Skopiowano nazwy urzadzen: %s" % names)
        except Exception:
            self._log("Nazwy urzadzen: %s" % names)

    # ---------------------------------------------------- source dashboard
    def _build_source_dashboard(self):
        """Two live cards modelled after a modern analytics dashboard."""
        board = ctk.CTkFrame(self, fg_color="transparent")
        board.grid(row=1, column=0, columnspan=3, sticky="ew", padx=14, pady=(12, 0))
        board.grid_columnconfigure(0, weight=1)
        board.grid_columnconfigure(1, weight=1)

        cam = ctk.CTkFrame(board, fg_color="#151A2A", corner_radius=18,
                           border_width=1, border_color="#2A3150")
        cam.grid(row=0, column=0, sticky="ew", padx=(0, 7))
        cam.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(cam, text=("KAMERA NA ŻYWO" if LANG.startswith("pl") else "LIVE CAMERA"),
                     font=ctk.CTkFont(size=11, weight="bold"), text_color="#68D7FF").grid(
                         row=0, column=0, padx=18, pady=(13, 2), sticky="w")
        self.lbl_camera_probe = ctk.CTkLabel(cam, text=("Skanowanie…" if LANG.startswith("pl") else "Scanning…"),
                                             font=ctk.CTkFont(size=12), text_color=MUTED)
        self.lbl_camera_probe.grid(row=0, column=1, padx=18, pady=(13, 2), sticky="e")
        self.var_input_camera = ctk.StringVar(value=("Biblioteka multimediów" if LANG.startswith("pl") else "Media library"))
        self.opt_input_camera = ctk.CTkOptionMenu(cam, variable=self.var_input_camera,
                                                  values=[self.var_input_camera.get()],
                                                  command=self._on_input_camera, **OPTION_MENU)
        self.opt_input_camera.grid(row=1, column=0, columnspan=2, padx=18, pady=8, sticky="ew")
        self.lbl_camera_metric = ctk.CTkLabel(cam, text="▁▂▃▅▇▆▃▅  —",
                                              font=ctk.CTkFont(size=14), text_color="#68D7FF")
        self.lbl_camera_metric.grid(row=2, column=0, padx=18, pady=(2, 13), sticky="w")
        ctk.CTkButton(cam, text=("↻  Skanuj" if LANG.startswith("pl") else "↻  Scan"), width=105,
                      command=self._scan_live_sources, **GHOST).grid(row=2, column=1, padx=18, pady=(2, 8), sticky="e")
        transform = ctk.CTkFrame(cam, fg_color="transparent")
        transform.grid(row=3, column=0, columnspan=2, padx=14, pady=(0, 12), sticky="ew")
        ctk.CTkButton(transform, text=("↶  Obróć w lewo" if LANG.startswith("pl") else "↶  Rotate left"),
                      width=118, height=28, command=lambda: self._rotate_live_input(-90), **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(transform, text=("Obróć w prawo  ↷" if LANG.startswith("pl") else "Rotate right  ↷"),
                      width=118, height=28, command=lambda: self._rotate_live_input(90), **GHOST).pack(side="left", padx=3)
        self.var_input_mirror = ctk.BooleanVar(value=bool(self.video and self.video.input_mirror))
        ctk.CTkCheckBox(transform, text=("Odbij" if LANG.startswith("pl") else "Mirror"),
                        variable=self.var_input_mirror, command=self._mirror_live_input,
                        width=74).pack(side="right", padx=3)
        self.lbl_input_rotation = ctk.CTkLabel(transform, text="0°", width=34,
                                               font=ctk.CTkFont(size=11, weight="bold"), text_color=MUTED)
        self.lbl_input_rotation.pack(side="right", padx=3)
        self._refresh_live_transform_label()

        mic = ctk.CTkFrame(board, fg_color="#18162A", corner_radius=18,
                           border_width=1, border_color="#342B55")
        mic.grid(row=0, column=1, sticky="ew", padx=(7, 0))
        mic.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(mic, text=("MIKROFON NA ŻYWO" if LANG.startswith("pl") else "LIVE MICROPHONE"),
                     font=ctk.CTkFont(size=11, weight="bold"), text_color="#C69CFF").grid(
                         row=0, column=0, padx=18, pady=(13, 2), sticky="w")
        self.lbl_microphone_probe = ctk.CTkLabel(mic, text=("Skanowanie…" if LANG.startswith("pl") else "Scanning…"),
                                                 font=ctk.CTkFont(size=12), text_color=MUTED)
        self.lbl_microphone_probe.grid(row=0, column=1, padx=18, pady=(13, 2), sticky="e")
        self.var_input_microphone = ctk.StringVar(value=("Generator vStudio" if LANG.startswith("pl") else "vStudio generator"))
        self.opt_input_microphone = ctk.CTkOptionMenu(mic, variable=self.var_input_microphone,
                                                      values=[self.var_input_microphone.get()],
                                                      command=self._on_input_microphone, **OPTION_MENU)
        self.opt_input_microphone.grid(row=1, column=0, columnspan=2, padx=18, pady=8, sticky="ew")
        self.lbl_microphone_metric = ctk.CTkLabel(mic, text="▁▃▆▂▇▅▂▁  —",
                                                  font=ctk.CTkFont(size=14), text_color="#C69CFF")
        self.lbl_microphone_metric.grid(row=2, column=0, padx=18, pady=(2, 13), sticky="w")
        ctk.CTkButton(mic, text=("↻  Skanuj" if LANG.startswith("pl") else "↻  Scan"), width=105,
                      command=self._scan_live_sources, **GHOST).grid(row=2, column=1, padx=18, pady=(2, 13), sticky="e")

    def _refresh_live_transform_label(self):
        try:
            rotation = int(self.video.input_rotation if self.video else 0) % 360
            self.lbl_input_rotation.configure(text="%d°" % rotation)
        except Exception:
            pass

    def _rotate_live_input(self, delta):
        """Rotate a host camera before framing; safe while it is streaming."""
        if not self.video:
            return
        self.video.input_rotation = (int(self.video.input_rotation or 0) + int(delta)) % 360
        CFG.setdefault("video", {})["input_rotation"] = self.video.input_rotation
        save_config(CFG)
        self._refresh_live_transform_label()
        direction = "left" if int(delta) < 0 else "right"
        if LANG.startswith("pl"):
            self._log("Obrót kamery na żywo: %d°" % self.video.input_rotation)
        else:
            self._log("Live camera rotated %s: %d°" % (direction, self.video.input_rotation))

    def _mirror_live_input(self):
        if not self.video:
            return
        self.video.input_mirror = bool(self.var_input_mirror.get())
        CFG.setdefault("video", {})["input_mirror"] = self.video.input_mirror
        save_config(CFG)
        state = "on" if self.video.input_mirror else "off"
        self._log(("Odbicie kamery na żywo: %s" if LANG.startswith("pl") else
                   "Live camera mirror: %s") % state)

    def _scan_live_sources(self):
        if self._source_scan_running or not HAS_VD:
            return
        self._source_scan_running = True
        # Release our current input while probing; otherwise Windows reports it
        # as busy and a manual rescan would incorrectly remove the selected camera.
        if self.video and self.video.live_camera_working():
            self.video.close_live_camera()
        if hasattr(self, "lbl_camera_probe"):
            self.lbl_camera_probe.configure(text=("Skanowanie…" if LANG.startswith("pl") else "Scanning…"), text_color=MUTED)
            self.lbl_microphone_probe.configure(text=("Skanowanie…" if LANG.startswith("pl") else "Scanning…"), text_color=MUTED)

        def scan():
            cameras = VD.probe_all_cameras()
            wanted = str((CFG.get("video", {}) or {}).get("input_camera_name", "") or "").strip().lower()
            if wanted and not any(str(item.get("name") or "").strip().lower() == wanted for item in cameras):
                # The launcher has just released its explicit preview. Some
                # phone-webcam drivers need a short DirectShow cooldown before
                # another process can open the same endpoint.
                time.sleep(0.6)
                cameras = VD.probe_all_cameras()
            microphones = VD.probe_working_microphones()
            try:
                self.after(0, lambda: self._apply_source_scan(cameras, microphones))
            except Exception:
                self._source_scan_running = False
        threading.Thread(target=scan, daemon=True).start()

    def _apply_source_scan(self, cameras, microphones):
        self._source_scan_running = False
        media = "Biblioteka multimediów" if LANG.startswith("pl") else "Media library"
        generated = "Generator vStudio" if LANG.startswith("pl") else "vStudio generator"
        # Every camera the host has is offered, whether or not it answered the
        # probe: a camera that is busy right now is still the camera the user
        # wants to pick, and hiding it is what produced "no cameras" on a
        # machine with a camera.
        working = [item for item in cameras if item.get("available")]
        detected = [item for item in cameras if not item.get("available")]
        self._camera_sources = {media: None}
        for item in working:
            label = "●  %s  ·  %dx%d" % (item["name"], item["width"], item["height"])
            self._camera_sources[label] = item
        not_ready = "zajęta / niedostępna" if LANG.startswith("pl") else "busy / unavailable"
        for item in detected:
            label = "○  %s  ·  %s" % (item["name"], not_ready)
            self._camera_sources[label] = item
        self._microphone_sources = {generated: None}
        for item in microphones:
            label = "●  %s  ·  %d Hz" % (item["name"], item["sample_rate"])
            self._microphone_sources[label] = item
        self.opt_input_camera.configure(values=list(self._camera_sources))
        self.opt_input_microphone.configure(values=list(self._microphone_sources))
        if working:
            self.lbl_camera_probe.configure(
                text=("● %d działa" % len(working) if LANG.startswith("pl") else "● %d working" % len(working)),
                text_color="#4ADE80")
        elif detected:
            self.lbl_camera_probe.configure(
                text=("○ wykryto %d — zajęte" % len(detected) if LANG.startswith("pl")
                      else "○ %d detected — busy" % len(detected)),
                text_color="#FBBF24")
        else:
            self.lbl_camera_probe.configure(
                text=("○ brak kamery" if LANG.startswith("pl") else "○ no camera"),
                text_color="#F87171")
        cable_ready = False
        try:
            cable_ready = bool(self.audio and self.audio.find_cable_device()[0] is not None)
        except Exception:
            pass
        mic_ready = bool(microphones) or cable_ready
        mic_state = (("● %d działa" % len(microphones)) if microphones else "● VB-CABLE gotowy" if cable_ready else "○ brak mikrofonu") if LANG.startswith("pl") else (("● %d working" % len(microphones)) if microphones else "● VB-CABLE ready" if cable_ready else "○ no microphone")
        self.lbl_microphone_probe.configure(text=mic_state, text_color="#4ADE80" if mic_ready else "#F87171")
        self.lbl_camera_metric.configure(text="▁▂▃▅▇▆▃▅  " + ("gotowa klatka" if working and LANG.startswith("pl") else "frame verified" if working else "brak sygnału" if LANG.startswith("pl") else "no signal"))
        mic_metric = ("strumień otwarty" if microphones else "wyjście do Androida gotowe" if cable_ready else "brak sygnału") if LANG.startswith("pl") else ("stream verified" if microphones else "Android output ready" if cable_ready else "no signal")
        self.lbl_microphone_metric.configure(text="▁▃▆▂▇▅▂▁  " + mic_metric)

        wanted_cam = str(CFG.get("video", {}).get("input_camera_name", "") or "").lower()
        wanted_mic = str(CFG.get("audio", {}).get("input_device_name", "") or "").lower()
        cam_label = next((label for label, item in self._camera_sources.items() if item and wanted_cam == item["name"].lower()), media)
        mic_label = next((label for label, item in self._microphone_sources.items() if item and wanted_mic == item["name"].lower()), generated)
        self.var_input_camera.set(cam_label)
        self.var_input_microphone.set(mic_label)
        if cam_label != media:
            self._on_input_camera(cam_label)
        elif wanted_cam and self.video:
            # Keep the remembered label so Octo can report the real failure;
            # never silently fall back to a placeholder/library frame.
            self.video.input_camera_error = "The selected camera did not return a frame: %s" % wanted_cam
            self.lbl_camera_probe.configure(text=("○ kamera niedostępna" if LANG.startswith("pl") else "○ camera unavailable"), text_color="#F87171")
        if mic_label != generated:
            self._on_input_microphone(mic_label)

    def _on_input_camera(self, label):
        item = self._camera_sources.get(label)
        ok = bool(self.video and item and self.video.set_live_camera(item["index"], item["name"]))
        if self.video and not item:
            self.video.set_live_camera(None)
        CFG.setdefault("video", {})["input_camera_index"] = item["index"] if item else None
        CFG["video"]["input_camera_name"] = item["name"] if item else ""
        save_config(CFG)
        if ok:
            self.lbl_camera_probe.configure(text=("● połączona" if LANG.startswith("pl") else "● connected"),
                                            text_color="#4ADE80")
        elif item:
            # Say WHY it is not live (busy, in use by another app, no frame)
            # instead of a silent "media".
            reason = str(item.get("note") or "")
            self.lbl_camera_probe.configure(text=("○ %s" % (reason[:60] or ("zajęta" if LANG.startswith("pl") else "busy"))),
                                            text_color="#FBBF24")
        else:
            self.lbl_camera_probe.configure(text=("○ media"), text_color=MUTED)
        self._log(("Źródło kamery: " if LANG.startswith("pl") else "Camera source: ") + label)
        if item and not ok:
            self._log((("Kamera %s nie oddała klatki (%s). Sprawdź, czy nie używa jej inny program, i kliknij Skanuj."
                        if LANG.startswith("pl") else
                        "Camera %s did not return a frame (%s). Check whether another app is using it, then press Scan.")
                       % (item["name"], reason or "-")))

    def _on_input_microphone(self, label):
        item = self._microphone_sources.get(label)
        if self.audio:
            was_running = self.audio.is_running()
            if was_running:
                self.audio.stop()
            self.audio.input_device = item["index"] if item else None
            CFG.setdefault("audio", {})["input_device_name"] = item["name"] if item else ""
            CFG["audio"]["passthrough_input"] = bool(item)
            save_config(CFG)
            if was_running:
                self._sync_engine(force=True)
        self.lbl_microphone_probe.configure(text=("● połączony" if item and LANG.startswith("pl") else "● connected" if item else "○ generator"),
                                            text_color="#4ADE80" if item else MUTED)
        self._log(("Źródło mikrofonu: " if LANG.startswith("pl") else "Microphone source: ") + label)

    # ------------------------------------------------------------- układ paneli
    def _apply_panel_layout(self):
        """Give all reclaimed side-panel space to the streamed-app preview."""
        left_on = bool(getattr(self, "_library_visible", True))
        right_on = bool(getattr(self, "_settings_visible", False))
        if hasattr(self, "left_panel"):
            (self.left_panel.grid if left_on else self.left_panel.grid_remove)()
        if hasattr(self, "right_panel"):
            (self.right_panel.grid if right_on else self.right_panel.grid_remove)()
        if hasattr(self, "preview_panel"):
            column = 1 if left_on else 0
            span = max(1, 3 - int(left_on) - int(right_on))
            self.preview_panel.grid_configure(column=column, columnspan=span)
        if hasattr(self, "btn_library_panel"):
            self.btn_library_panel.configure(text=("◀ Biblioteka" if left_on else "Biblioteka ▶"))
        if hasattr(self, "btn_settings_panel"):
            self.btn_settings_panel.configure(text=("Ustawienia ▶" if right_on else "◀ Ustawienia"))

    def _toggle_library_panel(self):
        self._library_visible = not self._library_visible
        self._apply_panel_layout()

    def _toggle_settings_panel(self):
        self._settings_visible = not self._settings_visible
        self._apply_panel_layout()

    def _toggle_log_panel(self):
        self._log_visible = not self._log_visible
        if self._log_visible:
            self.txt_log.grid()
            self.bottom_panel.configure(height=96)
            self.btn_log_panel.configure(text="▾")
        else:
            self.txt_log.grid_remove()
            self.bottom_panel.configure(height=34)
            self.btn_log_panel.configure(text="▸")

    # ------------------------------------------------------------- budowa UI
    def _build_ui(self):
        self._library_visible = True
        self._settings_visible = False
        self._log_visible = False
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=3)
        self.grid_columnconfigure(2, weight=0)
        self.grid_rowconfigure(2, weight=1)

        # ===== pasek górny =====
        top = ctk.CTkFrame(self, corner_radius=0, fg_color=CARD)
        top.grid(row=0, column=0, columnspan=3, sticky="ew")
        top.grid_columnconfigure(4, weight=1)

        brand = ctk.CTkFrame(top, fg_color="transparent")
        brand.grid(row=0, column=0, padx=20, pady=12, sticky="w")
        ctk.CTkLabel(brand, text=APP_NAME,
                     font=ctk.CTkFont(size=18, weight="bold"), text_color=TEXT).pack(anchor="w")
        if not MOBILE_ON:
            ctk.CTkLabel(brand, text=APP_SUBTITLE,
                         font=ctk.CTkFont(size=10), text_color=MUTED).pack(anchor="w")

        _, self.dot_cam, self.led_cam = self._status_pill(top, 2)
        _, self.dot_mic, self.led_mic = self._status_pill(top, 3)

        self.btn_cam_selector = ctk.CTkButton(top, text=("📷  " + (mobile_device_name() or self.camera_name)),
                                              font=ctk.CTkFont(size=12),
                                              width=150, height=42,
                                              command=self._open_devices_window,
                                              **GHOST)
        self.btn_cam_selector.grid(row=0, column=4, padx=6, pady=10, sticky="e")

        self.btn_broadcast = ctk.CTkButton(top, text="▶   Start nadawania",
                                           font=ctk.CTkFont(size=13, weight="bold"),
                                           width=210, height=42, command=self._toggle_broadcast,
                                           **PRIMARY)
        self.btn_broadcast.grid(row=0, column=5, padx=6, pady=10)
        device_btn = ctk.CTkButton(top, text="Urządzenia", width=120, height=42,
                                   command=self._open_devices_window, **GHOST)
        device_btn.grid(row=0, column=6, padx=6, pady=10)
        help_btn = ctk.CTkButton(top, text="Pomoc", width=96, height=42,
                                 command=self._open_help_window, **GHOST)
        help_btn.grid(row=0, column=7, padx=(6, 6), pady=10)
        ctk.CTkButton(top, text="⚙ Ustawienia", width=124, height=42,
                      command=self._open_settings_window, **GHOST).grid(row=0, column=8, padx=(6, 18), pady=10)
        if MOBILE_ON:
            # Camera selector already opens Devices. Removing duplicate buttons
            # leaves one clear row that fits comfortably on laptop displays.
            device_btn.grid_remove()
            help_btn.grid_remove()

        # Jedna linijka, ktora odpowiada na jedyne pytanie uzytkownika przy
        # emulatorze: co dokladnie wybrac w Androidzie.
        if MOBILE_ON:
            self._build_mobile_bar(top)

        self._build_source_dashboard()

        # ===== lewa kolumna: biblioteka =====
        left = ctk.CTkFrame(self, width=(220 if MOBILE_ON else 280), fg_color=CARD, corner_radius=16,
                            border_width=1, border_color=LINE)
        self.left_panel = left
        left.grid(row=2, column=0, sticky="nsew", padx=(14, 7), pady=14)
        left.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(left, text="Biblioteka", font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=TEXT).grid(row=0, column=0, padx=16, pady=(14, 6), sticky="w")

        btns = ctk.CTkFrame(left, fg_color="transparent")
        btns.grid(row=1, column=0, sticky="ew", padx=12)
        ctk.CTkButton(btns, text="+ Dodaj", width=120, command=self._add_files,
                      **PRIMARY).grid(row=0, column=0, padx=4, pady=4)
        ctk.CTkButton(btns, text="Folder", width=120, command=self._add_folder,
                      **GHOST).grid(row=0, column=1, padx=4, pady=4)

        self.playlist_box = ctk.CTkScrollableFrame(left, label_text="", fg_color=CARD2, corner_radius=12)
        self.playlist_box.grid(row=2, column=0, sticky="nsew", padx=12, pady=6)

        nav = ctk.CTkFrame(left, fg_color="transparent")
        nav.grid(row=3, column=0, sticky="ew", padx=12, pady=(2, 4))
        nav.grid_columnconfigure(0, weight=1)
        nav.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(nav, text="◀  Poprzednie", command=self._slide_prev,
                      **GHOST).grid(row=0, column=0, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(nav, text="Następne  ▶", command=self._slide_next,
                      **GHOST).grid(row=0, column=1, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(nav, text="Usuń zaznaczony", command=self._remove_selected,
                      **GHOST).grid(row=1, column=0, padx=4, pady=4, sticky="ew")
        mv = ctk.CTkFrame(nav, fg_color="transparent")
        mv.grid(row=1, column=1, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(mv, text="▲", width=52, command=lambda: self._move_sel(-1),
                      **GHOST).pack(side="left", expand=True, fill="x", padx=(0, 4))
        ctk.CTkButton(mv, text="▼", width=52, command=lambda: self._move_sel(1),
                      **GHOST).pack(side="left", expand=True, fill="x", padx=(4, 0))
        ctk.CTkButton(nav, text="Wyczyść listę", command=self._clear_playlist,
                      **GHOST).grid(row=2, column=0, columnspan=2, padx=4, pady=(4, 12), sticky="ew")

        # ===== środek: podgląd =====
        mid = ctk.CTkFrame(self, fg_color=CARD, corner_radius=16,
                           border_width=1, border_color=LINE)
        self.preview_panel = mid
        mid.grid(row=2, column=1, sticky="nsew", padx=7, pady=14)
        mid.grid_columnconfigure(0, weight=1)
        mid.grid_rowconfigure(1, weight=1)

        mid_top = ctk.CTkFrame(mid, fg_color="transparent")
        mid_top.grid(row=0, column=0, sticky="ew", padx=16, pady=(14, 6))
        ctk.CTkLabel(mid_top, text="Podgląd", font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=TEXT).pack(side="left")
        self.btn_settings_panel = ctk.CTkButton(mid_top, text="◀ Ustawienia", width=104, height=28,
                                                command=self._toggle_settings_panel, **GHOST)
        self.btn_settings_panel.pack(side="right", padx=(6, 0))
        self.btn_library_panel = ctk.CTkButton(mid_top, text="◀ Biblioteka", width=104, height=28,
                                               command=self._toggle_library_panel, **GHOST)
        self.btn_library_panel.pack(side="right", padx=6)
        self.lbl_fps = ctk.CTkLabel(mid_top, text="", font=ctk.CTkFont(size=12), text_color=MUTED)
        self.lbl_fps.pack(side="right", padx=(8, 0))
        self.lbl_slide = ctk.CTkLabel(mid_top, text="", font=ctk.CTkFont(size=12), text_color=MUTED)
        self.lbl_slide.pack(side="right", padx=8)

        phone_outer = ctk.CTkFrame(mid, fg_color="#07080B", border_width=2,
                                   border_color=LINE, corner_radius=28)
        phone_outer.grid(row=1, column=0, sticky="nsew", padx=24, pady=4)
        phone_outer.grid_columnconfigure(0, weight=1)
        phone_outer.grid_rowconfigure(1, weight=1)
        notch = ctk.CTkFrame(phone_outer, fg_color="#07080B", height=20)
        notch.grid(row=0, column=0, sticky="ew", padx=70, pady=(8, 0))
        ctk.CTkLabel(notch, text="●", text_color="#1E232E",
                     font=ctk.CTkFont(size=13)).pack()
        self.lbl_preview = ctk.CTkLabel(phone_outer, text="Dodaj zdjęcia lub nagrania",
                                        font=ctk.CTkFont(size=13), text_color=MUTED)
        self.lbl_preview.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 12))
        self._drag_last = None
        self.lbl_preview.bind("<ButtonPress-1>", self._frame_drag_start)
        self.lbl_preview.bind("<B1-Motion>", self._frame_drag_move)
        self.lbl_preview.bind("<ButtonRelease-1>", lambda e: setattr(self, "_drag_last", None))
        self.lbl_preview.bind("<ButtonPress-3>", self._frame_drag_start)
        self.lbl_preview.bind("<B3-Motion>", self._frame_drag_right_move)
        self.lbl_preview.bind("<ButtonRelease-3>", lambda e: setattr(self, "_drag_last", None))
        self.lbl_preview.bind("<Double-Button-1>", lambda e: self._frame_reset())
        self.lbl_preview.bind("<MouseWheel>", self._frame_wheel)
        self.lbl_preview.bind("<Button-4>", lambda e: self._frame_zoom_step(1.1))
        self.lbl_preview.bind("<Button-5>", lambda e: self._frame_zoom_step(1 / 1.1))

        # pasek pod podglądem: format + orientacja + silnik + fps
        bar = ctk.CTkFrame(mid, fg_color=CARD2, corner_radius=12)
        bar.grid(row=2, column=0, sticky="ew", padx=16, pady=12)
        bar.grid_columnconfigure(0, weight=1)
        bar.grid_columnconfigure(1, weight=0)
        fmt_labels = [v["label"] for v in PHONE_FORMATS.values()] or ["-"]
        cur_fmt = PHONE_FORMATS.get(self.video.format_id, {}).get("label", fmt_labels[0]) if self.video else fmt_labels[0]
        self.var_format = ctk.StringVar(value=cur_fmt)
        ctk.CTkOptionMenu(bar, variable=self.var_format, values=fmt_labels,
                          command=self._on_format_change).grid(row=0, column=0, padx=10, pady=8, sticky="ew")
        self.var_orient = ctk.StringVar(value="Pionowo")
        ctk.CTkSegmentedButton(bar, values=["Pionowo", "Poziomo"],
                               variable=self.var_orient,
                               command=self._on_orient_seg).grid(row=0, column=1, padx=(0, 10), pady=8)
        be_row = ctk.CTkFrame(bar, fg_color="transparent")
        be_row.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10, pady=(0, 8))
        ctk.CTkLabel(be_row, text="Silnik:", font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        be_init = BACKEND_LABELS.get(self.video.vcam_backend, "Auto") if self.video else "Auto"
        self.var_backend = ctk.StringVar(value=be_init)
        ctk.CTkSegmentedButton(be_row, values=list(BACKEND_LABELS.values()),
                               variable=self.var_backend,
                               command=self._on_backend_change).pack(side="left", padx=(6, 16))
        ctk.CTkLabel(be_row, text="FPS:", font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        self.var_fps = ctk.StringVar(value=str(self.video.fps if self.video else 30))
        ctk.CTkSegmentedButton(be_row, values=["24", "30", "60"],
                               variable=self.var_fps,
                               command=self._on_fps_change).pack(side="left", padx=6)
        self.lbl_camstatus = ctk.CTkLabel(be_row, text="", font=ctk.CTkFont(size=11), text_color=MUTED)
        self.lbl_camstatus.pack(side="right")
        self._update_orient_btn()

        # ===== prawa kolumna: zakładki =====
        right = ctk.CTkFrame(self, width=(280 if MOBILE_ON else 320), fg_color=CARD, corner_radius=16,
                             border_width=1, border_color=LINE)
        self.right_panel = right
        right.grid(row=2, column=2, sticky="nsew", padx=(7, 14), pady=14)
        self.tabs = ctk.CTkTabview(right, fg_color=CARD, corner_radius=12)
        self.tabs.pack(fill="both", expand=True, padx=8, pady=8)
        # Zakladki: "Dzwiek" i "Audio" to bylo to samo w dwoch miejscach -
        # teraz jedna zakladka "Sound and audio" (scena + poziomy u gory,
        # muzyka i nagrywanie nizej). Generator 3D Twarzy zostal usuniety:
        # nie ma nic wspolnego z kamera telefonu.
        sound_tab = tr("Dźwięk i audio")
        tab_names = [sound_tab] + ([tr("Mowa (TTS)")] if HAS_V14 else []) + \
                    ([tr("Prywatność")] if HAS_V14 else []) + \
                    [tr("Obraz"), tr("Kadr"), tr("Efekty")]
        for name in tab_names:
            self.tabs.add(name)
        merged = self.tabs.tab(sound_tab)
        self._tab_sound(merged)
        self._tab_music(merged)
        if tr("Mowa (TTS)") in tab_names:
            self._tab_tts(self.tabs.tab(tr("Mowa (TTS)")))
        if tr("Prywatność") in tab_names:
            self._tab_net(self.tabs.tab(tr("Prywatność")))
        self._tab_image(self.tabs.tab(tr("Obraz")))
        self._tab_frame(self.tabs.tab(tr("Kadr")))
        self._tab_fx(self.tabs.tab(tr("Efekty")))
        self._build_v14_ui()          # pasek odtwarzacza pod podglądem

        # ===== dół: dziennik =====
        bottom = ctk.CTkFrame(self, height=34, fg_color=CARD, corner_radius=16,
                              border_width=1, border_color=LINE)
        self.bottom_panel = bottom
        bottom.grid(row=3, column=0, columnspan=3, sticky="ew", padx=14, pady=(0, 14))
        bottom.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(bottom, text="Dziennik", font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=MUTED).grid(row=0, column=0, padx=14, pady=6, sticky="w")
        self.btn_log_panel = ctk.CTkButton(bottom, text="▸", width=30, height=24,
                                           command=self._toggle_log_panel, **GHOST)
        self.btn_log_panel.grid(row=0, column=1, padx=8, pady=4)
        self.txt_log = ctk.CTkTextbox(bottom, height=52, font=ctk.CTkFont(size=11),
                                      fg_color=CARD2, corner_radius=10, border_width=0,
                                      text_color=TEXT)
        self.txt_log.grid(row=1, column=0, columnspan=2, sticky="ew", padx=14, pady=(2, 10))
        self.txt_log.grid_remove()
        self.after_idle(self._apply_panel_layout)

    def _scroll_tab(self, tab):
        """Return the tab's single shared scroller.

        Sound and music intentionally share one tab.  Previously both builders
        added their own scrollable frame, producing two scrollbars and almost no
        spacing.  Caching the frame gives every tab exactly one scroll surface.
        """
        box = getattr(tab, "_vstudio_scroll_box", None)
        if box is None:
            box = ctk.CTkScrollableFrame(tab, label_text="", fg_color=CARD,
                                         scrollbar_button_color="#424A5B",
                                         scrollbar_button_hover_color="#687286")
            box.pack(fill="both", expand=True, padx=(0, 2), pady=2)
            tab._vstudio_scroll_box = box
        return box

    # ------------------------------------------------- zakładka: DŹWIĘK
    def _tab_sound(self, tab):
        box = self._scroll_tab(tab)
        self.lbl_audio_warn = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11, weight="bold"),
                                           text_color=WHITE, wraplength=280, justify="left")
        self.lbl_audio_warn.pack(anchor="w", padx=16, pady=(12, 0))

        self._section(box, "Sceneria")
        self.var_profile = ctk.StringVar(value=(self.audio.profile_id if self.audio else "pokoj"))
        for pid, p in AUDIO_PROFILES.items():
            label = p["label"]
            ctk.CTkRadioButton(box, text=label, variable=self.var_profile, value=pid,
                               command=self._on_profile).pack(anchor="w", padx=16, pady=2)
        self.lbl_prof_desc = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11),
                                          text_color=MUTED, wraplength=280, justify="left")
        self.lbl_prof_desc.pack(anchor="w", padx=16, pady=(4, 0))

        self._section(box, "Poziomy")
        pct = lambda v: "%d%%" % int(v * 100)
        a = CFG["audio"]
        self.sld_volume, self.val_volume = self._slider_card(
            box, "Głośność", a.get("volume", 0.8), 0, 1, 100, pct, self._on_audio_sliders)
        self.sld_noise, self.val_noise = self._slider_card(
            box, "Poziom szumu", a.get("noise_level", 0.5), 0, 1, 100, pct, self._on_audio_sliders)
        self.sld_event, self.val_event = self._slider_card(
            box, "Częstotliwość zdarzeń", a.get("event_rate", 0.5), 0, 1, 100, pct, self._on_audio_sliders)
        self.sld_bass, self.val_bass = self._slider_card(
            box, "Niskie tony", a.get("bass", 0.5), 0, 1, 100, pct, self._on_audio_sliders)

        self._section(box, "Oddech")
        self.var_breath = ctk.BooleanVar(value=a.get("breath_on", True))
        ctk.CTkCheckBox(box, text="Oddech (odznacz = wyciszony)", variable=self.var_breath,
                        command=self._on_breath_toggle).pack(anchor="w", padx=16, pady=2)
        self.sld_breath, self.val_breath = self._slider_card(
            box, "Głębokość oddechu", a.get("breath_level", 0.45), 0, 1, 100, pct, self._on_breath_level)
        self.sld_brate, self.val_brate = self._slider_card(
            box, "Tempo oddechu", a.get("breath_rate", 13), 6, 24, 18,
            lambda v: "%d /min" % int(v), self._on_breath_rate)
        self._hint(box, "Cichy, naturalny oddech jak z telefonu blisko ust. Tempo dryfuje ±3.")

        self._section(box, "Mikrofon")
        self.var_mute = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(box, text="Wycisz mikrofon", variable=self.var_mute,
                        command=self._on_mute).pack(anchor="w", padx=16, pady=2)
        ctk.CTkLabel(box, text="Urządzenie wyjściowe", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(anchor="w", padx=16, pady=(10, 0))
        self.var_outdev = ctk.StringVar(value="(domyślne)")
        self.opt_outdev = ctk.CTkOptionMenu(box, variable=self.var_outdev, values=["(domyślne)"],
                                            width=270, command=lambda _: self._on_outdev_change())
        self.opt_outdev.pack(anchor="w", padx=16, pady=4)
        self.var_cable_only = ctk.BooleanVar(value=a.get("cable_only", True))
        ctk.CTkCheckBox(box, text="Tylko wirtualne kable (bezpieczne)", variable=self.var_cable_only,
                        command=self._refresh_devices_combo).pack(anchor="w", padx=16, pady=2)
        row = ctk.CTkFrame(box, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(row, text="Odśwież", width=130, command=self._refresh_devices_combo,
                      **GHOST).pack(side="left", padx=4)
        ctk.CTkButton(row, text="Test dźwięku", width=130, command=self._test_sound,
                      **GHOST).pack(side="left", padx=4)
        self.lbl_outdev = ctk.CTkLabel(box, text="", font=ctk.CTkFont(size=11),
                                       text_color=MUTED, wraplength=280, justify="left")
        self.lbl_outdev.pack(anchor="w", padx=16, pady=(4, 0))
        ctk.CTkLabel(box, text="Poziom (VU)", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(anchor="w", padx=16, pady=(10, 0))
        self.vu_bar = ctk.CTkProgressBar(box, height=14, corner_radius=7,
                                         fg_color=CARD2, progress_color=WHITE)
        self.vu_bar.pack(fill="x", padx=16, pady=4)
        self.vu_bar.set(0)
        self._hint(box, "W komunikatorze jako mikrofon wybierz stronę odbiorczą kabla "
                        f"(CABLE Output / {self.camera_name}).")
        self._update_profile_desc()

    # ------------------------------------------------- zakładka: GENERATOR 3D TWARZY
    def _tab_face3d(self, tab):
        self._face3d_active = False
        try:
            from face_animator import Face3DAnimator
            self.face_animator = Face3DAnimator()
        except Exception as e:
            traceback.print_exc()
            self._log(f"[BŁĄD] Inicjalizacja Face3DAnimator: {e}")
            self.face_animator = None
        self._face3d_streaming = False

        box = self._scroll_tab(tab)
        self._section(box, "👤 Generator Modeli 3D Twarzy & Animacje")
        self._hint(box, "Trójwymiarowy model głowy z animacją naturalną, nienaturalną, obrotem 360° oraz syntezą mowy TTS z ruchem ust (Lip-Sync, 100% offline).")

        # Główny przełącznik ON / OFF generatora twarzy 3D
        self.var_face3d_enabled = ctk.BooleanVar(value=False)
        self.var_stream_vcam = self.var_face3d_enabled
        card_master = ctk.CTkFrame(box, fg_color=CARD2, corner_radius=10, border_width=1, border_color=LINE)
        card_master.pack(fill="x", padx=12, pady=6)

        row_sw = ctk.CTkFrame(card_master, fg_color="transparent")
        row_sw.pack(fill="x", padx=10, pady=8)

        self.sw_face3d = ctk.CTkSwitch(
            row_sw,
            text="🎭 Generator Twarzy 3D (WŁ / WYŁ)",
            variable=self.var_face3d_enabled,
            font=ctk.CTkFont(size=13, weight="bold"),
            command=self._face3d_toggle_master
        )
        self.sw_face3d.pack(side="left", padx=4)

        self.lbl_face3d_status = ctk.CTkLabel(
            row_sw,
            text="WYŁĄCZONY (Odtwarzacz biblioteki aktywny)",
            text_color=MUTED,
            font=ctk.CTkFont(size=11)
        )
        self.lbl_face3d_status.pack(side="right", padx=4)

        self._section(box, "1. Fotorealistyczne Modele 3D (Kolekcja Korean Man, Kobieta i Realistyczne Asety)")
        row_src = ctk.CTkFrame(box, fg_color="transparent")
        row_src.pack(fill="x", padx=12, pady=4)

        self.face_model_map = {
            "🌟 Korean Man (Ultra-HD)": "korean_man",
            "🌸 Korean Woman (Studio)": "korean_woman",
            "🎬 Studio Director HD": "korean_studio",
            "⚡ Cyber 2077 (Neo-Seoul)": "korean_cyber",
            "✨ Anime 3D Realistic": "korean_anime",
            "🧔 Realistic Male (Europejczyk)": "realistic_male",
            "👩 Realistic Female (Europejka)": "realistic_female",
            "🧬 Skan Anatomiczny 3D (478 pkt)": "canonical_scan",
        }
        self.face_model_reverse_map = {v: k for k, v in self.face_model_map.items()}

        self.var_face_gender = ctk.StringVar(value="korean_man")
        self.var_face_model_display = ctk.StringVar(value="🌟 Korean Man (Ultra-HD)")

        ctk.CTkLabel(row_src, text="Wybierz Model 3D:", text_color=MUTED, font=ctk.CTkFont(size=12, weight="bold")).pack(side="left", padx=(4, 6))
        self.opt_face_model = ctk.CTkOptionMenu(
            row_src,
            values=list(self.face_model_map.keys()),
            variable=self.var_face_model_display,
            command=self._on_face_model_dropdown_change,
            width=260,
            **OPTION_MENU
        )
        self.opt_face_model.pack(side="left", padx=4)

        row_quick_models = ctk.CTkFrame(box, fg_color="transparent")
        row_quick_models.pack(fill="x", padx=12, pady=2)
        for label, m_key in [("🌟 Korean Man", "korean_man"), ("🌸 Korean Woman", "korean_woman"),
                             ("🎬 Studio HD", "korean_studio"), ("⚡ Cyber", "korean_cyber"),
                             ("🧔 Real Male", "realistic_male"), ("👩 Real Female", "realistic_female")]:
            ctk.CTkButton(
                row_quick_models,
                text=label,
                font=ctk.CTkFont(size=11),
                width=80,
                command=lambda k=m_key: self._select_model_by_key(k),
                **GHOST
            ).pack(side="left", padx=2)

        row_btns = ctk.CTkFrame(box, fg_color="transparent")
        row_btns.pack(fill="x", padx=12, pady=4)
        ctk.CTkButton(row_btns, text="🎲 Kolejny model 3D", command=self._face3d_cycle, **PRIMARY).pack(side="left", padx=3)
        ctk.CTkButton(row_btns, text="📁 Wczytaj model 3D (OBJ/MA/3DS)...", command=self._face3d_pick_model_file, **GHOST).pack(side="left", padx=3)

        self._section(box, "🧠 Generator AI 360° Tekstury Twarzy ze Zdjęcia (AI 360 UV)")
        self._hint(box, "Generuj kompletną mapę UV 360° (twarz, uszy, skronie, włosy, szyję i tył głowy) ze zdjęcia frontalnego za pomocą AI (Lokalna sieć neuronowa lub OpenAI/Gemini).")

        card_ai = ctk.CTkFrame(box, fg_color=CARD2, corner_radius=10, border_width=1, border_color=LINE)
        card_ai.pack(fill="x", padx=12, pady=4)

        row_ai_engine = ctk.CTkFrame(card_ai, fg_color="transparent")
        row_ai_engine.pack(fill="x", padx=10, pady=(8, 3))
        ctk.CTkLabel(row_ai_engine, text="Silnik AI:", font=ctk.CTkFont(size=11, weight="bold"), text_color=TEXT).pack(side="left", padx=(0, 6))

        self.ai_engine_map = {
            "🤖 Wbudowany AI Neural 360 (Offline - bez klucza)": "local_neural",
            "🌐 OpenAI (GPT-4o Vision / DALL-E 3)": "openai",
            "✨ Google Gemini Pro Vision": "gemini",
        }
        self.var_ai_engine = ctk.StringVar(value="🤖 Wbudowany AI Neural 360 (Offline - bez klucza)")
        ctk.CTkOptionMenu(row_ai_engine, variable=self.var_ai_engine,
                          values=list(self.ai_engine_map.keys()),
                          width=260, fg_color=CARD, button_color=LINE,
                          button_hover_color=CARD2, text_color=TEXT).pack(side="left", fill="x", expand=True)

        row_ai_style = ctk.CTkFrame(card_ai, fg_color="transparent")
        row_ai_style.pack(fill="x", padx=10, pady=(2, 3))
        ctk.CTkLabel(row_ai_style, text="Styl 360:", font=ctk.CTkFont(size=11, weight="bold"), text_color=TEXT).pack(side="left", padx=(0, 6))

        self.ai_style_map = {
            "Fotorealistyczny 360 (Ultra-Realistic)": "photorealistic",
            "Studio Kinowe 360 (Cinematic HD)": "cinematic",
            "Cyberpunk 2077 / Neo-Seoul 360": "cyberpunk",
            "K-Pop / Stylized Anime 3D": "anime",
        }
        self.var_ai_style = ctk.StringVar(value="Fotorealistyczny 360 (Ultra-Realistic)")
        ctk.CTkOptionMenu(row_ai_style, variable=self.var_ai_style,
                          values=list(self.ai_style_map.keys()),
                          width=260, fg_color=CARD, button_color=LINE,
                          button_hover_color=CARD2, text_color=TEXT).pack(side="left", fill="x", expand=True)

        row_ai_key = ctk.CTkFrame(card_ai, fg_color="transparent")
        row_ai_key.pack(fill="x", padx=10, pady=(2, 3))
        ctk.CTkLabel(row_ai_key, text="Klucz API:", font=ctk.CTkFont(size=11), text_color=MUTED).pack(side="left", padx=(0, 6))
        self.ent_ai_key = ctk.CTkEntry(row_ai_key, placeholder_text="Opcjonalny (dla chmury OpenAI / Gemini)...", show="*", width=200, fg_color=BG, text_color=TEXT)
        self.ent_ai_key.pack(side="left", fill="x", expand=True)

        row_ai_btns = ctk.CTkFrame(card_ai, fg_color="transparent")
        row_ai_btns.pack(fill="x", padx=10, pady=(4, 6))
        ctk.CTkButton(row_ai_btns, text="📷 Generuj 360 z Biblioteki",
                      command=self._face3d_generate_ai_360_from_library, **ACCENT).pack(side="left", padx=2)
        ctk.CTkButton(row_ai_btns, text="📁 Generuj 360 ze zdjęcia...",
                      command=self._face3d_generate_ai_360_from_file, **PRIMARY).pack(side="left", padx=2)
        ctk.CTkButton(row_ai_btns, text="💾 Eksportuj UV (PNG)...",
                      command=self._face3d_export_uv_texture, **GHOST).pack(side="left", padx=2)

        self.lbl_ai_status = ctk.CTkLabel(card_ai, text="Silnik gotowy do syntezy pełnej tekstury 360° ze zdjęcia.", font=ctk.CTkFont(size=10), text_color=MUTED)
        self.lbl_ai_status.pack(fill="x", padx=10, pady=(0, 6))

        self._section(box, "🎭 Nakładanie i integracja zdjęcia na maskę Korean 3D")
        self._hint(box, "Nałóż i zintegruj dowolne zdjęcie twarzy bezpośrednio na trójwymiarową maskę modelu Korean Man (wtopienie UV, skalowanie i dopasowanie koloru skóry).")

        card_kov = ctk.CTkFrame(box, fg_color=CARD2, corner_radius=10, border_width=1, border_color=LINE)
        card_kov.pack(fill="x", padx=12, pady=4)

        row_kov_btns = ctk.CTkFrame(card_kov, fg_color="transparent")
        row_kov_btns.pack(fill="x", padx=10, pady=(8, 4))
        ctk.CTkButton(row_kov_btns, text="📷 Nałóż zdjęcie z Biblioteki",
                      command=self._face3d_apply_library_photo_korean, **ACCENT).pack(side="left", padx=3)
        ctk.CTkButton(row_kov_btns, text="📁 Wczytaj z dysku...",
                      command=self._face3d_pick_photo_overlay_korean, **PRIMARY).pack(side="left", padx=3)
        ctk.CTkButton(row_kov_btns, text="↺ Reset tekstury",
                      command=self._face3d_reset_korean_tex, **GHOST).pack(side="left", padx=3)

        self.sld_kov_opacity, self.val_kov_opacity = self._slider_card(
            card_kov, "Krycie / Siła wtopienia", 85, 0, 100, 100,
            lambda v: f"{int(v)}%", self._face3d_on_korean_overlay_slider
        )
        self.sld_kov_scale, self.val_kov_scale = self._slider_card(
            card_kov, "Skala twarzy na masce", 1.0, 0.70, 1.45, 75,
            lambda v: f"{v:.2f}×", self._face3d_on_korean_overlay_slider
        )
        self.sld_kov_offy, self.val_kov_offy = self._slider_card(
            card_kov, "Pozycja pionowa Y", 0, -80, 80, 160,
            lambda v: f"{int(v):+d} px", self._face3d_on_korean_overlay_slider
        )
        self.sld_kov_offx, self.val_kov_offx = self._slider_card(
            card_kov, "Pozycja pozioma X", 0, -60, 60, 120,
            lambda v: f"{int(v):+d} px", self._face3d_on_korean_overlay_slider
        )
        self.sld_kov_feather, self.val_kov_feather = self._slider_card(
            card_kov, "Wtopienie krawędzi (Feathering)", 22, 4, 50, 46,
            lambda v: f"{int(v)} px", self._face3d_on_korean_overlay_slider
        )

        row_kov_check = ctk.CTkFrame(card_kov, fg_color="transparent")
        row_kov_check.pack(fill="x", padx=10, pady=(2, 4))
        self.var_kov_remove_bg = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(row_kov_check, text="✂️ Usuń tło ze zdjęcia i wyspotuj tylko twarz",
                        variable=self.var_kov_remove_bg, font=ctk.CTkFont(size=11),
                        command=self._face3d_on_korean_overlay_slider).pack(side="left", padx=3)

        row_kov_check2 = ctk.CTkFrame(card_kov, fg_color="transparent")
        row_kov_check2.pack(fill="x", padx=10, pady=(0, 8))
        self.var_kov_match_skin = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(row_kov_check2, text="✨ Automatyczne dopasowanie koloru skóry (Auto Skin Balance)",
                        variable=self.var_kov_match_skin, font=ctk.CTkFont(size=11),
                        command=self._face3d_on_korean_overlay_slider).pack(side="left", padx=3)

        self._section(box, "🎭 Realistyczne Tło Sceny 3D (Background)")
        card_bg = ctk.CTkFrame(box, fg_color=CARD2, corner_radius=10, border_width=1, border_color=LINE)
        card_bg.pack(fill="x", padx=12, pady=4)

        row_bg_sel = ctk.CTkFrame(card_bg, fg_color="transparent")
        row_bg_sel.pack(fill="x", padx=10, pady=(8, 4))
        ctk.CTkLabel(row_bg_sel, text="Wybierz tło:", font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT).pack(side="left", padx=(0, 6))

        self.bg_options_map = {
            "📸 Studio Ciemne (Studio Dark)": "studio_dark",
            "💡 Studio Jasne (Studio Light)": "studio_light",
            "🏢 Nowoczesne Biuro (Office)": "office",
            "📺 Studio TV / Newsroom": "newsroom",
            "🛋️ Ciepły Loft / Apartament": "loft",
            "🌆 Cyberpunk / Neon City": "cyberpunk",
            "🌿 Plener / Park (Złota godzina)": "nature",
            "✨ Złoty Bokeh (Luxury Bokeh)": "bokeh",
            "🟩 Green Screen (Chroma Key)": "greenscreen",
            "📁 Własny obraz z dysku...": "custom"
        }
        self.var_face_bg_name = ctk.StringVar(value="📸 Studio Ciemne (Studio Dark)")
        ctk.CTkOptionMenu(row_bg_sel, variable=self.var_face_bg_name,
                          values=list(self.bg_options_map.keys()),
                          command=self._face3d_on_bg_change,
                          width=240, fg_color=CARD, button_color=LINE,
                          button_hover_color=CARD2, text_color=TEXT).pack(side="left", fill="x", expand=True)

        row_bg_btns = ctk.CTkFrame(card_bg, fg_color="transparent")
        row_bg_btns.pack(fill="x", padx=10, pady=(2, 6))
        ctk.CTkButton(row_bg_btns, text="📁 Wczytaj plik tła...",
                      command=self._face3d_pick_custom_bg, **PRIMARY).pack(side="left", padx=3)
        ctk.CTkButton(row_bg_btns, text="📷 Użyj tła z Biblioteki",
                      command=self._face3d_apply_library_bg, **GHOST).pack(side="left", padx=3)

        self.sld_bg_blur, self.val_bg_blur = self._slider_card(
            card_bg, "Głębia ostrości / Rozmycie tła (Bokeh)", 0, 0, 50, 50,
            lambda v: f"{int(v)} px", self._face3d_on_bg_slider
        )

        self._section(box, "📸 Generowanie modelu 3D ze zdjęcia (Opcja dodatkowa)")
        self._hint(box, "Opcja dodatkowa: Wczytaj własne zdjęcie portretowe — silnik 3D utworzy pełnowymiarową bryłę głowy z zachowaniem anatomii 3D.")
        row_photo = ctk.CTkFrame(box, fg_color="transparent")
        row_photo.pack(fill="x", padx=12, pady=4)
        ctk.CTkButton(row_photo, text="📷 Dopasuj model 3D do zdjęcia portretowego...",
                      command=self._face3d_fit_photo_btn, **GHOST).pack(side="left", padx=3)

        self._section(box, "2. Tryb wyświetlania 3D (Shader / Siatka)")
        self.var_face_render_mode = ctk.StringVar(value="textured")
        row_modes = ctk.CTkFrame(box, fg_color="transparent")
        row_modes.pack(fill="x", padx=12, pady=2)
        ctk.CTkRadioButton(row_modes, text="🎨 Fotorealistyczny 3D", variable=self.var_face_render_mode,
                           value="textured", font=ctk.CTkFont(size=11), text_color=TEXT,
                           command=self._face3d_update_render_mode).pack(side="left", padx=4)
        ctk.CTkRadioButton(row_modes, text="🕸️ Siatka Quad Wireframe", variable=self.var_face_render_mode,
                           value="wireframe", font=ctk.CTkFont(size=11), text_color=TEXT,
                           command=self._face3d_update_render_mode).pack(side="left", padx=4)

        row_modes2 = ctk.CTkFrame(box, fg_color="transparent")
        row_modes2.pack(fill="x", padx=12, pady=2)
        ctk.CTkRadioButton(row_modes2, text="💎 Hybryda (Siatka + Tekstura)", variable=self.var_face_render_mode,
                           value="textured_wireframe", font=ctk.CTkFont(size=11), text_color=TEXT,
                           command=self._face3d_update_render_mode).pack(side="left", padx=4)
        ctk.CTkRadioButton(row_modes2, text="🗿 Rzeźba Anatomiczna (Clay)", variable=self.var_face_render_mode,
                           value="clay", font=ctk.CTkFont(size=11), text_color=TEXT,
                           command=self._face3d_update_render_mode).pack(side="left", padx=4)

        row_toggles = ctk.CTkFrame(box, fg_color="transparent")
        row_toggles.pack(fill="x", padx=12, pady=4)
        self.var_face_hair = ctk.BooleanVar(value=True)
        self.var_face_neck = ctk.BooleanVar(value=True)
        self.var_face_ears = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(row_toggles, text="💇 Włosy 3D", variable=self.var_face_hair,
                         font=ctk.CTkFont(size=11), command=self._face3d_update_components).pack(side="left", padx=3)
        ctk.CTkCheckBox(row_toggles, text="🦒 Szyja", variable=self.var_face_neck,
                         font=ctk.CTkFont(size=11), command=self._face3d_update_components).pack(side="left", padx=3)
        ctk.CTkCheckBox(row_toggles, text="👂 Uszy", variable=self.var_face_ears,
                         font=ctk.CTkFont(size=11), command=self._face3d_update_components).pack(side="left", padx=3)

        self._section(box, "3. Sterowanie 3D i animacja głowy")
        self._hint(box, "Wskazówka: Możesz klikać i przeciągać myszą bezpośrednio po podglądzie telefonu, aby obracać głowę 3D, lub używać kółka myszy do przybliżania/oddalania!")

        # Przyciski kierunkowe D-Pad
        dpad_frame = ctk.CTkFrame(box, fg_color=CARD2, corner_radius=10, border_width=1, border_color=LINE)
        dpad_frame.pack(fill="x", padx=12, pady=4)
        
        row_d1 = ctk.CTkFrame(dpad_frame, fg_color="transparent")
        row_d1.pack(pady=(4, 2))
        ctk.CTkButton(row_d1, text="⬆️ W górę", width=90, height=26, command=lambda: self._face3d_cmd("up"), **GHOST).pack()

        row_d2 = ctk.CTkFrame(dpad_frame, fg_color="transparent")
        row_d2.pack(pady=2)
        ctk.CTkButton(row_d2, text="⬅️ W lewo", width=84, height=26, command=lambda: self._face3d_cmd("left"), **GHOST).pack(side="left", padx=3)
        ctk.CTkButton(row_d2, text="🎯 Reset", width=70, height=26, command=lambda: self._face3d_cmd("reset"), **PRIMARY).pack(side="left", padx=3)
        ctk.CTkButton(row_d2, text="➡️ W prawo", width=84, height=26, command=lambda: self._face3d_cmd("right"), **GHOST).pack(side="left", padx=3)

        row_d3 = ctk.CTkFrame(dpad_frame, fg_color="transparent")
        row_d3.pack(pady=2)
        ctk.CTkButton(row_d3, text="⬇️ W dół", width=90, height=26, command=lambda: self._face3d_cmd("down"), **GHOST).pack()

        row_d4 = ctk.CTkFrame(dpad_frame, fg_color="transparent")
        row_d4.pack(pady=(2, 6))
        ctk.CTkButton(row_d4, text="↩️ Przechył L", width=76, height=24, command=lambda: self._face3d_cmd("tilt_l"), **GHOST).pack(side="left", padx=2)
        ctk.CTkButton(row_d4, text="🔍 Przybliż", width=76, height=24, command=lambda: self._face3d_cmd("zoom_in"), **GHOST).pack(side="left", padx=2)
        ctk.CTkButton(row_d4, text="🔎 Oddal", width=76, height=24, command=lambda: self._face3d_cmd("zoom_out"), **GHOST).pack(side="left", padx=2)
        ctk.CTkButton(row_d4, text="↪️ Przechył P", width=76, height=24, command=lambda: self._face3d_cmd("tilt_r"), **GHOST).pack(side="left", padx=2)

        self._section(box, "4. Sekwencje animacji")
        self.var_anim_mode = ctk.StringVar(value="natural")
        ctk.CTkRadioButton(box, text="1. Naturalny ruch człowieka (obrót w prawo, saccades, mruganie, oddech)",
                           variable=self.var_anim_mode, value="natural", font=ctk.CTkFont(size=11),
                           command=self._face3d_update_anim).pack(anchor="w", padx=16, pady=2)
        ctk.CTkRadioButton(box, text="2. Nienaturalny ruch (gwałtowny skręt w lewo, zacięcia robotyczne, freeze)",
                           variable=self.var_anim_mode, value="unnatural", font=ctk.CTkFont(size=11),
                           command=self._face3d_update_anim).pack(anchor="w", padx=16, pady=2)
        ctk.CTkRadioButton(box, text="3. Ciągły obrót 360° dookoła osi (Turntable 360°)",
                           variable=self.var_anim_mode, value="turntable", font=ctk.CTkFont(size=11),
                           command=self._face3d_update_anim).pack(anchor="w", padx=16, pady=2)
        ctk.CTkRadioButton(box, text="4. Skinienie głową (Potakiwanie / Tak)",
                           variable=self.var_anim_mode, value="nodding", font=ctk.CTkFont(size=11),
                           command=self._face3d_update_anim).pack(anchor="w", padx=16, pady=2)
        ctk.CTkRadioButton(box, text="5. Kręcenie głową (Przeczenie / Nie)",
                           variable=self.var_anim_mode, value="shaking", font=ctk.CTkFont(size=11),
                           command=self._face3d_update_anim).pack(anchor="w", padx=16, pady=2)

        self._section(box, "5. Synteza mowy TTS & Ruch ust (3D Lip-Sync)")
        self.txt_face_tts = ctk.CTkTextbox(box, height=56, font=ctk.CTkFont(size=12),
                                           fg_color=CARD2, corner_radius=10,
                                           border_width=1, border_color=LINE, text_color=TEXT, wrap="word")
        self.txt_face_tts.pack(fill="x", padx=16, pady=4)
        self.txt_face_tts.insert("1.0", "Dzień dobry. Model trójwymiarowy głowy działa w pełni lokalnie bez internetu.")

        row_tts = ctk.CTkFrame(box, fg_color="transparent")
        row_tts.pack(fill="x", padx=12, pady=4)
        ctk.CTkButton(row_tts, text="🗣️ Wypowiedz z ruchem ust (3D Lip-Sync)", command=self._face3d_speak_lipsync, **ACCENT).pack(side="left", padx=3)
        ctk.CTkButton(row_tts, text="⏹ Stop", command=self._face3d_stop_anim, **GHOST).pack(side="left", padx=3)

        self._section(box, "6. Eksport 3D")
        row_vcam = ctk.CTkFrame(box, fg_color="transparent")
        row_vcam.pack(fill="x", padx=12, pady=4)
        ctk.CTkButton(row_vcam, text="💾 Eksportuj klatkę / OBJ", command=self._face3d_export, **PRIMARY).pack(side="left", padx=4)

        # Inicjalizacja domyślnego modelu 3D (w gotowości, Master Switch domyślnie WYŁĄCZONY)
        self._face3d_init_model()
        self._face3d_start_stream_loop()

    def _face3d_init_model(self):
        if getattr(self, "face_animator", None):
            self.face_animator.load_model("korean_man")

    def _face3d_toggle_master(self):
        if not getattr(self, "face_animator", None):
            try:
                from face_animator import Face3DAnimator
                self.face_animator = Face3DAnimator()
            except Exception as e:
                self._log(f"[BŁĄD 3D] Nie można załadować modułu 3D: {e}")
                if hasattr(self, "lbl_face3d_status"):
                    self.lbl_face3d_status.configure(
                        text=f"❌ BŁĄD 3D: {str(e)[:30]}",
                        text_color="#ef4444"
                    )
                if hasattr(self, "sw_face3d"):
                    self.sw_face3d.deselect()
                if hasattr(self, "var_face3d_enabled"):
                    self.var_face3d_enabled.set(False)
                self._face3d_active = False
                return

        enabled = False
        if hasattr(self, "var_face3d_enabled") and self.var_face3d_enabled is not None:
            try:
                enabled = bool(self.var_face3d_enabled.get())
            except Exception:
                enabled = False
        elif hasattr(self, "sw_face3d") and self.sw_face3d is not None:
            try:
                enabled = bool(self.sw_face3d.get())
            except Exception:
                enabled = False

        self._face3d_active = enabled
        if hasattr(self, "var_face3d_enabled") and hasattr(self.var_face3d_enabled, "set"):
            self.var_face3d_enabled.set(enabled)

        if enabled:
            if hasattr(self, "sw_face3d") and hasattr(self.sw_face3d, "select"):
                self.sw_face3d.select()
            if hasattr(self, "lbl_face3d_status"):
                self.lbl_face3d_status.configure(
                    text="🟢 WŁĄCZONY (Model 3D w podglądzie & kamerze)",
                    text_color="#10b981"
                )
            self._log(f"3D Face360: Generator twarzy 3D WŁĄCZONY — model '{self.face_animator.active_model_name}' transmitowany.")
            self._face3d_push_frame()
        else:
            if hasattr(self, "sw_face3d") and hasattr(self.sw_face3d, "deselect"):
                self.sw_face3d.deselect()
            if hasattr(self, "lbl_face3d_status"):
                self.lbl_face3d_status.configure(
                    text="WYŁĄCZONY (Odtwarzacz biblioteki aktywny)",
                    text_color=MUTED
                )
            if self.video:
                self.video.set_custom_frame(None)
            self._log("3D Face360: Generator twarzy 3D WYŁĄCZONY — przywrócono multimedia z biblioteki.")

    def _on_face_model_dropdown_change(self, choice_label: str):
        model_key = getattr(self, "face_model_map", {}).get(choice_label, "korean_man")
        self._select_model_by_key(model_key)

    def _select_model_by_key(self, model_key: str):
        if hasattr(self, "var_face_gender"):
            self.var_face_gender.set(model_key)
        disp = getattr(self, "face_model_reverse_map", {}).get(model_key, model_key)
        if hasattr(self, "var_face_model_display"):
            self.var_face_model_display.set(disp)
        if getattr(self, "face_animator", None):
            self.face_animator.load_model(model_key)
            self._log(f"3D Face360: Załadowano model 3D: {disp} (100% trójwymiarowa siatka).")
        self._face3d_active = True
        if hasattr(self, "var_face3d_enabled"):
            self.var_face3d_enabled.set(True)
        if hasattr(self, "sw_face3d"):
            self.sw_face3d.select()
        self._face3d_toggle_master()
        self._face3d_push_frame()

    def _face3d_generate(self):
        g = getattr(self, "var_face_gender", None)
        model = g.get() if g else "korean_man"
        self._select_model_by_key(model)

    def _face3d_cycle(self):
        if getattr(self, "face_animator", None):
            next_model = self.face_animator.cycle_model()
            if hasattr(self, "var_face_gender"):
                self.var_face_gender.set(next_model)
            disp = getattr(self, "face_model_reverse_map", {}).get(next_model, next_model)
            if hasattr(self, "var_face_model_display"):
                self.var_face_model_display.set(disp)
            self._log(f"3D Face360: Przełączono na model 3D: {disp}")
        self._face3d_active = True
        if hasattr(self, "var_face3d_enabled"):
            self.var_face3d_enabled.set(True)
        if hasattr(self, "sw_face3d"):
            self.sw_face3d.select()
        self._face3d_toggle_master()
        self._face3d_push_frame()

    def _face3d_pick_model_file(self):
        p = filedialog.askopenfilename(
            title="Wybierz model 3D (OBJ/MA/3DS)",
            filetypes=[
                ("Modele 3D (OBJ/MA/3DS)", "*.obj *.ma *.mb *.3ds"),
                ("Wszystkie pliki", "*.*")
            ]
        )
        if p and getattr(self, "face_animator", None):
            self.face_animator.load_model_file(p)
            self._log(f"3D Face360: Załadowano model 3D: {os.path.basename(p)}")
            self._face3d_active = True
            if hasattr(self, "var_face3d_enabled"):
                self.var_face3d_enabled.set(True)
            if hasattr(self, "sw_face3d"):
                self.sw_face3d.select()
            self._face3d_toggle_master()
            self._face3d_push_frame()

    def _face3d_fit_photo_btn(self):
        p = filedialog.askopenfilename(
            title="Wybierz zdjęcie portretowe do dopasowania modelu 3D (Opcja dodatkowa)",
            filetypes=[
                ("Zdjęcia portretowe (PNG/JPG)", "*.png *.jpg *.jpeg *.bmp"),
                ("Wszystkie obrazy", "*.png *.jpg *.jpeg *.webp *.bmp")
            ]
        )
        if p and getattr(self, "face_animator", None):
            self.face_animator.fit_photo_file(p)
            self._log(f"3D Face360: Dopasowano model 3D do zdjęcia: {os.path.basename(p)}")
            self._face3d_active = True
            if hasattr(self, "var_face3d_enabled"):
                self.var_face3d_enabled.set(True)
            if hasattr(self, "sw_face3d"):
                self.sw_face3d.select()
            self._face3d_toggle_master()
            self._face3d_push_frame()

    def _face3d_apply_library_photo_korean(self):
        if not self.video or not self.video.playlist:
            self._log("3D Face360: Biblioteka jest pusta. Dodaj zdjęcie do biblioteki.")
            return
        cur = self.video.current()
        if not cur or cur.get("type") != "image":
            for it in self.video.playlist:
                if it.get("type") == "image":
                    cur = it
                    break
        if not cur or not os.path.isfile(cur["path"]):
            self._log("3D Face360: Brak aktywnego zdjęcia w bibliotece.")
            return

        try:
            img = Image.open(cur["path"]).convert("RGB")
            if getattr(self, "face_animator", None):
                self.face_animator.load_model("korean_man")
                if hasattr(self, "var_face_gender"):
                    self.var_face_gender.set("korean_man")
                self.face_animator.apply_photo_overlay_korean(
                    img,
                    offset_x=float(self.sld_kov_offx.get()) if hasattr(self, "sld_kov_offx") else 0.0,
                    offset_y=float(self.sld_kov_offy.get()) if hasattr(self, "sld_kov_offy") else 0.0,
                    scale=float(self.sld_kov_scale.get()) if hasattr(self, "sld_kov_scale") else 1.0,
                    opacity=float(self.sld_kov_opacity.get()) / 100.0 if hasattr(self, "sld_kov_opacity") else 0.85,
                    feather=int(self.sld_kov_feather.get()) if hasattr(self, "sld_kov_feather") else 22,
                    match_skin=self.var_kov_match_skin.get() if hasattr(self, "var_kov_match_skin") else True,
                    remove_bg=self.var_kov_remove_bg.get() if hasattr(self, "var_kov_remove_bg") else True,
                )
                self._log(f"3D Face360: Zintegrowano zdjęcie z Biblioteki ({os.path.basename(cur['path'])}) na maskę Korean 3D.")
                if hasattr(self, "var_face3d_enabled") and not self.var_face3d_enabled.get():
                    self.var_face3d_enabled.set(True)
                    self._face3d_toggle_master()
                self._face3d_push_frame()
        except Exception as e:
            self._log(f"Błąd integracji zdjęcia z biblioteki: {e}")

    def _face3d_pick_photo_overlay_korean(self):
        p = filedialog.askopenfilename(
            title="Wybierz zdjęcie do nałożenia na maskę Korean 3D",
            filetypes=[
                ("Zdjęcia", "*.png *.jpg *.jpeg *.bmp *.webp"),
                ("Wszystkie obrazy", "*.*")
            ]
        )
        if p and getattr(self, "face_animator", None):
            try:
                img = Image.open(p).convert("RGB")
                self.face_animator.load_model("korean_man")
                if hasattr(self, "var_face_gender"):
                    self.var_face_gender.set("korean_man")
                self.face_animator.apply_photo_overlay_korean(
                    img,
                    offset_x=float(self.sld_kov_offx.get()) if hasattr(self, "sld_kov_offx") else 0.0,
                    offset_y=float(self.sld_kov_offy.get()) if hasattr(self, "sld_kov_offy") else 0.0,
                    scale=float(self.sld_kov_scale.get()) if hasattr(self, "sld_kov_scale") else 1.0,
                    opacity=float(self.sld_kov_opacity.get()) / 100.0 if hasattr(self, "sld_kov_opacity") else 0.85,
                    feather=int(self.sld_kov_feather.get()) if hasattr(self, "sld_kov_feather") else 22,
                    match_skin=self.var_kov_match_skin.get() if hasattr(self, "var_kov_match_skin") else True,
                    remove_bg=self.var_kov_remove_bg.get() if hasattr(self, "var_kov_remove_bg") else True,
                )
                self._log(f"3D Face360: Nałożono i zintegrowano zdjęcie: {os.path.basename(p)} na maskę Korean 3D.")
                if hasattr(self, "var_face3d_enabled") and not self.var_face3d_enabled.get():
                    self.var_face3d_enabled.set(True)
                    self._face3d_toggle_master()
                self._face3d_push_frame()
            except Exception as e:
                self._log(f"Błąd wczytywania zdjęcia: {e}")

    def _face3d_reset_korean_tex(self):
        if getattr(self, "face_animator", None):
            self.face_animator.reset_korean_texture()
            if hasattr(self, "sld_kov_opacity"): self.sld_kov_opacity.set(85)
            if hasattr(self, "val_kov_opacity"): self.val_kov_opacity.configure(text="85%")
            if hasattr(self, "sld_kov_scale"): self.sld_kov_scale.set(1.0)
            if hasattr(self, "val_kov_scale"): self.val_kov_scale.configure(text="1.00×")
            if hasattr(self, "sld_kov_offy"): self.sld_kov_offy.set(0)
            if hasattr(self, "val_kov_offy"): self.val_kov_offy.configure(text="+0 px")
            if hasattr(self, "sld_kov_offx"): self.sld_kov_offx.set(0)
            if hasattr(self, "val_kov_offx"): self.val_kov_offx.configure(text="+0 px")
            if hasattr(self, "sld_kov_feather"): self.sld_kov_feather.set(22)
            if hasattr(self, "val_kov_feather"): self.val_kov_feather.configure(text="22 px")
            if hasattr(self, "var_kov_match_skin"): self.var_kov_match_skin.set(True)
            if hasattr(self, "var_kov_remove_bg"): self.var_kov_remove_bg.set(True)
            self._log("3D Face360: Przywrócono fabryczną teksturę modelu Korean 3D.")
            self._face3d_push_frame()

    def _face3d_on_korean_overlay_slider(self, *args):
        if not getattr(self, "face_animator", None):
            return
        if self.face_animator.korean_overlay_photo is not None:
            self.face_animator.apply_photo_overlay_korean(
                offset_x=float(self.sld_kov_offx.get()) if hasattr(self, "sld_kov_offx") else 0.0,
                offset_y=float(self.sld_kov_offy.get()) if hasattr(self, "sld_kov_offy") else 0.0,
                scale=float(self.sld_kov_scale.get()) if hasattr(self, "sld_kov_scale") else 1.0,
                opacity=float(self.sld_kov_opacity.get()) / 100.0 if hasattr(self, "sld_kov_opacity") else 0.85,
                feather=int(self.sld_kov_feather.get()) if hasattr(self, "sld_kov_feather") else 22,
                match_skin=self.var_kov_match_skin.get() if hasattr(self, "var_kov_match_skin") else True,
                remove_bg=self.var_kov_remove_bg.get() if hasattr(self, "var_kov_remove_bg") else True,
            )
            self._face3d_push_frame()

    def _face3d_generate_ai_360_from_library(self):
        if not self.video or not self.video.playlist:
            self._log("3D Face360: Biblioteka jest pusta. Dodaj zdjęcie do biblioteki.")
            if hasattr(self, "lbl_ai_status"):
                self.lbl_ai_status.configure(text="⚠️ Biblioteka jest pusta.")
            return
        cur = self.video.current()
        if not cur or cur.get("type") != "image":
            for it in self.video.playlist:
                if it.get("type") == "image":
                    cur = it
                    break
        if not cur or not os.path.isfile(cur["path"]):
            self._log("3D Face360: Brak aktywnego zdjęcia w bibliotece.")
            if hasattr(self, "lbl_ai_status"):
                self.lbl_ai_status.configure(text="⚠️ Wybierz zdjęcie z biblioteki.")
            return

        try:
            img = Image.open(cur["path"]).convert("RGB")
            self._face3d_run_ai_generation(img, os.path.basename(cur["path"]))
        except Exception as e:
            self._log(f"Błąd odczytu zdjęcia z biblioteki: {e}")
            if hasattr(self, "lbl_ai_status"):
                self.lbl_ai_status.configure(text=f"❌ Błąd zdjęcia: {e}")

    def _face3d_generate_ai_360_from_file(self):
        p = filedialog.askopenfilename(
            title="Wybierz zdjęcie frontalne twarzy do generacji 360 AI",
            filetypes=[
                ("Zdjęcia twarzy", "*.png *.jpg *.jpeg *.bmp *.webp"),
                ("Wszystkie obrazy", "*.*")
            ]
        )
        if not p:
            return
        try:
            img = Image.open(p).convert("RGB")
            self._face3d_run_ai_generation(img, os.path.basename(p))
        except Exception as e:
            self._log(f"Błąd otwarcia pliku: {e}")
            if hasattr(self, "lbl_ai_status"):
                self.lbl_ai_status.configure(text=f"❌ Błąd pliku: {e}")

    def _face3d_run_ai_generation(self, img_pil, source_name):
        if not getattr(self, "face_animator", None):
            return

        raw_engine = self.var_ai_engine.get() if hasattr(self, "var_ai_engine") else ""
        engine = self.ai_engine_map.get(raw_engine, "local_neural")

        raw_style = self.var_ai_style.get() if hasattr(self, "var_ai_style") else ""
        style = self.ai_style_map.get(raw_style, "photorealistic")

        api_key = self.ent_ai_key.get().strip() if hasattr(self, "ent_ai_key") else ""

        if hasattr(self, "lbl_ai_status"):
            self.lbl_ai_status.configure(text=f"⏳ Rozpoczynanie generacji 360 AI ({engine} / {style})...", text_color="#38bdf8")
        self._log(f"3D Face360 AI: Rozpoczęto generację pełnej tekstury 360 ze zdjęcia '{source_name}' (silnik: {engine}, styl: {style})...")

        def worker():
            try:
                def progress(pct, msg):
                    if hasattr(self, "lbl_ai_status") and not getattr(self, "_closing", False):
                        try:
                            self.lbl_ai_status.configure(text=f"⏳ {int(pct*100)}%: {msg}", text_color="#38bdf8")
                        except Exception:
                            pass

                tex = self.face_animator.generate_ai_360_texture(
                    photo=img_pil,
                    engine=engine,
                    style=style,
                    api_key=api_key,
                    progress_callback=progress
                )

                def on_done():
                    if hasattr(self, "var_face_gender"):
                        self.var_face_gender.set("korean_man")
                    if hasattr(self, "lbl_ai_status"):
                        self.lbl_ai_status.configure(text=f"✅ Gotowe! Tekstura 360 nałożona na model ({tex.size[0]}×{tex.size[1]}).", text_color="#10b981")
                    self._log(f"3D Face360 AI: Pomyślnie zsyntetyzowano i nałożono teksturę 360 na model Korean 3D.")
                    self._face3d_active = True
                    if hasattr(self, "var_face3d_enabled"):
                        self.var_face3d_enabled.set(True)
                    if hasattr(self, "sw_face3d") and hasattr(self.sw_face3d, "select"):
                        self.sw_face3d.select()
                    self._face3d_toggle_master()
                    self._face3d_push_frame()

                if not getattr(self, "_closing", False):
                    self.after(0, on_done)
            except Exception as e:
                err_msg = str(e)
                def on_err():
                    if hasattr(self, "lbl_ai_status"):
                        self.lbl_ai_status.configure(text=f"❌ Błąd AI: {err_msg[:60]}", text_color="#ef4444")
                    self._log(f"3D Face360 AI Błąd: {err_msg}")
                if not getattr(self, "_closing", False):
                    self.after(0, on_err)

        th = threading.Thread(target=worker, daemon=True)
        th.start()

    def _face3d_export_uv_texture(self):
        if not getattr(self, "face_animator", None):
            return
        p = filedialog.asksaveasfilename(
            title="Eksportuj mapę tekstury UV 360 (PNG)",
            defaultextension=".png",
            filetypes=[
                ("Plik obrazu PNG (*.png)", "*.png"),
                ("Wszystkie pliki", "*.*")
            ],
            initialfile="korean_man_ai_360_uv.png"
        )
        if not p:
            return
        ok = self.face_animator.export_current_texture(p)
        if ok:
            if hasattr(self, "lbl_ai_status"):
                self.lbl_ai_status.configure(text=f"💾 Zapisano UV: {os.path.basename(p)}")
            self._log(f"3D Face360: Wyeksportowano mapę UV do {os.path.basename(p)}.")
        else:
            if hasattr(self, "lbl_ai_status"):
                self.lbl_ai_status.configure(text="❌ Błąd eksportu UV.")
            self._log("3D Face360: Nie udało się wyeksportować mapy UV.")

    def _face3d_on_bg_change(self, choice):
        if not getattr(self, "face_animator", None):
            return
        bg_key = self.bg_options_map.get(choice, "studio_dark")
        if bg_key == "custom" and not self.face_animator.custom_bg:
            self._face3d_pick_custom_bg()
            return
        blur = int(self.sld_bg_blur.get()) if hasattr(self, "sld_bg_blur") else 0
        self.face_animator.set_background(bg_key, blur=blur)
        self._log(f"3D Face360: Zmieniono tło sceny na: {choice}")
        self._face3d_push_frame()

    def _face3d_pick_custom_bg(self):
        p = filedialog.askopenfilename(
            title="Wybierz plik graficzny jako tło 3D",
            filetypes=[
                ("Obrazy tła", "*.jpg *.jpeg *.png *.webp *.bmp"),
                ("Wszystkie pliki", "*.*")
            ]
        )
        if p and getattr(self, "face_animator", None):
            try:
                blur = int(self.sld_bg_blur.get()) if hasattr(self, "sld_bg_blur") else 0
                self.face_animator.load_background_file(p, blur=blur)
                if hasattr(self, "var_face_bg_name"):
                    self.var_face_bg_name.set("📁 Własny obraz z dysku...")
                self._log(f"3D Face360: Wczytano własne tło: {os.path.basename(p)}")
                self._face3d_push_frame()
            except Exception as e:
                self._log(f"Błąd wczytywania pliku tła: {e}")

    def _face3d_apply_library_bg(self):
        if not self.video or not self.video.playlist:
            self._log("3D Face360: Biblioteka jest pusta. Dodaj zdjęcie do biblioteki.")
            return
        cur = self.video.current()
        if not cur or cur.get("type") != "image":
            for it in self.video.playlist:
                if it.get("type") == "image":
                    cur = it
                    break
        if not cur or not os.path.isfile(cur["path"]):
            self._log("3D Face360: Brak aktywnego obrazu w bibliotece.")
            return
        try:
            blur = int(self.sld_bg_blur.get()) if hasattr(self, "sld_bg_blur") else 0
            self.face_animator.load_background_file(cur["path"], blur=blur)
            if hasattr(self, "var_face_bg_name"):
                self.var_face_bg_name.set("📁 Własny obraz z dysku...")
            self._log(f"3D Face360: Ustawiono tło z Biblioteki: {os.path.basename(cur['path'])}")
            self._face3d_push_frame()
        except Exception as e:
            self._log(f"Błąd ustawiania tła z biblioteki: {e}")

    def _face3d_on_bg_slider(self, *args):
        if not getattr(self, "face_animator", None):
            return
        choice = self.var_face_bg_name.get() if hasattr(self, "var_face_bg_name") else "📸 Studio Ciemne (Studio Dark)"
        bg_key = self.bg_options_map.get(choice, "studio_dark")
        blur = int(self.sld_bg_blur.get()) if hasattr(self, "sld_bg_blur") else 0
        self.face_animator.set_background(bg_key, blur=blur)
        self._face3d_push_frame()

    def _face3d_pick_file(self):
        self._face3d_pick_model_file()

    def _face3d_pick_photo(self):
        self._face3d_fit_photo_btn()

    def _face3d_cmd(self, action):
        if not getattr(self, "face_animator", None):
            return
        if action == "left":
            self.face_animator.rotate_left()
        elif action == "right":
            self.face_animator.rotate_right()
        elif action == "up":
            self.face_animator.rotate_up()
        elif action == "down":
            self.face_animator.rotate_down()
        elif action == "tilt_l":
            self.face_animator.tilt_left()
        elif action == "tilt_r":
            self.face_animator.tilt_right()
        elif action == "zoom_in":
            self.face_animator.zoom_in()
        elif action == "zoom_out":
            self.face_animator.zoom_out()
        elif action == "reset":
            self.face_animator.reset_pose()
        self._face3d_push_frame()

    def _face3d_update_render_mode(self):
        if getattr(self, "face_animator", None) and hasattr(self, "var_face_render_mode"):
            mode = self.var_face_render_mode.get()
            self.face_animator.set_render_mode(mode)
            self._log(f"3D Face360: Tryb wyświetlania zmieniony na: {mode}")
            self._face3d_push_frame()

    def _face3d_update_components(self):
        if getattr(self, "face_animator", None):
            self.face_animator.show_hair = self.var_face_hair.get() if hasattr(self, "var_face_hair") else True
            self.face_animator.show_neck = self.var_face_neck.get() if hasattr(self, "var_face_neck") else True
            self.face_animator.show_ears = self.var_face_ears.get() if hasattr(self, "var_face_ears") else True
            self._face3d_push_frame()

    def _face3d_update_anim(self):
        if getattr(self, "face_animator", None) and hasattr(self, "var_anim_mode"):
            self.face_animator.anim_mode = self.var_anim_mode.get()
            self._log(f"3D Face360: Tryb animacji zmieniony na: {self.face_animator.anim_mode}")

    def _face3d_speak_lipsync(self):
        txt = self.txt_face_tts.get("1.0", "end").strip()
        if not txt:
            return
        self._log(f"3D Face360: Wypowiedź z ruchem ust: {txt[:35]}...")
        dur = max(1.5, len(txt) / 14.0)
        if getattr(self, "face_animator", None):
            self.face_animator.trigger_speech(txt, dur)

        def _worker():
            try:
                import pyttsx3
                eng = pyttsx3.init()
                eng.say(txt)
                eng.runAndWait()
            except Exception as exc:
                self._log(f"3D Lip-Sync TTS: {exc}")

        threading.Thread(target=_worker, daemon=True).start()

    def _face3d_stop_anim(self):
        if getattr(self, "face_animator", None):
            self.face_animator.stop_speech()

    def _face3d_toggle_stream(self):
        self._face3d_toggle_master()

    def _face3d_push_frame(self):
        if getattr(self, "face_animator", None) and self.video and getattr(self, "_face3d_active", False):
            try:
                fr = self.face_animator.render_frame(time.time(), 480, 640)
                self.video.set_custom_frame(fr)
                if HAS_PIL and hasattr(self, "lbl_preview") and not getattr(self, "_closing", False):
                    try:
                        pw = max(120, self.lbl_preview.winfo_width() - 4)
                        ph = max(160, self.lbl_preview.winfo_height() - 4)
                        fh, fw = fr.size[1], fr.size[0]
                        s = min(pw / fw, ph / fh)
                        dw, dh = max(1, int(fw * s)), max(1, int(fh * s))
                        img_scaled = fr.resize((dw, dh), Image.BILINEAR)
                        ctk_img = ctk.CTkImage(light_image=img_scaled, dark_image=img_scaled, size=(dw, dh))
                        self.lbl_preview.configure(image=ctk_img, text="")
                        self.lbl_preview.image = ctk_img
                    except Exception:
                        pass
            except Exception as e:
                self._log(f"3D Render error: {e}")

    def _face3d_start_stream_loop(self):
        def _loop():
            while not getattr(self, "_closing", False):
                if getattr(self, "face_animator", None) and self.video and getattr(self, "_face3d_active", False):
                    try:
                        fr = self.face_animator.render_frame(time.time(), 480, 640)
                        self.video.set_custom_frame(fr)
                    except Exception:
                        pass
                time.sleep(0.033)

        threading.Thread(target=_loop, daemon=True).start()

    def _face3d_export(self):
        p = filedialog.asksaveasfilename(
            title="Zapisz klatkę lub model 3D OBJ",
            defaultextension=".png",
            filetypes=[("PNG Obraz", "*.png"), ("Model 3D Wavefront OBJ", "*.obj"), ("JPEG Obraz", "*.jpg")]
        )
        if not p or not getattr(self, "face_animator", None):
            return
        if p.lower().endswith(".obj"):
            mesh = self.face_animator.head_mesh
            if mesh and "positions" in mesh and "indices" in mesh:
                lines = ["# Wavefront OBJ exported from vStudio 3D Face Generator\n"]
                for vx, vy, vz in mesh["positions"]:
                    lines.append(f"v {vx:.6f} {vy:.6f} {vz:.6f}\n")
                if "uvs" in mesh:
                    for u, v in mesh["uvs"]:
                        lines.append(f"vt {u:.6f} {v:.6f}\n")
                for tri in mesh["indices"]:
                    lines.append(f"f {tri[0]+1}/{tri[0]+1} {tri[1]+1}/{tri[1]+1} {tri[2]+1}/{tri[2]+1}\n")
                Path(p).write_text("".join(lines), encoding="utf-8")
                self._log(f"3D Face360: Wyeksportowano pełny model 3D OBJ: {os.path.basename(p)}")
        else:
            fr = self.face_animator.render_frame(time.time(), 1080, 1440)
            fr.save(p)
            self._log(f"3D Face360: Wyeksportowano kadr wysokiej rozdzielczości: {os.path.basename(p)}")

    # ------------------------------------------------- zakładka: OBRAZ
    def _tab_image(self, tab):
        box = self._scroll_tab(tab)
        v = self.video
        self._section(box, "Kadr i filtr")
        row = ctk.CTkFrame(box, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=2)
        ctk.CTkLabel(row, text="Kadrowanie", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="left")
        self.var_fit = ctk.StringVar(value=self._label_of(FIT_MODES, v.fit_mode if v else "fill"))
        ctk.CTkOptionMenu(row, variable=self.var_fit, values=list(FIT_MODES.values()) or ["-"],
                          width=170, command=self._on_fit_change).pack(side="right")
        row2 = ctk.CTkFrame(box, fg_color="transparent")
        row2.pack(fill="x", padx=16, pady=6)
        ctk.CTkLabel(row2, text="Filtr aparatu", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="left")
        self.var_filter = ctk.StringVar(value=self._label_of(FILTERS, v.filter_id if v else "normal"))
        ctk.CTkOptionMenu(row2, variable=self.var_filter, values=list(FILTERS.values()) or ["-"],
                          width=170, command=self._on_filter_change).pack(side="right")
        row3 = ctk.CTkFrame(box, fg_color="transparent")
        row3.pack(fill="x", padx=16, pady=6)
        ctk.CTkButton(row3, text="Obrót 90°", width=120, command=self._rotate,
                      **GHOST).pack(side="left")
        self.var_mirror = ctk.BooleanVar(value=v.mirror if v else False)
        ctk.CTkCheckBox(row3, text="Lustro", variable=self.var_mirror,
                        command=self._on_mirror).pack(side="right", padx=4)

        self._section(box, "Pokaz slajdów")
        row4 = ctk.CTkFrame(box, fg_color="transparent")
        row4.pack(fill="x", padx=16, pady=2)
        ctk.CTkLabel(row4, text="Tryb", font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        self.var_mode = ctk.StringVar(value=self._label_of(SLIDESHOW_MODES, v.mode if v else "auto"))
        ctk.CTkOptionMenu(row4, variable=self.var_mode, values=list(SLIDESHOW_MODES.values()) or ["-"],
                          width=170, command=self._on_mode_change).pack(side="right")
        row5 = ctk.CTkFrame(box, fg_color="transparent")
        row5.pack(fill="x", padx=16, pady=6)
        ctk.CTkLabel(row5, text="Co ile sekund", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="left")
        self.var_interval = ctk.StringVar(value=str(v.interval if v else 6.0))
        ctk.CTkOptionMenu(row5, variable=self.var_interval, width=100,
                          values=["2", "3", "4", "5", "6", "8", "10", "15", "20", "30"],
                          command=self._on_interval_change).pack(side="right")
        row6 = ctk.CTkFrame(box, fg_color="transparent")
        row6.pack(fill="x", padx=16, pady=6)
        ctk.CTkLabel(row6, text="Przejście", font=ctk.CTkFont(size=12), text_color=MUTED).pack(side="left")
        self.var_trans = ctk.StringVar(value=self._label_of(TRANSITIONS, v.transition if v else "fade"))
        ctk.CTkOptionMenu(row6, variable=self.var_trans, values=list(TRANSITIONS.values()) or ["-"],
                          width=170, command=self._on_trans_change).pack(side="right")

        self._section(box, "Nakładki aparatu")
        self.var_rec = ctk.BooleanVar(value=v.ov_rec if v else True)
        self.var_ts = ctk.BooleanVar(value=v.ov_timestamp if v else True)
        self.var_brand = ctk.BooleanVar(value=v.ov_brand if v else True)
        self.var_batt = ctk.BooleanVar(value=v.ov_battery if v else True)
        for text, var in (("Wskaźnik REC", self.var_rec), ("Data i godzina", self.var_ts),
                          ("Podpis Realme", self.var_brand), ("Ikona baterii", self.var_batt)):
            ctk.CTkCheckBox(box, text=text, variable=var,
                            command=self._on_fx).pack(anchor="w", padx=16, pady=3)
        self._hint(box, "Skróty: strzałki ← → przełączają slajdy.")

    # ------------------------------------------------- zakładka: KADR
    def _tab_frame(self, tab):
        box = self._scroll_tab(tab)
        v = self.video
        self._section(box, "Ręczne kadrowanie")
        self._hint(box, "Chwyć zdjęcie na podglądzie i przeciągnij. "
                        "Kółko myszy = zoom. Podwójny klik = reset. "
                        "Każde zdjęcie pamięta własny kadr.")
        self.sld_zoom, self.val_zoom = self._slider_card(
            box, "Zoom", v.zoom if v else 1.0, 0.5, 3.0, 50,
            lambda x: "%.2f×" % x, self._on_frame_sliders)
        self.sld_panx, self.val_panx = self._slider_card(
            box, "Pozycja X", v.pan_x if v else 0.0, -1, 1, 100,
            lambda x: "%+.2f" % x, self._on_frame_sliders)
        self.sld_pany, self.val_pany = self._slider_card(
            box, "Pozycja Y", v.pan_y if v else 0.0, -1, 1, 100,
            lambda x: "%+.2f" % x, self._on_frame_sliders)
        grid = ctk.CTkFrame(box, fg_color="transparent")
        grid.pack(fill="x", padx=12, pady=10)
        for i in range(3):
            grid.grid_columnconfigure(i, weight=1)
        presets = [(0, 0, "Środek", 0, 0), (1, 0, "Góra", 0, -1), (2, 0, "Dół", 0, 1),
                   (0, 1, "Lewo", -1, 0), (1, 1, "Prawo", 1, 0), (2, 1, "Reset", None, None)]
        for col, r, text, x, y in presets:
            if x is None:
                ctk.CTkButton(grid, text=text, command=self._frame_reset,
                              **GHOST).grid(row=r, column=col, padx=4, pady=4, sticky="ew")
            else:
                ctk.CTkButton(grid, text=text, command=lambda x=x, y=y: self._frame_preset(x, y),
                              **GHOST).grid(row=r, column=col, padx=4, pady=4, sticky="ew")

    # ------------------------------------------------- zakładka: EFEKTY
    def _tab_fx(self, tab):
        box = self._scroll_tab(tab)
        v = self.video
        self._section(box, "Efekty żywego telefonu")
        self.var_shake = ctk.BooleanVar(value=v.fx_shake if v else True)
        ctk.CTkCheckBox(box, text="Drganie ręki", variable=self.var_shake,
                        command=self._on_fx).pack(anchor="w", padx=16, pady=3)
        self.sld_shakeamt, self.val_shakeamt = self._slider_card(
            box, "Siła drgania", v.fx_shake_amount if v else 4.0, 0, 12, 24,
            lambda x: "%.1f" % x, self._on_fx_sliders)
        self.var_grain = ctk.BooleanVar(value=v.fx_grain if v else True)
        ctk.CTkCheckBox(box, text="Ziarno filmu", variable=self.var_grain,
                        command=self._on_fx).pack(anchor="w", padx=16, pady=3)
        self.sld_grainamt, self.val_grainamt = self._slider_card(
            box, "Ilość ziarna", v.fx_grain_amount if v else 6.0, 0, 25, 25,
            lambda x: "%.1f" % x, self._on_fx_sliders)
        self.var_vig = ctk.BooleanVar(value=v.fx_vignette if v else True)
        self.var_af = ctk.BooleanVar(value=v.fx_autofocus if v else True)
        for text, var in (("Winieta", self.var_vig), ("Animowany autofocus", self.var_af)):
            ctk.CTkCheckBox(box, text=text, variable=var,
                            command=self._on_fx).pack(anchor="w", padx=16, pady=3)
        self._hint(box, "Efekty sprawiają, że obraz wygląda jak nagranie z ręki.")

    # -------------------------------------------------------------- playlista
    def _refresh_playlist_ui(self):
        if not hasattr(self, "playlist_box") or not self.playlist_box:
            return
        if getattr(self, "_closing", False):
            return
        try:
            for w in self.playlist_box.winfo_children():
                try:
                    w.destroy()
                except Exception:
                    pass
        except Exception:
            return
        if not self.video or not self.video.playlist:
            ctk.CTkLabel(self.playlist_box, text="Pusto.\nDodaj zdjęcia lub nagrania.",
                         text_color=MUTED, justify="center").pack(padx=6, pady=14)
            return
        for i, item in enumerate(self.video.playlist):
            name = os.path.basename(item["path"])
            if len(name) > 30:
                name = name[:27] + "…"
            mark = "▸" if item["type"] == "video" else "•"
            cur = (i == self.video.index)
            sel = (i == self._sel_idx)
            if cur:
                fg, tc, bw = WHITE, "black", 0
            elif sel:
                fg, tc, bw = "transparent", TEXT, 1
            else:
                fg, tc, bw = "transparent", MUTED, 0
            b = ctk.CTkButton(self.playlist_box, text="%s  %s" % (mark, name),
                              anchor="w", fg_color=fg, text_color=tc, hover_color=CARD2,
                              border_width=bw, border_color=LINE,
                              corner_radius=9, height=32, font=ctk.CTkFont(size=12),
                              command=lambda i=i: self._select_slide(i))
            b.pack(fill="x", padx=4, pady=2)

    def _select_slide(self, i):
        self._sel_idx = i
        self._face3d_active = False
        if getattr(self, "sw_face3d", None):
            self.sw_face3d.deselect()
        if getattr(self, "var_face3d_enabled", None):
            self.var_face3d_enabled.set(False)
        if hasattr(self, "lbl_face3d_status"):
            self.lbl_face3d_status.configure(
                text="WYŁĄCZONY (Odtwarzacz biblioteki aktywny)",
                text_color=MUTED
            )
        if self.video:
            self.video.set_custom_frame(None)
            try:
                self.video.goto(i)
            except Exception as e:
                self._log("Biblioteka: %s" % e)
        # Odśwież listę dopiero po zakończeniu obsługi kliknięcia — przebudowa
        # niszczy przycisk, którego callback właśnie trwa (błędy Tk „invalid command name”).
        try:
            self.after_idle(self._refresh_playlist_ui)
        except Exception:
            self._refresh_playlist_ui()

    def _on_slide_change(self, idx):
        self._sel_idx = idx
        try:
            self.after(0, self._refresh_playlist_ui)
        except Exception:
            pass

    def _add_files(self):
        exts = [("Media", "*.jpg *.jpeg *.png *.webp *.bmp *.mp4 *.avi *.mkv *.mov *.webm *.m4v *.3gp"),
                ("Wszystkie", "*.*")]
        paths = filedialog.askopenfilenames(title="Wybierz zdjęcia / nagrania", filetypes=exts)
        if paths and self.video:
            self._face3d_active = False
            if getattr(self, "sw_face3d", None):
                self.sw_face3d.deselect()
            if getattr(self, "var_face3d_enabled", None):
                self.var_face3d_enabled.set(False)
            if hasattr(self, "lbl_face3d_status"):
                self.lbl_face3d_status.configure(
                    text="WYŁĄCZONY (Odtwarzacz biblioteki aktywny)",
                    text_color=MUTED
                )
            self.video.set_custom_frame(None)
            n = self.video.add_files(list(paths))
            self._log("Dodano %d plików." % n)
            self._refresh_playlist_ui()

    def _add_folder(self):
        folder = filedialog.askdirectory(title="Wybierz folder ze zdjęciami / nagraniami")
        if folder and self.video:
            self._face3d_active = False
            if getattr(self, "sw_face3d", None):
                self.sw_face3d.deselect()
            if getattr(self, "var_face3d_enabled", None):
                self.var_face3d_enabled.set(False)
            if hasattr(self, "lbl_face3d_status"):
                self.lbl_face3d_status.configure(
                    text="WYŁĄCZONY (Odtwarzacz biblioteki aktywny)",
                    text_color=MUTED
                )
            self.video.set_custom_frame(None)
            n = self.video.add_folder(folder)
            self._log("Dodano %d plików z folderu." % n)
            self._refresh_playlist_ui()

    def _remove_selected(self):
        if self.video:
            i = self._sel_idx
            self.video.remove_at(i)
            self._sel_idx = max(0, min(i, len(self.video.playlist) - 1))
            self._refresh_playlist_ui()

    def _clear_playlist(self):
        if self.video:
            self.video.clear()
            self._sel_idx = 0
            self._refresh_playlist_ui()
            self._log("Wyczyszczono listę.")

    def _move_sel(self, delta):
        if self.video:
            self._sel_idx = self.video.move(self._sel_idx, delta)
            self._refresh_playlist_ui()

    def _slide_next(self):
        self._face3d_active = False
        if getattr(self, "sw_face3d", None):
            self.sw_face3d.deselect()
        if getattr(self, "var_face3d_enabled", None):
            self.var_face3d_enabled.set(False)
        if hasattr(self, "lbl_face3d_status"):
            self.lbl_face3d_status.configure(
                text="WYŁĄCZONY (Odtwarzacz biblioteki aktywny)",
                text_color=MUTED
            )
        if self.video:
            self.video.set_custom_frame(None)
            self.video.next(manual=True)
            self._refresh_playlist_ui()

    def _slide_prev(self):
        self._face3d_active = False
        if getattr(self, "sw_face3d", None):
            self.sw_face3d.deselect()
        if getattr(self, "var_face3d_enabled", None):
            self.var_face3d_enabled.set(False)
        if hasattr(self, "lbl_face3d_status"):
            self.lbl_face3d_status.configure(
                text="WYŁĄCZONY (Odtwarzacz biblioteki aktywny)",
                text_color=MUTED
            )
        if self.video:
            self.video.set_custom_frame(None)
            self.video.prev()
            self._refresh_playlist_ui()

    # ------------------------------------------------------- obsługa: obraz
    def _restart_vcam_if_live(self, what):
        if self.video and self.video.vcam_active:
            self.video.stop_virtual()
            ok, msg = self.video.start_virtual()
            self._log(msg if ok else "Uwaga: " + msg)
        else:
            self._log(what)

    def _on_mode_change(self, label):
        if self.video:
            self.video.mode = self._key_of(SLIDESHOW_MODES, label)

    def _on_interval_change(self, val):
        if self.video:
            try:
                self.video.interval = float(val)
            except Exception:
                pass

    def _on_trans_change(self, label):
        if self.video:
            self.video.transition = self._key_of(TRANSITIONS, label)

    def _on_format_change(self, label):
        if not self.video:
            return
        for k, v in PHONE_FORMATS.items():
            if v["label"] == label:
                self.video.format_id = k
                self._restart_vcam_if_live("Format: " + label)
                break

    def _on_backend_change(self, label):
        if not self.video:
            return
        for k, v in BACKEND_LABELS.items():
            if v == label:
                self.video.vcam_backend = k
                self._restart_vcam_if_live("Silnik kamery: " + label)
                break

    def _on_fps_change(self, val):
        if not self.video:
            return
        try:
            self.video.fps = int(val)
            self._restart_vcam_if_live("FPS: " + str(val))
        except Exception:
            pass

    def _on_fit_change(self, label):
        if self.video:
            self.video.fit_mode = self._key_of(FIT_MODES, label)

    def _on_filter_change(self, label):
        if self.video:
            self.video.filter_id = self._key_of(FILTERS, label)

    def _rotate(self):
        if self.video:
            self.video.rotate = (self.video.rotate + 90) % 360
            self._log("Obrót: %d°" % self.video.rotate)

    def _on_mirror(self):
        if self.video:
            self.video.mirror = bool(self.var_mirror.get())

    def _on_fx(self):
        if not self.video:
            return
        v = self.video
        v.ov_rec = bool(self.var_rec.get())
        v.ov_timestamp = bool(self.var_ts.get())
        v.ov_brand = bool(self.var_brand.get())
        v.ov_battery = bool(self.var_batt.get())
        v.fx_shake = bool(self.var_shake.get())
        v.fx_grain = bool(self.var_grain.get())
        v.fx_vignette = bool(self.var_vig.get())
        v.fx_autofocus = bool(self.var_af.get())

    def _on_fx_sliders(self):
        if not self.video:
            return
        try:
            self.video.fx_shake_amount = float(self.sld_shakeamt.get())
            self.video.fx_grain_amount = float(self.sld_grainamt.get())
        except Exception:
            pass

    # --------------------------------------- kadrowanie + orientacja
    def _on_frame_sliders(self):
        if not self.video:
            return
        try:
            self.video.set_frame(zoom=self.sld_zoom.get(),
                                 pan_x=self.sld_panx.get(),
                                 pan_y=self.sld_pany.get())
        except Exception:
            pass

    def _sync_frame_ui(self):
        try:
            if not self.video:
                return
            self.sld_zoom.set(self.video.zoom)
            self.sld_panx.set(self.video.pan_x)
            self.sld_pany.set(self.video.pan_y)
            self.val_zoom.configure(text="%.2f×" % self.video.zoom)
            self.val_panx.configure(text="%+.2f" % self.video.pan_x)
            self.val_pany.configure(text="%+.2f" % self.video.pan_y)
        except Exception:
            pass

    def _frame_drag_start(self, e):
        self._drag_last = (e.x, e.y)

    def _frame_drag_move(self, e):
        if self._drag_last is None:
            return
        # Jeśli aktywny jest Generator Twarzy 3D: bezpośredni obrót modelu 3D myszą
        if getattr(self, "var_face3d_enabled", None) and self.var_face3d_enabled.get() and getattr(self, "face_animator", None):
            try:
                dx = (e.x - self._drag_last[0]) * 0.010
                dy = (e.y - self._drag_last[1]) * 0.010
                self._drag_last = (e.x, e.y)
                self.face_animator.rotate_by_delta(dx, dy)
                self._face3d_push_frame()
                return
            except Exception:
                pass

        if not self.video:
            return
        try:
            dx = (e.x - self._drag_last[0]) / 160.0
            dy = (e.y - self._drag_last[1]) / 160.0
            self._drag_last = (e.x, e.y)
            v = self.video
            v.set_frame(pan_x=v.pan_x + dx, pan_y=v.pan_y + dy)
            self._sync_frame_ui()
        except Exception:
            pass

    def _frame_drag_right_move(self, e):
        if self._drag_last is None:
            return
        if getattr(self, "var_face3d_enabled", None) and self.var_face3d_enabled.get() and getattr(self, "face_animator", None):
            try:
                dx = (e.x - self._drag_last[0]) * 0.012
                self._drag_last = (e.x, e.y)
                self.face_animator.roll_by_delta(dx)
                self._face3d_push_frame()
            except Exception:
                pass

    def _frame_wheel(self, e):
        # Jeśli aktywny jest Generator Twarzy 3D: przybliżanie/oddalanie modelu kółkiem myszy
        if getattr(self, "var_face3d_enabled", None) and self.var_face3d_enabled.get() and getattr(self, "face_animator", None):
            try:
                factor = 1.08 if (getattr(e, "delta", 0) > 0) else (1.0 / 1.08)
                self.face_animator.zoom_by_delta(factor)
                self._face3d_push_frame()
                return
            except Exception:
                pass

        try:
            steps = (e.delta / 120) if getattr(e, "delta", 0) else 0
            if steps:
                self._frame_zoom_step(1.12 ** steps)
        except Exception:
            pass

    def _frame_zoom_step(self, f):
        if self.video:
            self.video.set_frame(zoom=self.video.zoom * f)
            self._sync_frame_ui()

    def _frame_preset(self, x, y):
        if not self.video:
            return
        z = self.video.zoom
        if (x or y) and z < 1.15:
            z = 1.3
        self.video.set_frame(zoom=z, pan_x=x, pan_y=y)
        self._sync_frame_ui()

    def _frame_reset(self):
        if self.video:
            self.video.reset_frame()
            self._sync_frame_ui()
            self._log("Zresetowano kadr.")

    def _toggle_orientation(self):
        if not self.video:
            return
        new = "landscape" if self.video.orientation == "portrait" else "portrait"
        self.video.set_orientation(new)
        self._restart_vcam_if_live("")
        self._update_orient_btn()
        self._log("Telefon poziomo (panorama)." if new == "landscape" else "Telefon pionowo.")

    def _on_orient_seg(self, val):
        if not self.video:
            return
        want = "landscape" if val == "Poziomo" else "portrait"
        if self.video.orientation != want:
            self._toggle_orientation()
        else:
            self._update_orient_btn()

    def _update_orient_btn(self):
        try:
            land = self.video and self.video.orientation == "landscape"
            self.var_orient.set("Poziomo" if land else "Pionowo")
        except Exception:
            pass

    # ----------------------------------------------------- obsługa: dźwięk
    def _on_profile(self):
        if self.audio:
            self.audio.set_profile(self.var_profile.get())
            self._update_profile_desc()
            self._log("Sceneria: " + self.var_profile.get())

    def _update_profile_desc(self):
        try:
            p = AUDIO_PROFILES.get(self.var_profile.get(), {})
            self.lbl_prof_desc.configure(text=p.get("desc", ""))
        except Exception:
            pass

    def _on_audio_sliders(self):
        if not self.audio:
            return
        try:
            self.audio.set_volume(self.sld_volume.get())
            self.audio.set_noise_level(self.sld_noise.get())
            self.audio.set_event_rate(self.sld_event.get())
            self.audio.set_bass(self.sld_bass.get())
        except Exception:
            pass

    def _on_breath_toggle(self):
        if self.audio:
            self.audio.set_breath(self.var_breath.get())
            self._log("Oddech włączony." if self.var_breath.get() else "Oddech wyciszony.")

    def _on_breath_level(self):
        if self.audio:
            try:
                self.audio.set_breath_level(self.sld_breath.get())
            except Exception:
                pass

    def _on_breath_rate(self):
        if self.audio:
            try:
                self.audio.set_breath_rate(self.sld_brate.get())
            except Exception:
                pass

    def _on_mute(self):
        if self.audio:
            self.audio.set_muted(self.var_mute.get())
            self._log("Mikrofon wyciszony." if self.var_mute.get() else "Mikrofon aktywny.")
            self._update_leds()

    @staticmethod
    def _is_virtual_audio(name):
        n = (name or "").lower()
        return any(k in n for k in ("cable", "vb-audio", "voicemeeter", "virtual", "realme"))

    def _refresh_devices_combo(self):
        names = ["(domyślne)"]
        self._dev_map = {"(domyślne)": None}
        cable_label = None
        try:
            if self.audio and not self.audio.demo_mode:
                cable_only = bool(self.var_cable_only.get())
                for idx, name in self.audio.list_output_devices():
                    if cable_only and not self._is_virtual_audio(name):
                        continue
                    label = "[%d] %s" % (idx, name[:48])
                    names.append(label)
                    self._dev_map[label] = idx
                cidx, _ = self.audio.find_cable_device()
                if cidx is not None:
                    for label, di in self._dev_map.items():
                        if di == cidx:
                            cable_label = label
                            break
        except Exception:
            pass
        # przywróć zapamiętane urządzenie, inaczej CABLE
        saved = CFG["audio"].get("output_device_name", "")
        picked = None
        if saved:
            for label in names:
                if saved.lower() in label.lower():
                    picked = label
                    break
        if picked is None and cable_label is not None:
            picked = cable_label
        try:
            self.opt_outdev.configure(values=names)
            if picked is not None:
                self.var_outdev.set(picked)
            self._update_outdev_label()
            self._update_audio_warn()
        except Exception:
            pass

    def _update_outdev_label(self):
        try:
            if self.audio is None or self.audio.demo_mode:
                self.lbl_outdev.configure(text="Tryb demo — brak modułu audio. Uruchom INSTALUJ.bat.")
            elif len(self._dev_map) <= 1:
                self.lbl_outdev.configure(text="Brak urządzeń. Zainstaluj VB-CABLE i zrestartuj PC.")
            else:
                self.lbl_outdev.configure(text="Wybrane: " + self.var_outdev.get())
        except Exception:
            pass

    def _update_audio_warn(self):
        try:
            if self.audio is None or self.audio.demo_mode:
                self.lbl_audio_warn.configure(
                    text="TRYB DEMO — dźwięk nie jest wysyłany.\nUruchom INSTALUJ.bat, aby włączyć audio.")
            elif len(self._dev_map) <= 1:
                self.lbl_audio_warn.configure(
                    text="Nie wykryto urządzeń audio.\nZainstaluj VB-CABLE i zrestartuj komputer.")
            else:
                self.lbl_audio_warn.configure(text="")
        except Exception:
            pass

    def _on_outdev_change(self):
        try:
            CFG["audio"]["output_device_name"] = self.var_outdev.get()
        except Exception:
            pass
        self._update_outdev_label()
        if not self._is_virtual_audio(self.var_outdev.get()):
            self._log("Uwaga: to nie jest wirtualny kabel — dźwięk pójdzie na głośniki.")
        if self.audio and self._want_engine():
            self._sync_engine(force=True)
            self._log("Wyjście dźwięku: " + self.var_outdev.get())

    def _test_sound(self):
        if not self.audio:
            return
        if self.audio.demo_mode:
            self._log("Test niemożliwy — tryb demo (brak sounddevice). Uruchom INSTALUJ.bat.")
            return
        if self.audio.is_running():
            self._log("Dźwięk już gra.")
            return
        if not self._is_virtual_audio(self.var_outdev.get()):
            self._log("Test na głośnikach — usłyszysz szum. Wybierz CABLE Input, aby grać cicho.")
        dev = self._dev_map.get(self.var_outdev.get())
        self.audio.start(output_device=dev)
        self._update_leds()
        self._log("Test dźwięku (6 s): " + self.var_outdev.get())

        def _stop():
            time.sleep(6)
            if not self.broadcasting and not self._closing:
                try:
                    self.audio.stop()
                    self.after(0, self._update_leds)
                except Exception:
                    pass
        threading.Thread(target=_stop, daemon=True).start()

    # ---------------------------------------------------------- nadawanie
    def _toggle_broadcast(self):
        if self.broadcasting:
            self._stop_broadcast()
        else:
            self._start_broadcast()

    def _start_broadcast(self):
        if (self.audio and not self.audio.demo_mode
                and not self._is_virtual_audio(self.var_outdev.get())):
            if not messagebox.askyesno(
                    "Uwaga — dźwięk na głośnikach",
                    "Wybrane urządzenie (%s) nie wygląda na wirtualny kabel.\n\n"
                    "Szum będzie słyszalny z głośników i może wracać do mikrofonu.\n\n"
                    "Kontynuować mimo to?" % self.var_outdev.get()):
                self._log("Anulowano. Wybierz CABLE Input w zakładce Dźwięk.")
                return
        if self.video:
            ok, msg = self.video.start_virtual()
            self._log(msg if ok else "Uwaga: " + msg)
        if self.audio:
            self._sync_engine(force=True)
            if self.audio.demo_mode:
                self._log("Mikrofon: TRYB DEMO (dźwięk nie wychodzi). Uruchom INSTALUJ.bat.")
            else:
                self._log("Mikrofon nadaje: " + self.var_outdev.get())
                if self.audio.last_error:
                    self._log(self.audio.last_error)
        self.broadcasting = True
        self._log(f"Nadawanie. W komunikatorze wybierz kamerę '{self.camera_name}' i mikrofon '{self.camera_name}'.")
        try:
            self.btn_broadcast.configure(text="⏹   Stop nadawania", fg_color="transparent",
                                         text_color=WHITE, border_width=1, border_color=LINE,
                                         hover_color=CARD2)
        except Exception:
            pass
        self._update_leds()
        self._write_runtime_status()

    def _stop_broadcast(self):
        self.broadcasting = False
        try:
            if self.video:
                self.video.stop_virtual()
            self._sync_engine()
        except Exception:
            pass
        self._log("Zatrzymano. Podgląd działa dalej." + (
            " Muzyka gra dalej." if self._want_engine() else ""))
        try:
            self.btn_broadcast.configure(text="▶   Start nadawania", fg_color=WHITE,
                                         text_color="black", border_width=0,
                                         hover_color=WHITE_HOVER)
        except Exception:
            pass
        self._update_leds()
        self._write_runtime_status()

    def _update_leds(self):
        try:
            if self.video and self.video.vcam_active:
                self.dot_cam.configure(text_color=WHITE)
                self.led_cam.configure(text="Kamera  •  nadaje")
            else:
                self.dot_cam.configure(text_color=DIM)
                self.led_cam.configure(text="Kamera  •  podgląd")
            if self.audio and self.audio.is_running() and not self.var_mute.get():
                self.dot_mic.configure(text_color=WHITE)
                self.led_mic.configure(text="Mikrofon  •  nadaje")
            elif self.audio and self.audio.is_running():
                self.dot_mic.configure(text_color=MUTED)
                self.led_mic.configure(text="Mikrofon  •  wyciszony")
            else:
                self.dot_mic.configure(text_color=DIM)
                self.led_mic.configure(text="Mikrofon  •  wyłączony")
            if self.video and self.video.vcam_active and self.video.vcam_device:
                self.lbl_camstatus.configure(text="Silnik: " + self.video.vcam_device)
            elif self.video and self.video.vcam_active:
                self.lbl_camstatus.configure(text="Silnik: aktywny")
            else:
                self.lbl_camstatus.configure(text="")
        except Exception:
            pass

    # ------------------------------------------------------------- tickery
    def _tick_preview(self):
        try:
            if self.video and HAS_PIL:
                frame = self.video.get_preview()
                if frame is not None:
                    try:
                        pw = max(120, self.lbl_preview.winfo_width() - 4)
                        ph = max(160, self.lbl_preview.winfo_height() - 4)
                    except Exception:
                        pw, ph = 280, 560
                    fh, fw = frame.shape[:2]
                    s = min(pw / fw, ph / fh)
                    dw, dh = max(1, int(fw * s)), max(1, int(fh * s))
                    img = Image.fromarray(frame).resize((dw, dh), Image.BILINEAR)
                    ctk_img = ctk.CTkImage(light_image=img, dark_image=img, size=(dw, dh))
                    self.lbl_preview.configure(image=ctk_img, text="")
                    self.lbl_preview.image = ctk_img
                try:
                    self.lbl_fps.configure(text="%.0f fps" % self.video.actual_fps)
                    if getattr(self, "_face3d_active", False) and getattr(self, "face_animator", None):
                        self.lbl_slide.configure(
                            text=f"🎭 Model 3D: {self.face_animator.active_model_name}"
                        )
                    else:
                        cur = self.video.current()
                        if cur:
                            self.lbl_slide.configure(
                                text="%d/%d  •  %s" % (self.video.index + 1, len(self.video.playlist),
                                                      os.path.basename(cur["path"])[:26]))
                        else:
                            self.lbl_slide.configure(text="brak mediów")
                    if getattr(self.video, "_frame_changed", False):
                        self.video._frame_changed = False
                        self._sync_frame_ui()
                except Exception:
                    pass
            self._v14_tick()
        except Exception:
            pass
        if not self._closing:
            self.after(40, self._tick_preview)

    def _tick_meters(self):
        try:
            if self.audio:
                lvl = self.audio.get_level()
                if self.var_mute.get():
                    lvl = 0.0
                self.vu_bar.set(max(0.0, min(1.0, lvl)))
                if hasattr(self, "lbl_microphone_metric") and self.audio.input_device is not None:
                    bars = "▁▂▃▄▅▆▇█"
                    peak = max(1, min(8, int(lvl * 16)))
                    self.lbl_microphone_metric.configure(text=(bars[:peak] + " " + ("sygnał %.0f%%" % (lvl * 100))), text_color="#C69CFF")
            if hasattr(self, "lbl_camera_metric") and self.video and self.video.live_camera_working():
                self.lbl_camera_metric.configure(text="▁▂▃▅▇▆▃▅  %.0f fps" % self.video.actual_fps, text_color="#68D7FF")
            self._update_leds()
            self._v13_tick()
        except Exception:
            pass
        if not self._closing:
            self.after(120, self._tick_meters)

    # ---------------------------------------------------- okno: urządzenia
    def _open_devices_window(self):
        win = ctk.CTkToplevel(self)
        win.title("Urządzenia wirtualne — vStudio")
        win.geometry("680x720")
        win.configure(fg_color=BG)
        win.grab_set()

        ctk.CTkLabel(win, text="Urządzenia wirtualne", font=ctk.CTkFont(size=18, weight="bold"),
                     text_color=TEXT).pack(anchor="w", padx=16, pady=(14, 2))
        ctk.CTkLabel(win, text="Wybór i zmiana nazwy kamery wirtualnej (DirectShow / OBS / Unity) oraz mikrofonu",
                     text_color=MUTED, font=ctk.CTkFont(size=12)).pack(anchor="w", padx=16, pady=(0, 8))

        # ===== SEKCJA: WYBÓR I ZMIANA NAZWY KAMERY WIRTUALNEJ =====
        cam_card = ctk.CTkFrame(win, fg_color=CARD, corner_radius=12, border_width=1, border_color=LINE)
        cam_card.pack(fill="x", padx=14, pady=6)

        ctk.CTkLabel(cam_card, text="📷  Wybór i zmiana nazwy kamery wirtualnej",
                     font=ctk.CTkFont(size=14, weight="bold"), text_color=TEXT).pack(anchor="w", padx=14, pady=(10, 4))
        ctk.CTkLabel(cam_card, text="Wybierz gotową nazwę z listy lub wpisz własną (np. vStudio, Moja Kamera HD). "
                                   "Zastosuj w aplikacji lub zmień w rejestrze systemu (dla Zoom, Teams, Discord).",
                     font=ctk.CTkFont(size=11), text_color=MUTED, wraplength=630, justify="left").pack(anchor="w", padx=14, pady=(0, 8))

        row_sel = ctk.CTkFrame(cam_card, fg_color="transparent")
        row_sel.pack(fill="x", padx=14, pady=4)
        ctk.CTkLabel(row_sel, text="Wybierz z listy:", width=130, anchor="w",
                     font=ctk.CTkFont(size=12)).pack(side="left")
        
        selectable = VD.get_selectable_camera_names() if HAS_VD else ["vStudio", "OBS Virtual Camera"]
        combo_cam = ctk.CTkComboBox(row_sel, values=selectable, width=280, fg_color=CARD2, border_color=LINE)
        combo_cam.set(self.camera_name)
        combo_cam.pack(side="left", padx=6)

        row_edit = ctk.CTkFrame(cam_card, fg_color="transparent")
        row_edit.pack(fill="x", padx=14, pady=4)
        ctk.CTkLabel(row_edit, text="Wpisz / edytuj nazwę:", width=130, anchor="w",
                     font=ctk.CTkFont(size=12)).pack(side="left")
        ent_cam = ctk.CTkEntry(row_edit, width=280, fg_color=CARD2, border_color=LINE, text_color=TEXT)
        ent_cam.insert(0, self.camera_name)
        ent_cam.pack(side="left", padx=6)

        def on_combo_select(choice):
            ent_cam.delete(0, "end")
            ent_cam.insert(0, choice)
        combo_cam.configure(command=on_combo_select)

        lbl_status = ctk.CTkLabel(cam_card, text="", font=ctk.CTkFont(size=11), text_color=MUTED)
        lbl_status.pack(anchor="w", padx=14, pady=(4, 6))

        def update_status_label():
            curr_reg = VD.get_obs_virtualcam_name() if HAS_VD else ""
            txt = f"W aplikacji: «{self.camera_name}»"
            if curr_reg:
                txt += f"  •  W rejestrze Windows: «{curr_reg}»"
                if curr_reg.strip().lower() == self.camera_name.strip().lower():
                    txt += "  [✓ Zgodna]"
                else:
                    txt += "  [Różni się — kliknij 'Zmień w systemie']"
            lbl_status.configure(text=txt)

        def apply_name_app():
            new_name = ent_cam.get().strip()
            if not new_name:
                return
            self._set_active_camera_name(new_name)
            update_status_label()
            refresh_devices_status()
            self._log(f"Zaktualizowano nazwę kamery w aplikacji: {new_name}")

        def apply_name_system():
            new_name = ent_cam.get().strip()
            if not new_name:
                return
            self._set_active_camera_name(new_name)
            update_status_label()
            self._run_rename_script(custom_name=new_name)
            refresh_devices_status()

        row_btns = ctk.CTkFrame(cam_card, fg_color="transparent")
        row_btns.pack(fill="x", padx=14, pady=(4, 10))
        ctk.CTkButton(row_btns, text="💾  Ustaw w vStudio", width=160,
                      command=apply_name_app, **GHOST).pack(side="left", padx=(0, 6))
        ctk.CTkButton(row_btns, text="⚡  Zmień nazwę w systemie (Admin)", width=240,
                      command=apply_name_system, **PRIMARY).pack(side="left", padx=4)

        # ===== LISTA STATUSU URZĄDZEŃ =====
        box = ctk.CTkScrollableFrame(win, height=220, fg_color=CARD, corner_radius=12)
        box.pack(fill="both", expand=True, padx=14, pady=8)

        def refresh_devices_status():
            for w in box.winfo_children():
                w.destroy()
            rows = VD.devices_status_report(target_camera_name=self.camera_name) if HAS_VD else [("moduł", False, "brak virtual_devices.py")]
            for name, ok, desc in rows:
                mark = "●" if ok else "○"
                ctk.CTkLabel(box, text="%s  %s\n      %s" % (mark, name, desc),
                             font=ctk.CTkFont(size=12), justify="left",
                             text_color=TEXT if ok else MUTED).pack(anchor="w", padx=8, pady=4)
            update_status_label()
        refresh_devices_status()

        act_bar = ctk.CTkFrame(win, fg_color="transparent")
        act_bar.pack(fill="x", padx=14, pady=4)
        ctk.CTkButton(act_bar, text="Odśwież status", width=140, command=refresh_devices_status, **GHOST).pack(side="left", padx=(0, 4))
        ctk.CTkButton(act_bar, text="Diagnozuj kamerę (raport TXT)", width=220,
                      command=self._run_diagnose, **GHOST).pack(side="left", padx=4)

        row = ctk.CTkFrame(win, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=(2, 8))
        ctk.CTkButton(row, text="OBS Studio", width=140,
                      command=lambda: webbrowser.open("https://obsproject.com"),
                      **GHOST).pack(side="left", padx=2)
        ctk.CTkButton(row, text="VB-CABLE", width=140,
                      command=lambda: webbrowser.open("https://vb-audio.com/Cable/"),
                      **GHOST).pack(side="left", padx=2)
        ctk.CTkButton(row, text="Unity Capture", width=140,
                      command=lambda: webbrowser.open("https://github.com/schellingb/UnityCapture"),
                      **GHOST).pack(side="left", padx=2)

    def _set_active_camera_name(self, name: str):
        cleaned = (name or "").strip()
        if not cleaned:
            return
        self.camera_name = cleaned
        self.CFG.setdefault("device_names", {})["camera"] = cleaned
        self.CFG["device_names"]["microphone"] = cleaned
        if HAS_VD:
            VD.set_target_camera_name(cleaned)
        if self.video:
            self.video.camera_name = cleaned
        if hasattr(self, "btn_cam_selector"):
            try:
                self.btn_cam_selector.configure(text=f"📷 {cleaned}")
            except Exception:
                pass
        if getattr(self, "var_autosave", None) and self.var_autosave.get():
            try:
                self._save_settings_now()
            except Exception:
                pass

    def _run_rename_script(self, custom_name=None):
        if not HAS_VD:
            return
        target = (custom_name or self.camera_name or "vStudio").strip()
        self._set_active_camera_name(target)
        ps1 = os.path.join(APP_DIR, "scripts", "rename_devices.ps1")
        ok, msg = VD.run_powershell_script(ps1, new_name=target)
        self._log(msg)
        if ok:
            messagebox.showinfo("vStudio",
                                f"Otwarto konfigurator (okno administratora) dla nazwy: «{target}».\n\n"
                                "1) Potwierdź uprawnienia (Tak).\n"
                                "2) Zamknij OBS, jeśli jest otwarty.\n"
                                "3) Poczekaj na zielone komunikaty i WERYFIKACJĘ.\n"
                                "4) ZAMKNIJ i otwórz komunikator.")

    def _run_diagnose(self):
        if not HAS_VD:
            return
        ps1 = os.path.join(APP_DIR, "scripts", "diagnose_camera.ps1")
        ok, msg = VD.run_diagnose_script(ps1, target_name=self.camera_name)
        self._log(msg)
        if ok:
            self._log("Sprawdź DIAGNOZA_KAMERY.txt — sekcja [4] pokazuje, co widzą programy.")

    # -------------------------------------------------------- okno: pomoc
    def _open_help_window(self):
        win = ctk.CTkToplevel(self)
        win.title("Pomoc — vStudio")
        win.geometry("680x640")
        win.configure(fg_color=BG)
        txt = ctk.CTkTextbox(win, font=ctk.CTkFont(size=12), fg_color=CARD, text_color=TEXT,
                             corner_radius=12, border_width=1, border_color=LINE)
        txt.pack(fill="both", expand=True, padx=14, pady=14)
        help_text = (
            "vStudio — INSTRUKCJA\n"
            "══════════════════════════════\n\n"
            "CO TO ROBI?\n"
            "Projektuje zdjęcia i nagrania jako obraz z telefonu / wirtualnej kamery\n"
            "do Zoom / Teams / Discord / Meet i generuje losowe\n"
            "szumy mikrofonu telefonu. Wszystko offline.\n\n"
            "INSTALACJA (raz):\n"
            "1. INSTALUJ.bat -> opcja 1 robi WSZYSTKO sama\n"
            "   (Python, OBS, VB-CABLE, nazwy, skrot na pulpicie),\n"
            "   zwykle BEZ restartu komputera.\n"
            "2. OBS Studio (obsproject.com) → uruchom raz → Start Virtual Camera\n"
            "   (alternatywa: Unity Capture — bez OBS)\n"
            "3. VB-CABLE (vb-audio.com/Cable) → restart komputera\n"
            "4. USTAW_URZADZENIA.bat jako Administrator\n\n"
            "UŻYCIE:\n"
            "1. START_VSTUDIO.bat (lub START_SUITE.bat)\n"
            "2. Dodaj media (lewa kolumna lub folder media/)\n"
            "3. Prawa kolumna — zakładki:\n"
            "   Dźwięk — sceneria, poziomy, oddech, wybór urządzenia\n"
            "   Audio — oś czasu muzyki, pauza/wznowienie, odsłuch,\n"
            "           nagrywanie WAV, pauza mikrofonu\n"
            "   AI Wideo — prompt po polsku → AI robi film ze zdjęć\n"
            "           (offline, z lokalną nauką stylu), render i podgląd\n"
            "   Obraz — kadrowanie, filtr, pokaz, nakładki\n"
            "   Kadr — zoom i pozycja (lub myszka na podglądzie)\n"
            "   Efekty — drganie, ziarno, winieta, autofocus\n"
            "4. Pod podglądem: format, pion/poziom, silnik, FPS\n"
            "   i pasek odtwarzacza: ▶/❚❚, ■ stop, suwak czasu,\n"
            "   −5 s/+5 s, „Zapętl nagranie” + „Płynny szew”\n"
            "5. Start nadawania → w komunikatorze wybierz\n"
            f"   kamerę i mikrofon '{self.camera_name}'\n\n"
            "WYBÓR I ZMIANA NAZWY KAMERY:\n"
            "• Kliknij przycisk '📷 [Nazwa]' w górnym pasku lub wejdź w 'Urządzenia'.\n"
            "• Możesz wybrać gotową nazwę lub wpisać dowolną własną.\n"
            "• 'Ustaw w vStudio' zapisuje w aplikacji; 'Zmień nazwę w systemie (Admin)'\n"
            "  zmienia nazwę w rejestrze Windows (dla programów zewnętrznych).\n\n"
            "ODTWARZACZ NAGRANIA (pasek pod podglądem):\n"
            "• Pasek pojawia się WYŁĄCZNIE przy nagraniach (mp4/avi/\n"
            "  mkv/mov). Przy zdjęciu nie ma go wcale — pokaz slajdów\n"
            "  nie potrzebuje transportu.\n"
            "• ⏮ / ▶❚❚ / ⏹ / ⏭ — start, pauza i stop bieżącego MP4.\n"
            "  Pauza nie gasi kamery — rozmówca widzi zamrożony obraz.\n"
            "• Suwak czasu = skok w dowolne miejsce (00:04 / 00:10),\n"
            "  dodatkowo −5 s / +5 s.\n"
            "• „Zapętl nagranie” + „Płynny szew” (0–1,2 s): ostatnie\n"
            "  klatki rozpływają się w pierwsze → powtórka bez trzasku.\n"
            "  Wyłączona pętla = stop na ostatniej klatce / następny plik.\n\n"
            "PRYWATNOŚĆ I KLUCZE API (zakładka „Prywatność”) — OPCJA:\n"
            "Domyślnie apka nie ma sieci. Klucz wklejasz, jeśli chcesz:\n"
            "  • mowę z chmury (/audio/speech) — jak nie wyjdzie, wracasz\n"
            "    na silnik lokalny i dowiadujesz się o tym w logu;\n"
            "  • konsultacji planu AI Wideo — „🌐 Zapytaj AI o plan” w\n"
            "    zakładce AI Wideo; model zwraca wyłącznie liczby z listy\n"
            "    pól planu, każda przycinana do zakresu.\n"
            "Trzy osobne zgody: treść tekstu · treść promptu · miniatury\n"
            "zdjęć. Bez kliknięcia zgody nie zostaje wysłany ŻADEN bajt.\n"
            "Klucz mieszka w config.json (plik tekstowy), nigdy w presetach\n"
            "ani w dzienniku. „ⓘ” przy sekcjach opisuje to ludzkimi słowami;\n"
            "„Wyczyść klucze” i reset fabryczny kasują klucz na dobre.\n"
            "Przez czysty http:// klucz poleciałby jawnie — dlatego apka\n"
            "zgadza się na to tylko dla localhost, reszta wymaga https.\n\n"
            "MOWA (TTS) — zakładka „Mowa (TTS)”:\n"
            "Wpisz tekst → wybierz głos (z listy systemowych), tempo i\n"
            "głośność → „Mów do mikrofonu”. Mowa idzie tym samym kablem\n"
            "co szum, więc rozmówca słyszy jedno i drugie (i nagranie WAV).\n"
            "Offline: System.Speech (Windows) / espeak-ng / pyttsx3.\n"
            "Brak głosów? Windows: Ustawienia → Czas i język → Mowa.\n\n"
            "USTAWIENIA (⚙ w górnym pasku):\n"
            "Zapisz/cały stan do pliku JSON, wczytaj bez restartu,\n"
            "presety w folderze presets/, auto-zapis przy zamknięciu\n"
            "(można wyłączyć), Ctrl+S = zapis teraz, „fabryczne” = defaulty.\n\n"
            "MIKROFON NIE DZIAŁA?\n"
            "• Zakładka Dźwięk → Urządzenie wyjściowe → wybierz\n"
            "  CABLE Input. Brak listy = brak VB-CABLE lub restartu PC.\n"
            "• Tryb demo = brak sounddevice → uruchom INSTALUJ.bat.\n"
            f"• W komunikatorze wybierz CABLE Output / {self.camera_name}.\n\n"
            "STARA NAZWA KAMERY?\n"
            "Zamknij komunikator CAŁKOWICIE i otwórz ponownie.\n"
            "Potem: USTAW_URZADZENIA.bat → DIAGNOZUJ_KAMERE.bat.\n"
            "Skrypt ustawia nazwę na OBS i Unity jednocześnie.\n\n"
            "ODDECH: włącznik + głębokość + tempo (/min).\n"
            "Odznaczony = oddech wyciszony.\n\n"
            "OŚ CZASU AUDIO (zakładka Audio):\n"
            "Dodaj audio → ▶ odtwarzaj, ❚❚ pauza (pamięta miejsce),\n"
            "■ stop, klik na osi = skok, Pętla, głośność klipu.\n"
            "Muzyka leci RAZEM z szumem mikrofonu.\n"
            "ODSŁUCH = słyszysz u siebie (nie zmienia kabla).\n"
            "NAGRYWANIE = zapis tego, co idzie na wirtualny mikrofon.\n\n"
            "AI WIDEO (zakładka AI Wideo) — darmowe, w 100% offline:\n"
            "1. Dodaj zdjęcia (albo użyj playlisty).\n"
            "2. Napisz prompt, np. \"kinowy film 30 sekund, wolne\n"
            "   najazdy, sepia, cięcia w rytm muzyki\" — albo kliknij\n"
            "   \"Zaproponuj\" / wybierz styl z biblioteki.\n"
            "3. Akceptuj prompt → zobaczysz plan (liczby).\n"
            "4. Renderuj film → plik w folderze output/ → \n"
            "   \"Dodaj do playlisty\", żeby puścić go przez kamerę.\n"
            "AI uczy się lokalnie (ai_learning.json) — bez internetu.\n\n"
            "SKRÓTY: ← → przełączanie slajdów,\n"
            "        SPACJA = pauza/wznowienie muzyki,\n"
            "        CTRL+SPACJA = start/pauza nagrania,\n"
            "        CTRL+→ / CTRL+← = +5 s / −5 s w nagraniu,\n"
            "        CTRL+L = pętla nagrania,  CTRL+S = zapisz ustawienia,\n"
            "        CTRL+R = nagrywanie, CTRL+M = odsłuch.\n"
        )
        txt.insert("1.0", help_text)
        txt.configure(state="disabled")

    # -------------------------------------------------------------- zamykanie
    def _on_close(self):
        self._closing = True
        try:
            if self.video:
                CFG["video"].update({
                    "format_id": self.video.format_id, "fit_mode": self.video.fit_mode,
                    "filter": self.video.filter_id, "fps": self.video.fps,
                    "backend": self.video.vcam_backend,
                    "slideshow_mode": self.video.mode, "slideshow_interval": self.video.interval,
                    "transition": self.video.transition, "effect_shake": self.video.fx_shake,
                    "effect_shake_amount": self.video.fx_shake_amount,
                    "effect_grain": self.video.fx_grain,
                    "effect_grain_amount": self.video.fx_grain_amount,
                    "effect_vignette": self.video.fx_vignette,
                    "effect_autofocus": self.video.fx_autofocus, "overlay_rec": self.video.ov_rec,
                    "overlay_timestamp": self.video.ov_timestamp, "overlay_brand": self.video.ov_brand,
                    "overlay_battery": self.video.ov_battery, "mirror": self.video.mirror,
                    "rotate": self.video.rotate,
                    "input_rotation": self.video.input_rotation,
                    "input_mirror": self.video.input_mirror,
                    "zoom": self.video.zoom, "pan_x": self.video.pan_x,
                    "pan_y": self.video.pan_y, "orientation": self.video.orientation,
                    "frames": {k: list(v) for k, v in self.video.frame_memory.items()},
                })
            if self.audio:
                CFG["audio"].update({
                    "profile": self.var_profile.get(), "volume": float(self.sld_volume.get()),
                    "noise_level": float(self.sld_noise.get()), "event_rate": float(self.sld_event.get()),
                    "bass": float(self.sld_bass.get()),
                    "breath_on": bool(self.var_breath.get()),
                    "breath_level": float(self.sld_breath.get()),
                    "breath_rate": int(float(self.sld_brate.get())),
                    "output_device_name": self.var_outdev.get(),
                    "cable_only": bool(self.var_cable_only.get()),
                })
            self._v13_on_close()
            self._v14_on_close()
            if CFG.get("ui", {}).get("autosave", True):
                save_config(CFG)
        except Exception:
            pass
        try:
            self._v13_shutdown()
            if self.audio:
                self.audio.stop()
            if self.video:
                self.video.stop()
        except Exception:
            pass
        try:
            os.remove(self._runtime_status_path())
        except Exception:
            pass
        self.destroy()


RealmeStudioApp = VStudioApp


def _boost_priority():
    try:
        if sys.platform.startswith("win"):
            import ctypes
            ctypes.windll.kernel32.SetPriorityClass(
                ctypes.windll.kernel32.GetCurrentProcess(), 0x8000)
    except Exception:
        pass


def main():
    _boost_priority()
    try:
        app = VStudioApp()
        app.mainloop()
    except Exception:
        traceback.print_exc()
        try:
            input("\nWystąpił błąd (szczegóły powyżej). Naciśnij ENTER, aby zamknąć…")
        except Exception:
            pass


if __name__ == "__main__":
    main()
