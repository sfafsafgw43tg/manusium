# -*- coding: utf-8 -*-
"""
vStudio — silnik projekcji obrazu (jak OBS Virtual Camera).

Przyjmuje ZDJĘCIA (jpg/png/webp/bmp) i NAGRANIA (mp4/avi/mkv/mov/webm),
renderuje je w formatach telefonowych (pion 1080x2412 itd.), dodaje efekty
"żywego telefonu" (delikatne drgania, ziarno, autofocus, nakładka aparatu)
i wysyła klatki do wirtualnej kamery (pyvirtualcam → OBS Virtual Camera
lub Unity Capture).

Działa w 100% OFFLINE.

Wymaga: numpy + opencv (cv2) + Pillow. Podgląd działa zawsze.
pyvirtualcam jest potrzebne tylko do wysyłania do komunikatorów.
"""
import os
import random
import threading
import time
from collections import deque
from datetime import datetime

try:
    import numpy as np
    HAS_NUMPY = True
except Exception:
    HAS_NUMPY = False
    np = None

try:
    import cv2
    HAS_CV2 = True
except Exception:
    HAS_CV2 = False
    cv2 = None

try:
    from PIL import Image
    HAS_PIL = True
except Exception:
    HAS_PIL = False
    Image = None

try:
    import pyvirtualcam
    HAS_VCAM = True
except Exception:
    HAS_VCAM = False
    pyvirtualcam = None

from phone_formats import get_format

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}
VIDEO_EXTS = {".mp4", ".avi", ".mkv", ".mov", ".webm", ".m4v", ".3gp"}


def is_image(path):
    return os.path.splitext(path)[1].lower() in IMAGE_EXTS


def is_video(path):
    return os.path.splitext(path)[1].lower() in VIDEO_EXTS


class VideoEngine:
    def __init__(self):
        self.playlist = []          # [{"path":..., "type":"image"/"video"}]
        self.index = 0
        self.mode = "auto"          # manual/auto/random
        self.interval = 6.0
        self.transition = "fade"

        self.camera_name = "vStudio"
        self.brand_title = "vStudio"
        self.format_id = "realme12pro"
        self.fit_mode = "fill"
        self.filter_id = "normal"
        self.fps = 30
        self.mirror = False
        self.rotate = 0

        # ręczne kadrowanie (ustawianie zdjęcia w kadrze)
        self.zoom = 1.0          # 0.5..3.0 powiększenie kadru
        self.pan_x = 0.0         # -1..1 przesunięcie poziome (treści)
        self.pan_y = 0.0         # -1..1 przesunięcie pionowe (treści)
        self.orientation = "portrait"  # lub "landscape" (telefon na długość)
        self.frame_memory = {}   # path -> (zoom, pan_x, pan_y), każdy slajd pamięta kadr
        self._last_path = None
        self._frame_changed = False  # flaga dla UI: odśwież suwaki kadru

        # efekty "żywego telefonu"
        self.fx_shake = True
        self.fx_shake_amount = 4.0
        self.fx_grain = True
        self.fx_grain_amount = 6.0
        self._custom_frame = None
        self.fx_vignette = True
        self.fx_autofocus = True
        self.ov_rec = True
        self.ov_timestamp = True
        self.ov_brand = True
        self.ov_battery = True

        self._running = False
        self._thread = None
        self._lock = threading.Lock()
        # Jedyny strażnik cv2.VideoCapture. Wątek renderujący czyta klatki, a wątek
        # GUI (przyciski ▶/■, suwak, klik w bibliotece) robi seek/otwiera/zamyka plik.
        # Bez wspólnej blokady FFmpeg dostawał read() i set()/release() naraz →
        # twarde zamknięcie programu (access violation), bez wyjątku Pythona.
        self._cap_lock = threading.RLock()
        self._pending_next = False  # koniec pliku obsłużony pod _cap_lock → next() po zwolnieniu
        self._cap = None            # cv2.VideoCapture dla wideo
        self._cap_path = None
        # Optional physical/virtual host camera. Its frames become the source
        # for vStudio's Unity Capture output and therefore for the emulator.
        self.input_camera_index = None
        self.input_camera_name = ""
        # Transform only the selected live input before it is fitted into the
        # phone frame. Phone-as-webcam drivers commonly expose portrait video
        # sideways; rotating after fitting would crop and stretch that frame.
        self.input_rotation = 0
        self.input_mirror = False
        self._input_camera = None
        self.input_camera_error = ""
        self._input_camera_lock = threading.RLock()
        self._img_cache = {}        # path -> ndarray
        self._last_switch = time.time()
        self._trans_from = None     # klatka początkowa przejścia
        self._trans_t0 = 0.0
        self._af_box_until = 0.0    # autofocus: do kiedy pokazać ramkę
        self._af_box_next = time.time() + 4
        self._af_pos = (0.5, 0.45)
        self._preview_frame = None  # ostatnia klatka RGB do podglądu
        self._cam = None            # pyvirtualcam.Camera
        self._cam_size = (0, 0)
        # Mobile mode can publish a driver-safe size independently from the
        # editor preview. Rotation is explicit; no hidden Android quarter-turn.
        self.virtual_output_size = None
        self.virtual_output_rotation = 0
        self._render_scale = 1.0    # adaptacyjna jakość (spada przy słabym PC)
        self.vcam_active = False
        self.vcam_error = ""
        self.vcam_backend = "auto"   # auto | obs | unitycapture (wybór silnika)
        self.vcam_backend_used = ""
        self.vcam_device = ""
        self.actual_fps = 0.0
        self.on_slide_change = None  # callback(index)

        # --- transport nagrania (play / pause / stop / przewijanie) + petla ---
        self.playing = True          # False = pauza (ostatnia klatka zamrozona)
        self.loop_video = True       # True = zapetlać, False = stanac / nastepny slajd
        self.loop_blend = 0.35       # s — dlugosc plynnego szwu na petli (0 = twarde ciecie)
        self._video_pos = 0          # numer ostatnio wyswietlonej klatki
        self._video_len = 0          # liczba klatek w pliku (0 = nieustalona)
        self._video_fps = 0.0        # fps pliku (nie mylic z fps kamery)
        self._frozen = None          # klatka „na pauzie” (BGR, sprzed efektow)
        self._tail = None            # deque ostatnich klatek → do crossfade'u
        self._tail_want = -1
        self._blend_src = None       # klatki ogona (od najnowszej) w trakcie szwu
        self._blend_i = 0
        self._tail_budget = 64 * 1024 * 1024   # max ~64 MB na ogon (1080p ≈ 10 klatek)

    # ------------------------------------------------------------- playlist
    def add_files(self, paths):
        added = 0
        for p in paths:
            if not os.path.isfile(p):
                continue
            if is_image(p):
                self.playlist.append({"path": p, "type": "image"})
                added += 1
            elif is_video(p):
                self.playlist.append({"path": p, "type": "video"})
                added += 1
        return added

    def add_folder(self, folder):
        if not os.path.isdir(folder):
            return 0
        files = [os.path.join(folder, f) for f in sorted(os.listdir(folder))]
        return self.add_files(files)

    def remove_at(self, idx):
        if 0 <= idx < len(self.playlist):
            item = self.playlist.pop(idx)
            self._img_cache.pop(item["path"], None)
            if self._cap_path == item["path"]:
                self._close_cap()
            if self.index >= len(self.playlist):
                self.index = max(0, len(self.playlist) - 1)

    def clear(self):
        self.playlist = []
        self._img_cache = {}
        self._close_cap()
        self.index = 0

    def move(self, idx, delta):
        j = idx + delta
        if 0 <= idx < len(self.playlist) and 0 <= j < len(self.playlist):
            self.playlist[idx], self.playlist[j] = self.playlist[j], self.playlist[idx]
            return j
        return idx

    def current(self):
        if self.playlist and 0 <= self.index < len(self.playlist):
            return self.playlist[self.index]
        return None

    def next(self, manual=True):
        if not self.playlist:
            return
        with self._lock:
            self._begin_transition()
            if self.mode == "random" or (manual and len(self.playlist) > 1 and random.random() < 0.0):
                self.index = random.randrange(len(self.playlist))
            else:
                self.index = (self.index + 1) % len(self.playlist)
            self._last_switch = time.time()
            self._open_cap_if_needed()
            self.playing = True
        if self.on_slide_change:
            try:
                self.on_slide_change(self.index)
            except Exception:
                pass

    def prev(self):
        if not self.playlist:
            return
        with self._lock:
            self._begin_transition()
            self.index = (self.index - 1) % len(self.playlist)
            self._last_switch = time.time()
            self._open_cap_if_needed()
            self.playing = True
        if self.on_slide_change:
            try:
                self.on_slide_change(self.index)
            except Exception:
                pass

    def goto(self, idx):
        if 0 <= idx < len(self.playlist):
            with self._lock:
                self._begin_transition()
                self.index = idx
                self._last_switch = time.time()
                self._open_cap_if_needed()
                self.playing = True
            if self.on_slide_change:
                try:
                    self.on_slide_change(self.index)
                except Exception:
                    pass

    # ================================== TRANSPORT NAGRANIA (play/pause/stop/seek)
    def is_video_item(self):
        cur = self.current()
        return bool(cur and cur["type"] == "video")

    def set_playing(self, on):
        """Włącz / zatrzymaj odtwarzanie bieżącego nagrania (obraz zostaje w kadrze)."""
        with self._cap_lock:
            self.playing = bool(on)
            if self.playing:
                self._frozen = None   # po wznowieniu czytamy dalej od bieżącej pozycji
            return self.playing

    def toggle_playing(self):
        return self.set_playing(not self.playing)

    def stop_video(self):
        """■ Stop: pauza + powrót do pierwszej klatki."""
        with self._cap_lock:
            self.playing = False
            self.seek(frames=0)      # seek zeruje _frozen → podgląd pokaże pierwszą klatkę
            return False

    def set_loop(self, on):
        self.loop_video = bool(on)
        if not self.loop_video:
            self._tail = None
            self._blend_src = None
        else:
            self._tail_want = -1        # przelicz bufor ogona przy najbliższej klatce
        return self.loop_video

    def set_loop_blend(self, seconds):
        """Długość płynnego szwu na pętli (0 = twarde cięcie)."""
        try:
            self.loop_blend = max(0.0, min(2.0, float(seconds)))
        except Exception:
            pass
        self._tail_want = -1
        return self.loop_blend

    def seek(self, seconds=None, frames=None):
        """Przeskocz nagranie (sekundy ALBO numery klatek). True = pozycja ustawiona."""
        if not HAS_CV2:
            return False
        with self._cap_lock:
            cap = self._cap
            if cap is None:
                return False
            try:
                fps = self._video_fps or float(self.fps) or 30.0
                if frames is None:
                    frames = int(round(float(seconds or 0.0) * fps))
                frames = int(max(0, frames))
                if self._video_len > 0:
                    frames = min(frames, max(0, self._video_len - 1))
                cap.set(cv2.CAP_PROP_POS_FRAMES, frames)
                try:
                    got = int(cap.get(cv2.CAP_PROP_POS_FRAMES))
                except Exception:
                    got = -1
                if abs(got - frames) > 1:
                    if not self._seek_by_step(frames):
                        return False
                self._video_pos = frames
                self._blend_src = None
                self._blend_i = 0
                self._frozen = None
                try:
                    if self._tail:
                        self._tail.clear()
                except Exception:
                    pass
                return True
            except Exception:
                return False

    def nudge(self, delta_seconds):
        """Skok ±N sekund (dla przycisków i skrótów)."""
        info = self.video_info()
        fps = info["fps"] or 30.0
        return self.seek(frames=int(info["pos"]) + int(round(float(delta_seconds) * fps)))

    def _seek_by_step(self, target):
        """Ścieżka awaryjna dla kodeków, które ignorują CAP_PROP_POS_FRAMES."""
        with self._cap_lock:
            cap = self._cap
            if cap is None:
                return False
            try:
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                n = 0
                while n < min(int(target), 3000):
                    ok, _ = cap.read()
                    if not ok:
                        break
                    n += 1
                return n >= int(target) or n > 0
            except Exception:
                return False

    def video_info(self):
        """Dane do paska odtwarzacza: pozycja, długość, fps, pauza, pętla."""
        cur = self.current()
        is_vid = self.is_video_item()
        fps = float(self._video_fps or self.fps or 30.0)
        total = int(self._video_len or 0)
        pos = int(self._video_pos or 0)
        if total > 0:
            pos = max(0, min(pos, total - 1))
        return {"is_video": is_vid, "playing": bool(self.playing),
                "loop": bool(self.loop_video), "blend": float(self.loop_blend),
                "pos": pos, "frames": total, "fps": fps,
                "pos_s": (pos / fps) if fps else 0.0,
                "dur_s": (total / fps) if (total and fps) else 0.0,
                "name": (os.path.basename(cur["path"]) if cur else "")}

    # --------------------------------------------------- pętla z „płynnym szwem”
    def _tail_len_for(self, fr):
        """Ile ostatnich klatek trzymać w pamięci (crossfade), z limitem MB."""
        try:
            if not self.loop_video or self.loop_blend <= 0.01:
                return 0
            fps = float(self._video_fps or self.fps or 30.0)
            want = int(round(self.loop_blend * fps))
            if want < 1:
                return 0
            h, w = fr.shape[:2]
            per = max(1, int(h) * int(w) * 3)
            by_mem = max(1, self._tail_budget // per)
            return max(1, min(want, by_mem, 24))
        except Exception:
            return 0

    def _remember_tail(self, fr):
        n = self._tail_len_for(fr)
        if n <= 0:
            if self._tail:
                self._tail = None
            self._tail_want = -1
            return
        if self._tail is None or self._tail_want != n:
            self._tail = deque(maxlen=n)
            self._tail_want = n
        self._tail.append(fr)

    def _tail_snapshot(self):
        """Ogon nagrania (od najnowszej klatki) — zdjety PRZED skokiem na 0,
        bo seek czysci bufor. None = twardsze ciecie (brak rozplywania)."""
        try:
            if (not self.loop_video or self.loop_blend <= 0.01
                    or self._tail is None or len(self._tail) < 2):
                return None
            return list(reversed(list(self._tail)))
        except Exception:
            return None

    def _apply_loop_blend(self, fr):
        """Rozpływanie ostatnich klatek w pierwsze klatki po powtórce."""
        src = self._blend_src
        if not src:
            return fr
        n = len(src)
        i = self._blend_i
        if i >= n:
            self._blend_src = None
            return fr
        try:
            a = (i + 1.0) / (n + 1.0)
            out = cv2.addWeighted(src[i], 1.0 - a, fr, a, 0.0)
        except Exception:
            out = fr
        self._blend_i += 1
        if self._blend_i >= n:
            self._blend_src = None
            if self._tail:
                try:
                    self._tail.clear()
                except Exception:
                    pass
        return out

    def _loop_back(self):
        """Wróć do początku pliku. True = mamy nową klatkę do pokazania."""
        with self._cap_lock:
            if self._cap is None:
                return False
            if self.seek(frames=0):
                return True
            try:                   # seek nie zadziałał → otwórz plik od nowa
                self._close_cap()
                self._open_cap_if_needed()
                return self._cap is not None
            except Exception:
                return False

    def _handle_video_end(self):
        """Koniec pliku: pętla (z płynnym szwem) | stop na ostatniej klatce | dalej.

        Zwraca klatkę BGR do pokazania albo None (pustka / zmiana slajdu).
        """
        # UWAGA: wołane pod _cap_lock. next() bierze _lock, a GUI bierze _lock → _cap_lock
        # (goto/next/prev) — wołanie next() stąd groziłoby zakleszczeniem. Zamiast tego
        # zostawiamy flagę; _get_source_frame woła next() po zwolnieniu _cap_lock.
        if self.loop_video:
            blend = self._tail_snapshot()
            if self._loop_back() and self._cap is not None:
                self._blend_src = blend
                self._blend_i = 0
                ok, fr = self._cap.read()
                if ok:
                    self._video_pos = 1
                    self._frozen = fr
                    return self._apply_loop_blend(fr)
            self._close_cap()
            self._blend_src = None
            self._pending_next = True    # plik nie do odczytu → przeskocz
            return None
        self.playing = False
        if len(self.playlist) > 1 and self.mode in ("auto", "random"):
            self._pending_next = True
            return None
        return self._frozen              # ostatnia klatka zostaje na ekranie

    # ------------------------------------------- ręczne kadrowanie (zoom/pan)
    def set_frame(self, zoom=None, pan_x=None, pan_y=None):
        """Ustaw kadr ręcznie (z przycięciem do zakresów)."""
        if zoom is not None:
            self.zoom = max(0.5, min(3.0, float(zoom)))
        if pan_x is not None:
            self.pan_x = max(-1.0, min(1.0, float(pan_x)))
        if pan_y is not None:
            self.pan_y = max(-1.0, min(1.0, float(pan_y)))

    def reset_frame(self):
        """Wyzeruj kadr bieżącego slajdu."""
        self.zoom, self.pan_x, self.pan_y = 1.0, 0.0, 0.0
        cur = self.current()
        if cur:
            self.frame_memory.pop(cur["path"], None)
        self._frame_changed = True

    def set_orientation(self, o):
        if o in ("portrait", "landscape"):
            self.orientation = o

    def _track_slide_frame(self):
        """Zapamiętaj kadr starego slajdu i przywróć kadr nowego.

        Wołane przy każdym pobraniu klatki — dzięki temu każde zdjęcie
        ma własny, zapamiętany kadr (zoom + pozycja)."""
        cur = self.current()
        path = cur["path"] if cur else None
        if path != self._last_path:
            if self._last_path:
                self.frame_memory[self._last_path] = (self.zoom, self.pan_x, self.pan_y)
            if path and path in self.frame_memory:
                try:
                    z, x, y = self.frame_memory[path]
                    self.zoom, self.pan_x, self.pan_y = float(z), float(x), float(y)
                    self._frame_changed = True
                except Exception:
                    pass
            elif path:
                # nowy slajd bez zapamiętanego kadru → zacznij od domyślnego
                if (self.zoom, self.pan_x, self.pan_y) != (1.0, 0.0, 0.0):
                    self.zoom, self.pan_x, self.pan_y = 1.0, 0.0, 0.0
                    self._frame_changed = True
            self._last_path = path

    # ------------------------------------------------- start / stop render
    def start(self):
        if self._running:
            return
        self._running = True
        self._last_switch = time.time()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        th = self._thread
        if th is not None and th.is_alive() and th is not threading.current_thread():
            th.join(timeout=1.5)     # nie zamykaj pliku, gdy wątek jeszcze czyta klatkę
        self._thread = None
        self.stop_virtual()
        self._close_cap()
        self.close_live_camera()

    def set_live_camera(self, index, name=""):
        """Use a tested host camera as the live source; None restores media."""
        self.close_live_camera()
        if index is None or not HAS_CV2:
            self.input_camera_index = None
            self.input_camera_name = ""
            return False
        try:
            idx = int(index)
            if os.name == "nt" and name:
                # Numeric OpenCV indexes can point at a different DirectShow
                # filter than the displayed name (e.g. Redmi selected, Iriun
                # opened). Bind the graph to the exact selected filter name.
                import virtual_devices as VD
                cap = VD.open_camera_exact(idx, str(name))
            else:
                backend = cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY
                cap = cv2.VideoCapture(idx, backend)
            ok, _frame = cap.read() if cap is not None and cap.isOpened() else (False, None)
            if not ok:
                if cap is not None:
                    cap.release()
                self.input_camera_error = ("Kamera %s nie oddała klatki (używa jej inny program albo sterownik jest zajęty)."
                                           % str(name or idx))
                return False
            with self._input_camera_lock:
                self._input_camera = cap
                self.input_camera_index = idx
                self.input_camera_name = str(name or "Camera %d" % idx)
                self.input_camera_error = ""
            return True
        except Exception as exc:
            self.input_camera_error = str(exc)
            return False

    def close_live_camera(self):
        with self._input_camera_lock:
            cap, self._input_camera = self._input_camera, None
            if cap is not None:
                try:
                    cap.release()
                except Exception:
                    pass

    def live_camera_working(self):
        with self._input_camera_lock:
            return self._input_camera is not None and self._input_camera.isOpened()

    def start_virtual(self, backend=None):
        """Otwórz wirtualną kamerę. backend: None/'auto' | 'obs' | 'unitycapture'.
        Zwraca (ok, komunikat). Użyty silnik ląduje w vcam_backend_used."""
        if not HAS_VCAM:
            self.vcam_error = "Brak pyvirtualcam — uruchom INSTALUJ.bat."
            return False, self.vcam_error
        be = backend or getattr(self, "vcam_backend", "auto")
        if be == "auto":
            be = None
        fmt = get_format(self.format_id)
        w, h = fmt["width"], fmt["height"]
        if self.orientation == "landscape":
            w, h = h, w  # wymiar zgodny z renderem (telefon na długość)
        if self.virtual_output_size:
            w, h = self.virtual_output_size
        # Unity Capture requires even dimensions and custom widths in groups of
        # four. Mobile mode uses VGA, which Android CameraProvider negotiates
        # consistently across old and current Windows emulator builds.
        w -= w % 4
        h -= h % 2
        try:
            if self._cam is not None:
                try:
                    self._cam.close()
                except Exception:
                    pass
                self._cam = None
            kwargs = dict(width=w, height=h, fps=self.fps, print_fps=False)
            # OpenCV renders BGR. Declaring that producer format lets
            # pyvirtualcam convert into the DirectShow driver's negotiated
            # consumer format instead of publishing swapped RGB bytes.
            pixel_formats = getattr(pyvirtualcam, "PixelFormat", None)
            if pixel_formats is not None and hasattr(pixel_formats, "BGR"):
                kwargs["fmt"] = pixel_formats.BGR
            if be is not None:
                kwargs["backend"] = be
            try:
                self._cam = pyvirtualcam.Camera(**kwargs)
            except TypeError:
                kwargs.pop("backend", None)  # stara wersja pyvirtualcam
                try:
                    self._cam = pyvirtualcam.Camera(**kwargs)
                except TypeError:
                    kwargs.pop("fmt", None)
                    self._cam = pyvirtualcam.Camera(**kwargs)
            try:
                self.vcam_backend_used = str(getattr(self._cam, "backend", be or "auto"))
            except Exception:
                self.vcam_backend_used = be or "auto"
            try:
                self.vcam_device = str(self._cam.device)
            except Exception:
                self.vcam_device = ""
            self._cam_size = (w, h)
            self.vcam_active = True
            self.vcam_error = ""
            return True, f"Nadaję do: {self.vcam_device}  ({w}×{h} @ {self.fps} fps)"
        except Exception as e:
            self._cam = None
            self.vcam_active = False
            self.vcam_error = str(e)
            return False, ("Nie mogę otworzyć wirtualnej kamery. "
                           "Zainstaluj OBS Studio (Start Virtual Camera) lub Unity Capture "
                           "i uruchom USTAW_URZADZENIA.bat.\n"
                           f"Szczegóły: {e}")

    def stop_virtual(self):
        try:
            if self._cam is not None:
                self._cam.close()
        except Exception:
            pass
        self._cam = None
        self.vcam_active = False

    def get_preview(self):
        with self._lock:
            return None if self._preview_frame is None else self._preview_frame.copy()

    # ------------------------------------------------------------- pętla
    def _loop(self):
        t_prev = time.time()
        ema = 1 / 30
        while self._running:
            t0 = time.time()
            # auto-slideshow
            if self.playlist and self.mode in ("auto", "random"):
                cur = self.current()
                is_vid = cur and cur["type"] == "video"
                # wideo: konczy sie SOP (w _handle_video_end), nie tniemy mu pętli
                if not is_vid and (t0 - self._last_switch) >= self.interval:
                    self.next(manual=False)
                elif is_vid and not self.loop_video and not self.playing:
                    # nagranie sie skonczylo bez pętli → po chwili idziemy dalej
                    if (t0 - self._last_switch) >= max(self.interval, 2.0):
                        self.next(manual=False)
            try:
                frame = self._render_frame()
            except Exception:
                # Jedna zła klatka (uszkodzony plik, wyścig przy zmianie slajdu) nie może
                # zabić wątku renderowania — wcześniej podgląd zamierał na stałe.
                frame = None
                time.sleep(0.05)
            if frame is not None:
                with self._lock:
                    self._preview_frame = frame.copy()
                if self._cam is not None and self.vcam_active:
                    try:
                        cw, ch = self._cam_size
                        send = frame
                        if self.virtual_output_rotation == 90 and HAS_CV2:
                            send = cv2.rotate(send, cv2.ROTATE_90_CLOCKWISE)
                        elif self.virtual_output_rotation == 270 and HAS_CV2:
                            send = cv2.rotate(send, cv2.ROTATE_90_COUNTERCLOCKWISE)
                        elif self.virtual_output_rotation == 180 and HAS_CV2:
                            send = cv2.rotate(send, cv2.ROTATE_180)
                        if (send.shape[1], send.shape[0]) != (cw, ch) and HAS_CV2:
                            # Fit without rotating or stretching the portrait
                            # composition. Android receives a conventional
                            # landscape sensor frame and handles display layout.
                            fh, fw = send.shape[:2]
                            scale = min(float(cw) / max(1, fw), float(ch) / max(1, fh))
                            nw, nh = max(1, int(fw * scale)), max(1, int(fh * scale))
                            fitted = cv2.resize(send, (nw, nh), interpolation=cv2.INTER_LINEAR)
                            canvas = np.zeros((ch, cw, 3), dtype=fitted.dtype)
                            x, y = (cw - nw) // 2, (ch - nh) // 2
                            canvas[y:y + nh, x:x + nw] = fitted
                            send = canvas
                        self._cam.send(send)
                        try:
                            self._cam.sleep_until_next_frame()
                        except Exception:
                            pass
                    except Exception as e:
                        self.vcam_error = str(e)
                        self.vcam_active = False
                        try:
                            self._cam.close()
                        except Exception:
                            pass
                        self._cam = None
            # fps
            dt = time.time() - t0
            ema = 0.9 * ema + 0.1 * max(dt, 1e-4)
            self.actual_fps = 1.0 / ema
            sleep_for = max(0.0, (1.0 / self.fps) - dt)
            # adaptacyjna jakość: słaby PC → render w niższej rozdzielczości + upscale
            try:
                if ema > 1 / 22 and self._render_scale > 0.5:
                    self._render_scale = max(0.5, self._render_scale - 0.05)
                elif ema < 1 / 45 and self._render_scale < 1.0:
                    self._render_scale = min(1.0, self._render_scale + 0.02)
            except Exception:
                pass
            time.sleep(sleep_for if not self.vcam_active else min(sleep_for, 0.005))
            t_prev = t0

    # ------------------------------------------------------------ render
    def _render_frame(self):
        if not HAS_NUMPY or not HAS_CV2:
            return None
        fmt = get_format(self.format_id)
        W, H = fmt["width"], fmt["height"]
        if self.orientation == "landscape":
            W, H = H, W  # telefon na długość (poziomo)
        W -= W % 2
        H -= H % 2
        # mniejsza robocza dla 4K (wydajność) + adaptacyjna skala, na końcu upscale
        scale = self._render_scale
        if max(W, H) > 2600:
            scale *= 0.5
        wW, wH = max(2, int(W * scale) // 2 * 2), max(2, int(H * scale) // 2 * 2)

        base = self._get_source_frame(wW, wH)
        if base is None:
            base = self._placeholder(wW, wH)

        # przejście (transition)
        if self._trans_from is not None and self.transition in ("fade", "black"):
            try:
                tf = self._trans_from
                if (tf.shape[1], tf.shape[0]) != (wW, wH):
                    tf = cv2.resize(tf, (wW, wH))
                k = min(1.0, (time.time() - self._trans_t0) / 0.6)
                if self.transition == "fade":
                    base = cv2.addWeighted(tf, 1 - k, base, k, 0)
                else:  # przez czerń
                    if k < 0.5:
                        base = cv2.addWeighted(tf, 1 - k * 2, np.zeros_like(tf), k * 2, 0)
                    else:
                        base = cv2.addWeighted(np.zeros_like(base), 1 - (k - 0.5) * 2, base, (k - 0.5) * 2, 0)
                if k >= 1.0:
                    self._trans_from = None
            except Exception:
                self._trans_from = None

        frame = base
        # lustro / obrót
        if self.mirror:
            frame = cv2.flip(frame, 1)
        if self.rotate == 90:
            frame = cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)
            frame = cv2.resize(frame, (wW, wH))
        elif self.rotate == 180:
            frame = cv2.rotate(frame, cv2.ROTATE_180)
        elif self.rotate == 270:
            frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)
            frame = cv2.resize(frame, (wW, wH))

        # filtr
        frame = self._apply_filter(frame)
        # drganie telefonu (shake)
        if self.fx_shake:
            frame = self._apply_shake(frame)
        # ziarno
        if self.fx_grain:
            frame = self._apply_grain(frame)
        # winieta
        if self.fx_vignette:
            frame = self._apply_vignette(frame)
        # autofocus
        if self.fx_autofocus:
            frame = self._apply_autofocus(frame)
        # nakładki Realme UI
        frame = self._apply_overlays(frame)

        if scale != 1.0:
            frame = cv2.resize(frame, (W, H), interpolation=cv2.INTER_LINEAR)
        # RGB (pyvirtualcam + podgląd chcą RGB)
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        return frame

    def _begin_transition(self):
        try:
            if self._preview_frame is not None and self.transition in ("fade", "black") and HAS_CV2:
                bgr = cv2.cvtColor(self._preview_frame, cv2.COLOR_RGB2BGR)
                self._trans_from = bgr
                self._trans_t0 = time.time()
            else:
                self._trans_from = None
        except Exception:
            self._trans_from = None

    def set_custom_frame(self, frame):
        self._custom_frame = frame

    def _get_source_frame(self, wW, wH):
        # A selected live source has priority over files. Reading is guarded so
        # switching devices cannot release VideoCapture during a frame read.
        with self._input_camera_lock:
            if self._input_camera is not None:
                ok, live = self._input_camera.read()
                if ok and live is not None:
                    self.input_camera_error = ""
                    # Correct the raw camera first, while its natural aspect
                    # ratio is still available. This is independent from the
                    # output sensor rotation used by Android CameraProvider.
                    rotation = int(getattr(self, "input_rotation", 0) or 0) % 360
                    if rotation == 90:
                        live = cv2.rotate(live, cv2.ROTATE_90_CLOCKWISE)
                    elif rotation == 180:
                        live = cv2.rotate(live, cv2.ROTATE_180)
                    elif rotation == 270:
                        live = cv2.rotate(live, cv2.ROTATE_90_COUNTERCLOCKWISE)
                    if bool(getattr(self, "input_mirror", False)):
                        live = cv2.flip(live, 1)
                    return self._fit(live, wW, wH)
                self.input_camera_error = "The selected camera stopped returning frames."
        if getattr(self, "_custom_frame", None) is not None:
            cframe = self._custom_frame
            if hasattr(cframe, "convert"):
                cframe = cv2.cvtColor(np.array(cframe.convert("RGB")), cv2.COLOR_RGB2BGR)
            return self._fit(cframe, wW, wH)

        self._track_slide_frame()
        cur = self.current()
        if cur is None:
            return None
        if cur["type"] == "image":
            img = self._img_cache.get(cur["path"])
            if img is None:
                img = cv2.imread(cur["path"], cv2.IMREAD_COLOR)
                if img is None and HAS_PIL:
                    try:
                        pil = Image.open(cur["path"]).convert("RGB")
                        img = cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)
                    except Exception:
                        img = None
                if img is None:
                    return None
                # cache max ~12 zdjęć
                if len(self._img_cache) >= 12:
                    self._img_cache.pop(next(iter(self._img_cache)))
                self._img_cache[cur["path"]] = img
            return self._fit(img, wW, wH)
        else:
            fr = self._read_video_frame()
            if self._pending_next:
                self._pending_next = False
                self.next(manual=False)
            return self._fit(fr, wW, wH) if fr is not None else None

    def _read_video_frame(self):
        """Kolejna klatka nagrania (BGR) albo None. Cała praca na VideoCapture pod _cap_lock."""
        with self._cap_lock:
            self._open_cap_if_needed()
            cap = self._cap
            if cap is None:
                return None
            if not self.playing:
                # pauza / stop: trzymamy klatkę w kadrze, żeby obraz nie znikał
                if self._frozen is None:
                    self._peek_frozen()
                return self._frozen
            try:
                ok, fr = cap.read()
            except Exception:
                ok, fr = False, None
            if not ok or fr is None:
                return self._handle_video_end()
            self._video_pos += 1
            self._frozen = fr
            self._remember_tail(fr)          # ogon → potrzebny na szwie pętli
            return self._apply_loop_blend(fr)  # rozpuszczenie ogona w początek

    def _open_cap_if_needed(self):
        cur = self.current()
        if not HAS_CV2:
            return
        if cur is None or cur["type"] != "video":
            if self._cap is not None and (cur is None or cur["type"] == "image"):
                pass  # zostaw cap (szybki powrót), ale nie wymagane
            return
        with self._cap_lock:
            if self._cap_path == cur["path"] and self._cap is not None:
                return
            self._close_cap()
            try:
                cap = cv2.VideoCapture(cur["path"])
                if cap.isOpened():
                    self._cap = cap
                    self._cap_path = cur["path"]
                    self._probe_video()
                else:
                    try:
                        cap.release()
                    except Exception:
                        pass
            except Exception:
                self._cap = None

    def _probe_video(self):
        """Wczytaj metrykę pliku (fps, liczba klatek) i wyzeruj transport."""
        try:
            fps = float(self._cap.get(cv2.CAP_PROP_FPS) or 0.0)
            self._video_fps = fps if fps > 1.0 else float(self.fps or 30)
            n = int(self._cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
            self._video_len = n if n > 1 else 0
        except Exception:
            self._video_fps = float(self.fps or 30)
            self._video_len = 0
        try:
            self._video_pos = max(0, int(self._cap.get(cv2.CAP_PROP_POS_FRAMES) or 0))
        except Exception:
            self._video_pos = 0
        self.playing = True
        self._frozen = None
        self._tail = None
        self._tail_want = -1
        self._blend_src = None
        self._blend_i = 0

    def _peek_frozen(self):
        """Pobierz bieżącą klatkę bez przesuwania pozycji (obraz pod pauzą/stopem)."""
        with self._cap_lock:
            cap = self._cap
            if cap is None:
                return
            try:
                pos = int(cap.get(cv2.CAP_PROP_POS_FRAMES) or 0)
                ok, fr = cap.read()
                try:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, max(0, pos))
                except Exception:
                    pass
                if ok and fr is not None:
                    self._frozen = fr
                    self._video_pos = max(0, pos)
            except Exception:
                pass

    def _close_cap(self):
        with self._cap_lock:
            cap, self._cap, self._cap_path = self._cap, None, None
            try:
                if cap is not None:
                    cap.release()
            except Exception:
                pass

    def _fit(self, img, wW, wH):
        """Dopasuj obraz do kadru + ręczny zoom i przesunięcie (pan).

        Konwencja: pan_x > 0 → treść w prawo, pan_y > 0 → treść w dół
        (jak „chwycenie" zdjęcia myszką)."""
        h, w = img.shape[:2]
        if h == 0 or w == 0:
            return np.zeros((wH, wW, 3), dtype=np.uint8)
        zoom = max(0.2, min(5.0, float(getattr(self, "zoom", 1.0) or 1.0)))
        px = max(-1.0, min(1.0, float(getattr(self, "pan_x", 0.0) or 0.0)))
        py = max(-1.0, min(1.0, float(getattr(self, "pan_y", 0.0) or 0.0)))

        if self.fit_mode == "stretch":
            nw = max(1, int(wW * zoom))
            nh = max(1, int(wH * zoom))
        else:
            base = max(wW / w, wH / h) if self.fit_mode in ("fill", "blur") else min(wW / w, wH / h)
            s = base * zoom
            nw, nh = max(1, int(w * s)), max(1, int(h * s))
        resized = cv2.resize(img, (nw, nh),
                             interpolation=cv2.INTER_AREA if (nw < w and nh < h) else cv2.INTER_LINEAR)

        # tło
        if self.fit_mode == "blur":
            bg = cv2.resize(img, (wW, wH), interpolation=cv2.INTER_LINEAR)
            bg = cv2.GaussianBlur(bg, (0, 0), 25)
            bg = cv2.convertScaleAbs(bg, alpha=0.55, beta=0)
        else:
            bg = np.zeros((wH, wW, 3), dtype=np.uint8)

        # obraz większy od kadru → wycinamy okno (pan przesuwa TREŚĆ);
        # obraz mniejszy → wklejamy z przesunięciem w marginesach.
        if nw >= wW:
            x0 = int((nw - wW) / 2 - px * (nw - wW) / 2)
            x0 = max(0, min(nw - wW, x0))
            dx, cw = 0, wW
        else:
            x0, cw = 0, nw
            dx = int((wW - nw) / 2 + px * (wW - nw) / 2)
        if nh >= wH:
            y0 = int((nh - wH) / 2 - py * (nh - wH) / 2)
            y0 = max(0, min(nh - wH, y0))
            dy, ch = 0, wH
        else:
            y0, ch = 0, nh
            dy = int((wH - nh) / 2 + py * (wH - nh) / 2)
        bg[dy:dy + ch, dx:dx + cw] = resized[y0:y0 + ch, x0:x0 + cw]
        return bg

    def _placeholder(self, wW, wH):
        img = np.zeros((wH, wW, 3), dtype=np.uint8)
        # gradient granat → czerń
        for y in range(wH):
            k = y / max(1, wH)
            img[y, :] = (int(24 + 30 * k), int(20 + 22 * k), int(46 + 40 * k))
        if HAS_CV2:
            cx = wW // 2
            cv2.circle(img, (cx, int(wH * 0.40)), min(wW, wH) // 8, (232, 169, 61), 3)
            cv2.circle(img, (cx, int(wH * 0.40)), min(wW, wH) // 24, (232, 169, 61), -1)
            fs = max(0.6, wW / 900)
            app_title = getattr(self, "brand_title", "vStudio") or "vStudio"
            (tw, _), _ = cv2.getTextSize(app_title, cv2.FONT_HERSHEY_SIMPLEX, fs * 1.1, max(1, int(2 * fs)))
            cv2.putText(img, app_title, (cx - tw // 2, int(wH * 0.52)),
                        cv2.FONT_HERSHEY_SIMPLEX, fs * 1.1, (235, 235, 235), max(1, int(2 * fs)), cv2.LINE_AA)
            cv2.putText(img, "Dodaj zdjecia lub nagrania, aby rozpoczac projekcje",
                        (cx - int(360 * fs), int(wH * 0.56)),
                        cv2.FONT_HERSHEY_SIMPLEX, fs * 0.65, (180, 180, 180), max(1, int(fs)), cv2.LINE_AA)
        return img

    # --------------------------------------------------------------- efekty
    def _apply_filter(self, f):
        fid = self.filter_id
        if fid == "normal":
            return f
        try:
            if fid == "vivid":
                hsv = cv2.cvtColor(f, cv2.COLOR_BGR2HSV).astype(np.float32)
                hsv[:, :, 1] *= 1.35
                hsv[:, :, 2] *= 1.08
                np.clip(hsv[:, :, 1], 0, 255, out=hsv[:, :, 1])
                np.clip(hsv[:, :, 2], 0, 255, out=hsv[:, :, 2])
                return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)
            if fid == "night":
                f = cv2.convertScaleAbs(f, alpha=0.85, beta=-18)
                f[:, :, 0] = cv2.convertScaleAbs(f[:, :, 0], alpha=1.15)
                return f
            if fid == "bw":
                g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
                return cv2.cvtColor(g, cv2.COLOR_GRAY2BGR)
            if fid == "sepia":
                k = np.array([[0.272, 0.534, 0.131],
                              [0.349, 0.686, 0.168],
                              [0.393, 0.769, 0.189]], dtype=np.float32)
                return cv2.convertScaleAbs(cv2.transform(f, k))
            if fid == "cold":
                f = f.astype(np.float32)
                f[:, :, 0] *= 1.18
                f[:, :, 2] *= 0.88
                return np.clip(f, 0, 255).astype(np.uint8)
            if fid == "warm":
                f = f.astype(np.float32)
                f[:, :, 2] *= 1.18
                f[:, :, 0] *= 0.88
                return np.clip(f, 0, 255).astype(np.uint8)
        except Exception:
            pass
        return f

    def _apply_shake(self, f):
        amt = float(self.fx_shake_amount)
        if amt <= 0.1:
            return f
        try:
            dx = random.uniform(-amt, amt)
            dy = random.uniform(-amt, amt)
            M = np.float32([[1, 0, dx], [0, 1, dy]])
            h, w = f.shape[:2]
            # powiększ lekko, żeby nie było czarnych krawędzi
            pad = int(amt + 2)
            big = cv2.copyMakeBorder(f, pad, pad, pad, pad, cv2.BORDER_REPLICATE)
            sh = cv2.warpAffine(big, M, (w + 2 * pad, h + 2 * pad),
                                flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            return sh[pad:pad + h, pad:pad + w].copy()
        except Exception:
            return f

    def _apply_grain(self, f):
        try:
            amt = float(self.fx_grain_amount)
            noise = np.random.randn(*f.shape[:2]).astype(np.float32) * amt
            n3 = np.repeat(noise[:, :, None], 3, axis=2)
            return np.clip(f.astype(np.float32) + n3, 0, 255).astype(np.uint8)
        except Exception:
            return f

    def _apply_vignette(self, f):
        try:
            h, w = f.shape[:2]
            key = (w, h)
            if getattr(self, "_vig_key", None) != key:
                yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
                cx, cy = w / 2, h / 2
                d = np.sqrt(((xx - cx) / (w / 2)) ** 2 + ((yy - cy) / (h / 2)) ** 2) / np.sqrt(2)
                mask = np.clip(1.0 - d * 0.55, 0.45, 1.0).astype(np.float32)
                self._vig_mask = mask
                self._vig_key = key
            return (f.astype(np.float32) * self._vig_mask[:, :, None]).astype(np.uint8)
        except Exception:
            return f

    def _apply_autofocus(self, f):
        try:
            now = time.time()
            h, w = f.shape[:2]
            if now >= self._af_box_next:
                self._af_pos = (random.uniform(0.3, 0.7), random.uniform(0.25, 0.65))
                self._af_box_until = now + random.uniform(1.2, 2.2)
                self._af_box_next = now + random.uniform(5, 14)
            if now < self._af_box_until:
                cx, cy = int(self._af_pos[0] * w), int(self._af_pos[1] * h)
                s = min(w, h) // 7
                col = (80, 220, 120)
                th = max(1, w // 400)
                L = s // 3
                # narożniki ramki ostrości
                x0, y0, x1, y1 = cx - s, cy - s, cx + s, cy + s
                cv2.line(f, (x0, y0), (x0 + L, y0), col, th); cv2.line(f, (x0, y0), (x0, y0 + L), col, th)
                cv2.line(f, (x1, y0), (x1 - L, y0), col, th); cv2.line(f, (x1, y0), (x1, y0 + L), col, th)
                cv2.line(f, (x0, y1), (x0 + L, y1), col, th); cv2.line(f, (x0, y1), (x0, y1 - L), col, th)
                cv2.line(f, (x1, y1), (x1 - L, y1), col, th); cv2.line(f, (x1, y1), (x1, y1 - L), col, th)
        except Exception:
            pass
        return f

    def _apply_overlays(self, f):
        try:
            h, w = f.shape[:2]
            fs = max(0.5, w / 1100)
            th = max(1, int(1.6 * fs))
            pad = int(24 * fs)
            y = pad + int(30 * fs)
            if self.ov_rec and self.vcam_active:
                cv2.circle(f, (pad + int(14 * fs), y), int(12 * fs), (60, 60, 230), -1)
                cv2.putText(f, "REC", (pad + int(34 * fs), y + int(10 * fs)),
                            cv2.FONT_HERSHEY_SIMPLEX, fs * 0.8, (230, 230, 230), th, cv2.LINE_AA)
            if self.ov_timestamp:
                ts = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
                (tw, _), _ = cv2.getTextSize(ts, cv2.FONT_HERSHEY_SIMPLEX, fs * 0.62, th)
                cv2.putText(f, ts, (w - tw - pad, h - pad),
                            cv2.FONT_HERSHEY_SIMPLEX, fs * 0.62, (225, 225, 225), th, cv2.LINE_AA)
            if self.ov_brand:
                cam_name = getattr(self, "camera_name", "vStudio") or "vStudio"
                brand_str = f"{cam_name}  |  50MP OIS"
                cv2.putText(f, brand_str, (pad, h - pad),
                            cv2.FONT_HERSHEY_SIMPLEX, fs * 0.62, (225, 225, 225), th, cv2.LINE_AA)
            if self.ov_battery:
                bx, by = w - pad - int(90 * fs), pad
                bw, bh = int(80 * fs), int(34 * fs)
                cv2.rectangle(f, (bx, by), (bx + bw, by + bh), (220, 220, 220), th)
                cv2.rectangle(f, (bx + bw, by + bh // 4), (bx + bw + int(8 * fs), by + 3 * bh // 4), (220, 220, 220), -1)
                cv2.rectangle(f, (bx + 4, by + 4), (bx + int(bw * 0.72), by + bh - 4), (120, 220, 120), -1)
        except Exception:
            pass
        return f
