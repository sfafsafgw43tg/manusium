# -*- coding: utf-8 -*-
"""
vStudio — formaty telefonowe i proporcje kadrów.

Format domyślny: 1080 x 2412 px (20:9), natywna wysoka rozdzielczość
do wirtualnej kamery w komunikatorach i mediach społecznościowych.
"""
from collections import OrderedDict

PHONE_FORMATS = OrderedDict([
    ("realme12pro", {
        "label": "vStudio  •  1080 × 2412  (20:9, natywny)",
        "width": 1080, "height": 2412, "desc": "Natywna rozdzielczość 1080x2412 (20:9).",
    }),
    ("fhd_vert", {
        "label": "Full HD pion  •  1080 × 1920  (9:16)",
        "width": 1080, "height": 1920, "desc": "Klasyczny pionowy Full HD — TikTok / Reels / rozmowy.",
    }),
    ("hd_vert", {
        "label": "HD pion  •  720 × 1600  (20:9, lekki)",
        "width": 720, "height": 1600, "desc": "Lżejszy format — słabsze komputery, mniejsze opóźnienia.",
    }),
    ("qhd_vert", {
        "label": "QHD pion  •  1440 × 2560  (9:16)",
        "width": 1440, "height": 2560, "desc": "Ostrzejszy obraz, większe obciążenie.",
    }),
    ("uhd_vert", {
        "label": "4K pion  •  2160 × 3840  (9:16)",
        "width": 2160, "height": 3840, "desc": "Maksymalna jakość. Uwaga: wymaga mocnego PC.",
    }),
    ("fhd_horiz", {
        "label": "Full HD poziom  •  1920 × 1080  (16:9)",
        "width": 1920, "height": 1080, "desc": "Poziomo — Zoom / Teams / Meet na komputerze.",
    }),
    ("square", {
        "label": "Kwadrat  •  1080 × 1080  (1:1)",
        "width": 1080, "height": 1080, "desc": "Instagram / awatar / zdjęcia profilowe.",
    }),
    ("story", {
        "label": "Story  •  1080 × 2400  (pełny ekran)",
        "width": 1080, "height": 2400, "desc": "Pełnoekranowe stories.",
    }),
])

PHONE_FORMATS["vstudio"] = PHONE_FORMATS["realme12pro"]

FIT_MODES = OrderedDict([
    ("fill",   "Wypełnij (przytnij brzegi)"),
    ("fit",    "Dopasuj (czarne pasy)"),
    ("stretch", "Rozciągnij (cały kadr)"),
    ("blur",   "Dopasuj + rozmyte tło"),
])

FILTERS = OrderedDict([
    ("normal", "Normalny"),
    ("vivid",  "Żywy (Vivid)"),
    ("night",  "Nocny"),
    ("bw",     "Czarno-biały"),
    ("sepia",  "Sepia / Retro"),
    ("cold",   "Chłodny"),
    ("warm",   "Ciepły"),
])

TRANSITIONS = OrderedDict([
    ("none",  "Brak (cięcie)"),
    ("fade",  "Przenikanie"),
    ("black", "Przez czerń"),
])

SLIDESHOW_MODES = OrderedDict([
    ("manual", "Ręczny (strzałki / przyciski)"),
    ("auto",   "Auto — po kolei"),
    ("random", "Auto — losowo"),
])


def register_custom_format(format_id: str, width: int, height: int, label: str, desc: str = "") -> str:
    """Dodaje (lub aktualizuje) format o dowolnej rozdzielczosci.

    Uzywane przez tryb mobilny: kadr wirtualnej kamery jest wtedy dokladnie
    taki, jak ekran emulowanego telefonu, wiec obraz nie jest skalowany.
    """
    try:
        width, height = int(width), int(height)
    except Exception:
        return ""
    if width < 240 or height < 240 or width > 8192 or height > 8192:
        return ""
    PHONE_FORMATS[format_id] = {
        "label": label or ("Telefon  •  %d × %d" % (width, height)),
        "width": width, "height": height,
        "desc": desc or "Rozdzielczosc emulowanego telefonu.",
    }
    # Format telefonu ma byc pierwszy na liscie wyboru.
    PHONE_FORMATS.move_to_end(format_id, last=False)
    return format_id


def get_format(format_id: str):
    if format_id in PHONE_FORMATS:
        return PHONE_FORMATS[format_id]
    return PHONE_FORMATS["realme12pro"]
