# -*- coding: utf-8 -*-
"""
vStudio — silnik losowych szumów "jak z mikrofonu telefonu".

Generuje w czasie rzeczywistym (44.1/48 kHz, mono→stereo) dźwięk, który brzmi
jak prawdziwy mikrofon w smartfonie:
  • cichy szum własny mikrofonu (biały + różowy),
  • przydźwięk sieciowy 50 Hz (bardzo cichy),
  • podmuchy wiatru / szum otoczenia zależny od profilu,
  • LOSOWE ZDARZENIA: trzaski, puknięcia, tarcie o ubranie,
    kliknięcia, "pyknięcia" GSM, szuranie, kaszlnięcie w tle itp.

Profile: pokój, ulica, wiatr, tłum, samochód, deszcz, noc, losowy AI.

Wyjście: dowolne urządzenie odtwarzania — normalnie "CABLE Input
(VB-Audio Virtual Cable)", którego druga strona ("CABLE Output", po zmianie
nazwy: "vStudio") jest wybierana w komunikatorach jako mikrofon.

Działa w 100% OFFLINE. Bez serwera, bez internetu.

Wymaga: numpy + sounddevice. Jeśli ich brak — tryb DEMO (fałszywy VU meter).
"""
import math
import random
import threading
import time

try:
    import numpy as np
    HAS_NUMPY = True
except Exception:
    HAS_NUMPY = False

try:
    import sounddevice as sd
    HAS_SD = True
except Exception:
    HAS_SD = False
    sd = None

# v1.3: os czasu muzyki, odsluch miejscowy, nagrywanie
try:
    from audio_timeline import RingTap, AudioMixer, MonitorOut, Recorder, AudioTimeline
    HAS_TIMELINE = True
except Exception:
    HAS_TIMELINE = False
    try:
        from audio_timeline import RingTap, AudioMixer
    except Exception:
        RingTap = AudioMixer = MonitorOut = Recorder = AudioTimeline = None


# ---------------------------------------------------------------- profile
AUDIO_PROFILES = {
    "pokoj": {
        "label": "Cichy pokój",
        "desc": "Delikatny szum, rzadkie trzaski i szuranie.",
        "base": 0.012, "wind": 0.0, "rumble": 0.004, "hum": 0.004,
        "event_gap": (6, 22), "events": ["click", "rustle", "thump_soft", "crackle", "sniff", "sigh", "soft_breath"],
    },
    "ulica": {
        "label": "Ulica / miasto",
        "desc": "Przytłumiony gwar, przejeżdżające auta, wiatr.",
        "base": 0.030, "wind": 0.05, "rumble": 0.020, "hum": 0.002,
        "event_gap": (3, 10), "events": ["car", "click", "wind_gust", "rustle", "horn_far"],
    },
    "wiatr": {
        "label": "Wiatr",
        "desc": "Silne podmuchy wiatru w mikrofon — jak nagranie z dworu.",
        "base": 0.020, "wind": 0.16, "rumble": 0.010, "hum": 0.001,
        "event_gap": (2, 7), "events": ["wind_gust", "wind_gust", "rustle", "crackle"],
    },
    "tlum": {
        "label": "Tłum / kawiarnia",
        "desc": "Gwar rozmów w tle, stukanie filiżanek.",
        "base": 0.045, "wind": 0.01, "rumble": 0.008, "hum": 0.002,
        "event_gap": (2, 8), "events": ["murmur", "clink", "rustle", "thump_soft", "click"],
    },
    "samochod": {
        "label": "Samochód / jazda",
        "desc": "Niski pomruk silnika i szum opon + kierunkowskaz.",
        "base": 0.035, "wind": 0.03, "rumble": 0.035, "hum": 0.006,
        "event_gap": (4, 12), "events": ["blinker", "car", "thump_soft", "click", "sigh", "sniff"],
    },
    "deszcz": {
        "label": "Deszcz",
        "desc": "Równy szum deszczu za oknem.",
        "base": 0.055, "wind": 0.04, "rumble": 0.006, "hum": 0.002,
        "event_gap": (5, 14), "events": ["thunder_far", "rustle", "crackle", "sigh"],
    },
    "noc": {
        "label": "Noc / sypialnia",
        "desc": "Prawie cisza — słychać tylko szum elektroniki.",
        "base": 0.007, "wind": 0.0, "rumble": 0.002, "hum": 0.005,
        "event_gap": (10, 30), "events": ["click", "crackle", "sigh", "soft_breath", "deep_breath"],
    },
    "losowy": {
        "label": "Losowy AI (zmienia scenerię)",
        "desc": "Sam przełącza profile co kilka minut — nie do wykrycia rutyny.",
        "base": 0.025, "wind": 0.03, "rumble": 0.010, "hum": 0.003,
        "event_gap": (3, 12), "events": ["click", "rustle", "wind_gust", "car", "murmur", "crackle", "sniff", "sigh"],
    },
}


BREATH_GAIN = {
    # jak głośny jest ciągły oddech w danej scenerii (mnożnik)
    "pokoj": 0.55, "ulica": 0.25, "wiatr": 0.22, "tlum": 0.15,
    "samochod": 0.35, "deszcz": 0.40, "noc": 0.70, "losowy": 0.40,
}


class PhoneNoiseEngine:
    """Generator szumu mikrofonu telefonu w czasie rzeczywistym."""

    def __init__(self, sample_rate=48000, blocksize=4096):
        self.sr = int(sample_rate)
        self.block = int(blocksize)
        self.profile_id = "pokoj"
        self.volume = 0.8
        self.noise_level = 0.5   # 0..1 mnożnik szumu bazowego
        self.event_rate = 0.5    # 0..1 częstotliwość zdarzeń
        self.bass = 0.5          # 0..1 podbicie niskich tonów
        self.breath_on = True    # ciągły oddech (jak telefon blisko ust)
        self.breath_level = 0.45 # 0..1 głębokość oddechu
        self.breath_rate_base = 13.0  # bazowe tempo (oddechy/min), dryfuje ±3

        self._running = False
        self._stream = None
        self._thread = None
        self._lock = threading.Lock()

        # stan generatora (ciągłość między blokami)
        self._pink = [0.0] * 7
        self._brown_last = 0.0
        self._wind_phase = 0.0
        self._wind_lfo = 0.0
        self._hum_phase = 0.0
        self._engine_phase = 0.0
        self._breath_phase = 0.0
        self._breath_rate = 13.0
        self._breath_lp = 0.0
        self._breath_t = 0.0
        self._samples_until_event = self.sr * 3
        self._active_events = []   # lista dictów: {samples: np.array, pos: int, gain: float}
        self._level = 0.0          # wygładzony poziom (VU meter 0..1)
        self._muted = False
        self.output_device = None  # None = domyślne; lub index/nazwa
        self.input_device = None   # wybrany przez Octo.su mikrofon hosta
        self.demo_mode = not (HAS_NUMPY and HAS_SD)
        self.last_error = ""
        self._profile_switch_at = 0.0
        self._effective_profile = "pokoj"

        # --- v1.3: muzyka / os czasu, odsluch, nagrywanie, pauza ---
        self.timeline = None          # AudioTimeline podlaczony z UI
        self.mixer = AudioMixer(self.sr) if HAS_TIMELINE else None
        self.taps = []                # odbiorcy kopii sygnalu (odsluch, nagrywanie)
        self.out_tap = RingTap(self.sr, seconds=2.0) if HAS_TIMELINE else None
        if self.out_tap is not None:
            self.taps.append(self.out_tap)
        self.monitor = None           # MonitorOut (dzwiek slyszalny w aplikacji)
        self._paused = False

    # ---------------------------------------------------------- urządzenia
    @staticmethod
    def list_output_devices():
        """Zwraca listę (index, nazwa) urządzeń WYJŚCIA (tam kierujemy dźwięk)."""
        if not HAS_SD:
            return []
        try:
            devs = sd.query_devices()
        except Exception:
            return []
        out = []
        for i, d in enumerate(devs):
            try:
                if d.get("max_output_channels", 0) > 0:
                    out.append((i, str(d.get("name", f"Urządzenie {i}"))))
            except Exception:
                continue
        return out

    @staticmethod
    def list_input_devices():
        """Zwraca listę (index, nazwa) urządzeń WEJŚCIA (mikrofony)."""
        if not HAS_SD:
            return []
        try:
            devs = sd.query_devices()
        except Exception:
            return []
        out = []
        for i, d in enumerate(devs):
            try:
                if d.get("max_input_channels", 0) > 0:
                    out.append((i, str(d.get("name", f"Urządzenie {i}"))))
            except Exception:
                continue
        return out

    def active_input_device_name(self):
        """Name of the host microphone currently feeding the virtual cable."""
        if self.input_device is None:
            return "Generator vStudio"
        if not HAS_SD:
            return "Mikrofon #%s" % self.input_device
        try:
            info = sd.query_devices(self.input_device)
            return str(info.get("name") or ("Mikrofon #%s" % self.input_device))
        except Exception:
            return "Mikrofon #%s" % self.input_device

    @staticmethod
    def find_cable_device():
        """Szuka VB-CABLE (wejścia kabla = naszego wyjścia) po nazwie."""
        keys = ("cable input", "vb-audio", "vstudio", "realme 12 pro", "cable in")
        for idx, name in PhoneNoiseEngine.list_output_devices():
            low = name.lower()
            if any(k in low for k in keys):
                return idx, name
        return None, ""

    # ------------------------------------------------------------- sterowanie
    def set_profile(self, pid):
        if pid in AUDIO_PROFILES:
            with self._lock:
                self.profile_id = pid
                self._effective_profile = pid
                self._profile_switch_at = time.time() + random.uniform(120, 300)

    def set_volume(self, v):
        self.volume = max(0.0, min(1.0, float(v)))

    def set_noise_level(self, v):
        self.noise_level = max(0.0, min(1.0, float(v)))

    def set_event_rate(self, v):
        self.event_rate = max(0.0, min(1.0, float(v)))

    def set_bass(self, v):
        self.bass = max(0.0, min(1.0, float(v)))

    def set_breath(self, on):
        self.breath_on = bool(on)

    def set_breath_level(self, v):
        self.breath_level = max(0.0, min(1.0, float(v)))

    def set_breath_rate(self, v):
        self.breath_rate_base = max(6.0, min(24.0, float(v)))

    def set_muted(self, m):
        self._muted = bool(m)

    def is_running(self):
        return self._running

    def get_level(self):
        return float(self._level)

    def get_effective_profile(self):
        return self._effective_profile

    # ------------------------------------------- v1.3: muzyka, pauza, tapy
    def attach_timeline(self, timeline):
        """Podlacza os czasu muzyki — jej dzwiek leci razem z szumem."""
        self.timeline = timeline
        if self.mixer is not None:
            self.mixer.music_gain = float(getattr(timeline, "gain", 0.9) or 0.9)

    def set_paused(self, paused):
        """Pauza mikrofonu: cisza na wyjsciu + zatrzymana os czasu."""
        self._paused = bool(paused)

    def is_paused(self):
        return bool(self._paused)

    def add_tap(self, tap):
        try:
            if tap is not None and tap not in self.taps:
                self.taps.append(tap)
        except Exception:
            pass

    def remove_tap(self, tap):
        try:
            if tap in self.taps:
                self.taps.remove(tap)
        except Exception:
            pass

    def tap_signal(self):
        """Ostatnie ~2 s sygnalu mikrofonu (do nagrywania)."""
        return self.out_tap

    def start_monitor(self, device=None, gain=0.8):
        """Odsluch u siebie — dzwiek slyszalny w aplikacji (glosniki/sluchawki)."""
        if not HAS_TIMELINE or MonitorOut is None:
            self.last_error = "brak modulu odsluchu"
            return False
        if self.monitor is None:
            self.monitor = MonitorOut(self.sr, device=device, gain=gain)
        else:
            self.monitor.gain = float(gain)
            if self.monitor.device != device:
                # Merely replacing .device leaves the existing PortAudio stream
                # attached to the old output. Restart it through set_device so
                # the selector actually changes where monitoring is heard.
                self.monitor.set_device(device)
        self.add_tap(self.monitor.tap)
        return self.monitor.start()

    def stop_monitor(self):
        try:
            if self.monitor is not None:
                self.remove_tap(self.monitor.tap)
                self.monitor.stop()
        except Exception:
            pass

    def monitor_running(self):
        try:
            return bool(self.monitor is not None and self.monitor.running)
        except Exception:
            return False

    def monitor_level(self):
        try:
            return float(self.monitor.level()) if self.monitor is not None else 0.0
        except Exception:
            return 0.0

    def monitor_error(self):
        try:
            return str(self.monitor.last_error) if self.monitor is not None else ""
        except Exception:
            return ""

    def start(self, output_device=None):
        """Start strumienia. output_device: index lub nazwa urządzenia (np. CABLE Input)."""
        if self._running:
            return True
        self.output_device = output_device
        if self.demo_mode:
            self._running = True
            self._thread = threading.Thread(target=self._demo_loop, daemon=True)
            self._thread.start()
            return True
        try:
            if self.input_device is not None:
                self._stream = sd.Stream(
                    samplerate=self.sr, blocksize=self.block,
                    channels=(1, 2), dtype="float32",
                    device=(self.input_device, self.output_device),
                    callback=self._duplex_callback,
                )
            else:
                self._stream = sd.OutputStream(
                    samplerate=self.sr,
                    blocksize=self.block,
                    channels=2,
                    dtype="float32",
                    device=self.output_device,
                    callback=self._callback,
                )
            self._stream.start()
            self._running = True
            self.last_error = ""
            self._profile_switch_at = time.time() + random.uniform(120, 300)
            return True
        except Exception as e:
            self.last_error = str(e)
            # awaryjnie: spróbuj domyślnego urządzenia
            try:
                self._stream = sd.OutputStream(
                    samplerate=self.sr, blocksize=self.block,
                    channels=2, dtype="float32", device=None,
                    callback=self._callback,
                )
                self._stream.start()
                self._running = True
                self.last_error = f"Wybrane urządzenie niedostępne ({e}), użyto domyślnego."
                return True
            except Exception as e2:
                self.last_error = str(e2)
                # totalny fallback: tryb demo (żeby apka żyła)
                self.demo_mode = True
                self._running = True
                self._thread = threading.Thread(target=self._demo_loop, daemon=True)
                self._thread.start()
                return True

    def stop(self):
        self._running = False
        try:
            if self._stream is not None:
                self._stream.stop()
                self._stream.close()
        except Exception:
            pass
        self._stream = None
        self._level = 0.0
        self._active_events = []
        self._paused = False
        try:
            if self.out_tap is not None:
                self.out_tap.clear()
        except Exception:
            pass

    # ------------------------------------------------------- generowanie audio
    def _demo_loop(self):
        import random as _r
        while self._running and self.demo_mode:
            base = 0.06 + 0.05 * self.noise_level
            self._level = max(0.0, min(1.0, base + _r.uniform(-0.02, 0.10)))
            time.sleep(0.08)

    def _duplex_callback(self, indata, outdata, frames, time_info, status):
        """Route the microphone selected in Octo.su into Android's VB-CABLE."""
        try:
            mono = np.asarray(indata[:, 0], dtype=np.float32)
            gain = max(0.0, min(2.0, float(self.volume)))
            signal = np.clip(mono * gain, -1.0, 1.0)
            outdata[:, 0] = signal
            outdata[:, 1] = signal
            self._level = min(1.0, float(np.sqrt(np.mean(signal ** 2))) * 4.0)
            for tap in list(self.taps):
                try: tap.write(outdata.copy())
                except Exception: pass
        except Exception:
            outdata.fill(0)

    def _callback(self, outdata, frames, time_info, status):
        try:
            if self._paused:
                # PAUZA: cisza, os czasu stoi (nie przewija sie)
                buf = np.zeros((frames, 2), dtype=np.float32)
            else:
                try:
                    buf = self._render(frames)
                except Exception:
                    buf = np.zeros((frames, 2), dtype=np.float32)
                # muzyka z osi czasu — miks razem z szumem telefonu
                tl = self.timeline
                if tl is not None:
                    try:
                        music = tl.read(frames)
                    except Exception:
                        music = None
                    if self._muted:
                        pass
                    elif music is not None and len(music):
                        try:
                            if self.mixer is not None:
                                buf = self.mixer.mix(buf, music)
                            else:
                                buf = np.clip(buf + music, -1.0, 1.0).astype(np.float32)
                        except Exception:
                            pass
                if self._muted:
                    buf = np.zeros((frames, 2), dtype=np.float32)
        except Exception:
            buf = np.zeros((frames, 2), dtype=np.float32)
        # VU meter (RMS + peak hold prosty)
        try:
            rms = float(np.sqrt(np.mean(buf ** 2)))
            peak = rms * 4.0
            self._level = 0.75 * self._level + 0.25 * min(1.0, peak)
        except Exception:
            pass
        # kopia sygnalu dla odsluchu i nagrywania
        if self.taps:
            for _t in list(self.taps):
                try:
                    _t.write(buf)
                except Exception:
                    continue
        outdata[:] = buf

    def _render(self, frames):
        p = AUDIO_PROFILES.get(self._effective_profile, AUDIO_PROFILES["pokoj"])
        # tryb LOSOWY AI — co jakiś czas zmień scenerię
        if self.profile_id == "losowy" and time.time() > self._profile_switch_at:
            choices = [k for k in AUDIO_PROFILES.keys() if k != "losowy"]
            self._effective_profile = random.choice(choices)
            p = AUDIO_PROFILES[self._effective_profile]
            self._profile_switch_at = time.time() + random.uniform(90, 260)

        n = frames
        # --- 1) szum biały
        white = np.random.randn(n).astype(np.float32)
        # --- 2) szum różowy (aproksymacja Paula Kellet)
        pink = np.empty(n, dtype=np.float32)
        b = self._pink
        for i in range(n):
            w = float(np.random.randn())
            b[0] = 0.99886 * b[0] + w * 0.0555179
            b[1] = 0.99332 * b[1] + w * 0.0750759
            b[2] = 0.96900 * b[2] + w * 0.1538520
            b[3] = 0.86650 * b[3] + w * 0.3104856
            b[4] = 0.55000 * b[4] + w * 0.5329522
            b[5] = -0.7616 * b[5] - w * 0.0168980
            pink[i] = (b[0] + b[1] + b[2] + b[3] + b[4] + b[5] + b[6] + w * 0.5362) * 0.11
            b[6] = w * 0.115926
        # --- 3) szum brązowy (niskie dudnienie) — ciągłość
        brown = np.empty(n, dtype=np.float32)
        last = self._brown_last
        for i in range(n):
            w = float(np.random.randn())
            last = (last + 0.02 * w) / 1.02
            brown[i] = last * 3.5
        self._brown_last = last
        # --- 4) wiatr: filtrowany szum modulowany wolnym LFO
        wind = np.zeros(n, dtype=np.float32)
        if p["wind"] > 0.001:
            lfo_rate = 0.13 + 0.1 * self._wind_lfo
            idx = np.arange(n, dtype=np.float32)
            lfo = 0.5 + 0.5 * np.sin(2 * np.pi * lfo_rate * (self._wind_phase + idx / self.sr))
            # filtr dolnoprzepustowy jednobiegunowy na białym szumie
            alpha = 0.06
            f = np.empty(n, dtype=np.float32)
            prev = getattr(self, "_wind_prev", 0.0)
            wn = np.random.randn(n).astype(np.float32)
            for i in range(n):
                prev = prev + alpha * (wn[i] - prev)
                f[i] = prev
            self._wind_prev = float(prev)
            wind = (f * 2.2 * lfo).astype(np.float32)
            self._wind_phase += n / self.sr
            self._wind_lfo = (self._wind_lfo + 0.002) % 1.0
        # --- 5) przydźwięk 50 Hz
        hum = np.zeros(n, dtype=np.float32)
        if p["hum"] > 0.0005:
            idx = np.arange(n, dtype=np.float32)
            ph = self._hum_phase + idx / self.sr
            hum = (np.sin(2 * np.pi * 50 * ph) * 0.7
                   + np.sin(2 * np.pi * 100 * ph) * 0.2
                   + np.sin(2 * np.pi * 150 * ph) * 0.1).astype(np.float32)
            self._hum_phase = (self._hum_phase + n / self.sr) % 1.0
        # --- 6) pomruk silnika (samochód): 55 Hz + harmoniczne z wibrato
        if self._effective_profile == "samochod":
            idx = np.arange(n, dtype=np.float32)
            ph = self._engine_phase + idx / self.sr
            vib = 1.0 + 0.02 * np.sin(2 * np.pi * 7 * ph)
            eng = (np.sin(2 * np.pi * 55 * ph * vib)
                   + 0.5 * np.sin(2 * np.pi * 110 * ph)
                   + 0.25 * np.sin(2 * np.pi * 82.5 * ph)).astype(np.float32) * 0.5
            self._engine_phase = (self._engine_phase + n / self.sr) % 10.0
        else:
            eng = 0.0

        noise_mix = p["base"] * (0.45 * white + 0.55 * pink)
        ambience = p["wind"] * wind + p["rumble"] * brown + p["hum"] * hum
        mono = noise_mix * (0.25 + 1.75 * self.noise_level) + ambience + self._render_breath(n, p)
        if isinstance(eng, np.ndarray):
            mono = mono + p["rumble"] * 1.4 * eng

        # podbicie basów prostym filtrem (miks z wersją wygładzoną)
        if self.bass > 0.02:
            k = 0.02 + 0.10 * (1.0 - self.bass)
            prev = getattr(self, "_bass_prev", 0.0)
            smooth = np.empty(n, dtype=np.float32)
            for i in range(n):
                prev = prev + k * (mono[i] - prev)
                smooth[i] = prev
            self._bass_prev = float(prev)
            mono = (1.0 - 0.5 * self.bass) * mono + (0.5 * self.bass) * smooth * 1.6

        # --- 7) zdarzenia losowe
        mono = self._process_events(mono, p)

        # --- 8) charakterystyka "telefonu": lekka kompresja + pasmo
        mono = np.tanh(mono * 2.2) * 0.55
        # filtr górnoprzepustowy (usuń DC) + dolnoprzepustowy (telefon ~8kHz góra)
        hp_prev_in = getattr(self, "_hp_prev_in", 0.0)
        hp_prev_out = getattr(self, "_hp_prev_out", 0.0)
        lp_prev = getattr(self, "_lp_prev", 0.0)
        a_hp, a_lp = 0.995, 0.35
        out_m = np.empty(n, dtype=np.float32)
        for i in range(n):
            x = mono[i]
            hp = a_hp * (hp_prev_out + x - hp_prev_in)
            hp_prev_in, hp_prev_out = x, hp
            lp_prev = lp_prev + a_lp * (hp - lp_prev)
            out_m[i] = lp_prev
        self._hp_prev_in, self._hp_prev_out, self._lp_prev = hp_prev_in, hp_prev_out, lp_prev

        if self._muted:
            out_m[:] = 0.0
        else:
            out_m *= (self.volume * 1.6)

        # stereo z mikro-różnicą fazową (jak dwa mikrofony w telefonie)
        dly = int(self.sr * 0.0004)  # ~0.4 ms
        right = np.concatenate([getattr(self, "_st_tail", np.zeros(dly, dtype=np.float32)), out_m])[:n]
        self._st_tail = out_m[-dly:].copy() if n >= dly else out_m.copy()
        stereo = np.stack([out_m, right * 0.96 + out_m * 0.04], axis=1)
        np.clip(stereo, -0.98, 0.98, out=stereo)
        return stereo.astype(np.float32)

    def _render_breath(self, n, p):
        """Ciągły, cichy oddech — jak telefon trzymany blisko ust.

        Cykl: wdech (~38% czasu, jaśniejszy szum) + wydech (ciemniejszy).
        Tempo dryfuje naturalnie w zakresie 10–17 oddechów/min."""
        if not self.breath_on or self.breath_level <= 0.01:
            return 0.0
        gain = BREATH_GAIN.get(self._effective_profile, 0.35) * self.breath_level
        if gain <= 0.005:
            return 0.0
        lo = max(6.0, self.breath_rate_base - 3.0)
        hi = min(24.0, self.breath_rate_base + 3.0)
        self._breath_rate = max(lo, min(hi,
            self._breath_rate + random.uniform(-0.06, 0.06)))
        cyc = 60.0 / self._breath_rate
        idx = np.arange(n, dtype=np.float32) / self.sr
        ph = (self._breath_phase + idx / cyc) % 1.0
        self._breath_phase = (self._breath_phase + n / self.sr / cyc) % 1.0
        inh = ph < 0.38
        s_in = np.clip(np.sin(ph / 0.38 * np.pi / 2), 0.0, 1.0)
        s_out = np.clip(np.sin((1 - (ph - 0.38) / 0.62) * np.pi / 2), 0.0, 1.0)
        env = np.where(inh, s_in ** 1.5, s_out ** 1.2).astype(np.float32)
        w = np.random.randn(n).astype(np.float32)
        out = np.empty(n, dtype=np.float32)
        lp = self._breath_lp
        for i in range(n):
            a = 0.10 if inh[i] else 0.05
            lp += a * (w[i] - lp)
            out[i] = lp
        self._breath_lp = float(lp)
        t = self._breath_t + idx
        whistle = (np.sin(2 * np.pi * 540 * t).astype(np.float32) * (env ** 3)
                   * inh.astype(np.float32) * 0.05)
        self._breath_t += n / self.sr
        return ((out * 2.2 * env + whistle) * gain).astype(np.float32)

    # ------------------------------------------------------- zdarzenia losowe
    def _process_events(self, mono, p):
        n = len(mono)
        # odliczanie do następnego zdarzenia
        self._samples_until_event -= n
        if self._samples_until_event <= 0:
            rate = 0.15 + 1.85 * self.event_rate
            gap_lo, gap_hi = p["event_gap"]
            gap = random.uniform(gap_lo, gap_hi) / max(0.2, rate)
            self._samples_until_event = int(self.sr * max(0.4, gap))
            ev = random.choice(p["events"])
            try:
                samples = self._make_event(ev)
                if samples is not None and len(samples) > 0:
                    self._active_events.append({"s": samples, "pos": 0, "gain": random.uniform(0.5, 1.0)})
            except Exception:
                pass
        # miksuj aktywne zdarzenia
        if self._active_events:
            still = []
            for e in self._active_events:
                s, pos = e["s"], e["pos"]
                take = min(len(s) - pos, n)
                if take > 0:
                    mono[:take] += s[pos:pos + take] * e["gain"]
                    e["pos"] += take
                if e["pos"] < len(s):
                    still.append(e)
            self._active_events = still[-6:]  # max 6 naraz
        return mono

    def _make_event(self, kind):
        sr = self.sr
        R = random
        if kind == "click":  # krótkie kliknięcie
            L = int(sr * R.uniform(0.015, 0.05))
            t = np.arange(L) / sr
            env = np.exp(-t * R.uniform(120, 300))
            return (np.random.randn(L).astype(np.float32) * env * R.uniform(0.15, 0.5))
        if kind == "crackle":  # trzask elektryczny
            L = int(sr * R.uniform(0.03, 0.12))
            t = np.arange(L) / sr
            env = np.exp(-t * R.uniform(40, 120))
            f = R.uniform(1200, 4500)
            return ((np.sin(2 * np.pi * f * t) * 0.5 + np.random.randn(L) * 0.5).astype(np.float32) * env * R.uniform(0.1, 0.35))
        if kind == "thump_soft":  # miękkie puknięcie
            L = int(sr * R.uniform(0.08, 0.2))
            t = np.arange(L) / sr
            env = np.exp(-t * R.uniform(18, 40))
            f0 = R.uniform(70, 140)
            return (np.sin(2 * np.pi * f0 * t) * env * R.uniform(0.25, 0.6)).astype(np.float32)
        if kind == "rustle":  # tarcie o ubranie
            L = int(sr * R.uniform(0.25, 0.9))
            t = np.arange(L) / sr
            env = np.sin(np.pi * t / (L / sr)) ** 1.5
            f = np.random.randn(L).astype(np.float32)
            # filtr górnoprzepustowy przybliżony (różnicowy)
            f = np.concatenate([[0], np.diff(f)]).astype(np.float32)
            return (f * env * R.uniform(0.12, 0.4)).astype(np.float32)
        if kind == "wind_gust":  # podmuch wiatru
            L = int(sr * R.uniform(0.7, 2.2))
            t = np.arange(L) / sr
            T = L / sr
            env = (np.sin(np.pi * t / T) ** 2).astype(np.float32)
            f = np.random.randn(L).astype(np.float32)
            prev, out = 0.0, np.empty(L, dtype=np.float32)
            for i in range(L):
                prev = prev + 0.05 * (f[i] - prev)
                out[i] = prev
            return (out * 3.0 * env * R.uniform(0.3, 0.8)).astype(np.float32)
        if kind == "car":  # przejeżdżające auto (przesunięcie Dopplera — uproszczone)
            L = int(sr * R.uniform(1.2, 3.0))
            t = np.arange(L) / sr
            T = L / sr
            env = (np.sin(np.pi * t / T)).astype(np.float32)
            f0 = R.uniform(90, 160)
            sweep = f0 * (1.15 - 0.3 * t / T)
            phase = np.cumsum(sweep / sr) * 2 * np.pi
            tone = np.sin(phase) * 0.5 + np.sin(phase * 2.02) * 0.25
            noise = np.random.randn(L).astype(np.float32) * 0.3
            prev, out = 0.0, np.empty(L, dtype=np.float32)
            for i in range(L):
                prev = prev + 0.12 * ((tone[i] + noise[i]) - prev)
                out[i] = prev
            return (out * 1.8 * env * R.uniform(0.25, 0.6)).astype(np.float32)
        if kind == "murmur":  # gwar rozmów (bełkot — filtrowany szum z obwiednią mowy)
            L = int(sr * R.uniform(1.0, 2.5))
            t = np.arange(L) / sr
            # obwiednia "sylab" 3-6 Hz
            syl = 0.5 + 0.5 * np.sin(2 * np.pi * R.uniform(3, 6) * t + R.uniform(0, 6))
            f = np.random.randn(L).astype(np.float32)
            prev, out = 0.0, np.empty(L, dtype=np.float32)
            for i in range(L):
                prev = prev + 0.25 * (f[i] - prev)
                out[i] = prev
            hp = np.concatenate([[0], np.diff(out)]).astype(np.float32)
            return (hp * syl * R.uniform(0.15, 0.4)).astype(np.float32)
        if kind == "clink":  # stuknięcie szkła
            L = int(sr * R.uniform(0.2, 0.5))
            t = np.arange(L) / sr
            f1, f2 = R.uniform(2200, 3400), R.uniform(3400, 5200)
            env = np.exp(-t * R.uniform(10, 22))
            return ((np.sin(2 * np.pi * f1 * t) * 0.6 + np.sin(2 * np.pi * f2 * t) * 0.4) * env * R.uniform(0.08, 0.25)).astype(np.float32)
        if kind == "blinker":  # kierunkowskaz: cyk-cyk
            L = int(sr * 1.2)
            out = np.zeros(L, dtype=np.float32)
            for k in range(2):
                start = int(sr * (0.1 + k * 0.55))
                ln = int(sr * 0.06)
                tt = np.arange(ln) / sr
                env = np.exp(-tt * 160)
                out[start:start + ln] += (np.sin(2 * np.pi * 1800 * tt) * env * 0.3).astype(np.float32)
            return out
        if kind == "horn_far":  # daleki klakson
            L = int(sr * R.uniform(0.4, 0.9))
            t = np.arange(L) / sr
            env = np.sin(np.pi * t / (L / sr))
            f = R.uniform(300, 420)
            return ((np.sin(2 * np.pi * f * t) * 0.6 + np.sin(2 * np.pi * f * 1.25 * t) * 0.4) * env * R.uniform(0.06, 0.18)).astype(np.float32)
        if kind == "thunder_far":  # daleki grzmot
            L = int(sr * R.uniform(1.0, 2.5))
            t = np.arange(L) / sr
            env = (np.sin(np.pi * t / (L / sr)) ** 0.7).astype(np.float32)
            f = np.random.randn(L).astype(np.float32)
            prev, out = 0.0, np.empty(L, dtype=np.float32)
            for i in range(L):
                prev = prev + 0.03 * (f[i] - prev)
                out[i] = prev
            return (out * 4.0 * env * R.uniform(0.2, 0.5)).astype(np.float32)
        if kind == "sniff":  # krótkie wciągnięcie powietrza nosem
            L = int(sr * R.uniform(0.22, 0.4))
            t = np.arange(L) / sr
            env = (np.sin(np.pi * t / (L / sr)) ** 0.8).astype(np.float32)
            f = np.random.randn(L).astype(np.float32)
            hp = np.concatenate([[0], np.diff(f)]).astype(np.float32)
            tone = np.sin(2 * np.pi * R.uniform(500, 700) * t).astype(np.float32) * 0.2
            return ((hp * 0.8 + tone) * env * R.uniform(0.15, 0.3)).astype(np.float32)
        if kind == "sigh":  # westchnięcie — długi wydech z opadającym tonem
            L = int(sr * R.uniform(0.9, 1.6))
            t = np.arange(L) / sr
            T = L / sr
            env = (np.sin(np.pi * t / T) ** 0.7).astype(np.float32)
            f0 = R.uniform(280, 360)
            sweep = f0 * (1.0 - 0.35 * t / T)
            phase = np.cumsum(sweep / sr) * 2 * np.pi
            tone = (np.sin(phase) * 0.4 + np.sin(phase * 0.5) * 0.25).astype(np.float32)
            nz = np.random.randn(L).astype(np.float32)
            prev, out = 0.0, np.empty(L, dtype=np.float32)
            for i in range(L):
                prev = prev + 0.08 * (nz[i] - prev)
                out[i] = prev
            return ((out * 1.6 + tone) * env * R.uniform(0.15, 0.3)).astype(np.float32)
        if kind == "soft_breath":  # pojedynczy cichy oddech (wdech + wydech)
            L = int(sr * R.uniform(1.6, 2.6))
            t = np.arange(L) / sr
            T = L / sr
            env = (np.sin(np.pi * t / T)).astype(np.float32)
            nz = np.random.randn(L).astype(np.float32)
            prev, out = 0.0, np.empty(L, dtype=np.float32)
            for i in range(L):
                a = 0.09 if t[i] < T * 0.4 else 0.05
                prev = prev + a * (nz[i] - prev)
                out[i] = prev
            return (out * 2.0 * env * R.uniform(0.2, 0.35)).astype(np.float32)
        if kind == "deep_breath":  # głęboki, wolny oddech (noc)
            L = int(sr * R.uniform(2.5, 4.0))
            t = np.arange(L) / sr
            T = L / sr
            env = (np.sin(np.pi * t / T) ** 1.2).astype(np.float32)
            nz = np.random.randn(L).astype(np.float32)
            prev, out = 0.0, np.empty(L, dtype=np.float32)
            for i in range(L):
                a = 0.07 if t[i] < T * 0.42 else 0.04
                prev = prev + a * (nz[i] - prev)
                out[i] = prev
            return (out * 2.6 * env * R.uniform(0.22, 0.38)).astype(np.float32)
        return None
