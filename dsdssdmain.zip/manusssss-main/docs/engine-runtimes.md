# Native engine runtimes

OctoBrowser treats the browser engines as separately versioned runtime components. Engine files are not mixed with application JavaScript, profile data, or the Electron launcher.

## Packaged layout

A production package should contain this structure under the application resources directory:

```text
resources/
  engines/
    chromium/
      140.0.7339.0/
        chromium.exe                 # chromium on Linux/macOS
        *.dll                        # Windows dependencies, when applicable
        *.pak
        resources/
        locales/
        icudtl.dat
        snapshot_blob.bin
        v8_context_snapshot.bin
        runtime.json
    gecko/
      151.0.0-camoufox.1/
        camoufox.exe                # camoufox on Windows
        *.dll                        # Windows dependencies, when applicable
        browser/
        omni.ja
        resources/
        runtime.json
```

`runtime.json` is mandatory. Its schema is `octo.engine-manifest.v1` and records the engine kind, engine version, executable relative to the version directory, control protocol, supported target platforms, capabilities, and an optional SHA-256 digest. The application accepts an engine only when:

- the manifest schema and engine kind are valid;
- the current OS/architecture is listed;
- the executable resolves inside the version directory;
- the executable name matches the platform convention; and
- the executable exists.

The app selects the lexically newest version directory containing a valid manifest. An environment override is available for development: `OCTO_CHROMIUM_RUNTIME` or `OCTO_GECKO_RUNTIME` points to the directory containing version subdirectories. A packaged build should use `process.resourcesPath/engines/<kind>` and should not rely on a system browser.

The current Chromium migration branch retains an explicit development fallback to the legacy per-user InkBrowser location only when no packaged Chromium runtime is found. Invalid packaged manifests and escaping/missing executables are errors; they are not silently replaced with arbitrary files.

## Acquisition and signing

The repository does not check in browser binaries. A release pipeline must obtain an official or reproducibly built binary, verify its upstream license and release checksum/signature, place the complete runtime directory into the layout above, generate `runtime.json`, and sign the resulting application package. The runtime manifest's optional digest is metadata for the packaged artifact; it is not a substitute for release signing.

For Chromium, the release process must package the executable together with the matching DLLs, `.pak` files, resources, locales, ICU data, snapshots, and other files required by that exact build. Do not copy only the executable.

For Gecko, ordinary Firefox is not equivalent to Camoufox. Camoufox documents a patched Firefox build and separate portable packages for Linux, Windows, and macOS. Its build instructions use `make`/`multibuild.py`, and its browser is MPL-2.0 with separate launcher and third-party notices. The release pipeline must build or obtain a specific Camoufox release and record the exact version and license notices before advertising Gecko support.

`invisible_playwright` is an MIT-licensed Python Playwright-compatible wrapper that downloads a patched Firefox engine with its own fetch command. It supports Windows x86_64 and Linux x86_64/arm64 according to its documentation, but it is not itself a native TypeScript desktop-window runtime for this app. It is therefore a reference for a possible Gecko automation adapter and packaging evidence, not a substitute for the app's Gecko process contract.

References:

- Camoufox repository and build/licensing documentation: <https://github.com/daijro/camoufox>
- invisible_playwright repository, fetch model, supported platforms, and licensing: <https://github.com/feder-cr/invisible_playwright>
