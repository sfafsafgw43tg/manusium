#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const target = process.argv.find((arg) => arg.startsWith('--target='))?.slice('--target='.length) ?? `${process.platform}-${process.arch}`;
const out = path.resolve(root, process.argv.find((arg) => arg.startsWith('--out='))?.slice('--out='.length) ?? 'resources/engines/gecko/140.0');
const entry = {
  version: '140.0', platform: 'linux-x64',
  source: 'https://ftp.mozilla.org/pub/firefox/releases/140.0/linux-x86_64/en-US/firefox-140.0.tar.xz',
  archiveSha512: '481bb473c1c8279626e25d7253ee1735ca42e6898a5a664b21f1189d2779c2ecb555536eb46bcb2ac88066c286e831e17b23b877d7cd2d3b650083198c6dedc6',
};
if (target !== entry.platform) {
  console.error(`[stage-firefox] unsupported target ${target}; only ${entry.platform} is currently staged`);
  process.exit(2);
}
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'octo-firefox-stage-'));
const archive = path.join(temp, 'firefox.tar.xz');
const digest = (file) => crypto.createHash('sha512').update(fs.readFileSync(file)).digest('hex');
try {
  execFileSync('curl', ['-fL', '--retry', '3', entry.source, '-o', archive], { stdio: 'inherit' });
  if (digest(archive) !== entry.archiveSha512) throw new Error('Mozilla archive SHA-512 mismatch');
  const listing = execFileSync('tar', ['-tJf', archive], { encoding: 'utf8' }).split(/\r?\n/).filter(Boolean);
  if (listing.some((item) => item.replace(/\\/g, '/').startsWith('/') || item.replace(/\\/g, '/').split('/').includes('..'))) throw new Error('Unsafe archive path');
  const unpacked = path.join(temp, 'unpacked'); fs.mkdirSync(unpacked);
  execFileSync('tar', ['-xJf', archive, '-C', unpacked], { stdio: 'inherit' });
  const source = path.join(unpacked, 'firefox');
  if (!fs.existsSync(path.join(source, 'firefox'))) throw new Error('Firefox executable missing');
  const staged = `${out}.partial-${process.pid}`;
  fs.rmSync(staged, { recursive: true, force: true }); fs.mkdirSync(path.dirname(staged), { recursive: true });
  fs.cpSync(source, staged, { recursive: true }); fs.chmodSync(path.join(staged, 'firefox'), 0o755);
  fs.writeFileSync(path.join(staged, 'runtime.json'), `${JSON.stringify({ schema: 1, kind: 'firefox', protocol: 'remote-debugging', version: entry.version, executable: 'firefox', platforms: [entry.platform], executableSha256: crypto.createHash('sha256').update(fs.readFileSync(path.join(staged, 'firefox'))).digest('hex'), source: { url: entry.source, archiveSha512: entry.archiveSha512, license: 'MPL-2.0 with additional binary components and Mozilla trademark restrictions; preserve upstream notices.' } }, null, 2)}\n`);
  fs.writeFileSync(path.join(staged, 'NOTICE.firefox.txt'), `Firefox ${entry.version} from Mozilla.org.\nSource: ${entry.source}\nArchive SHA-512: ${entry.archiveSha512}\n`);
  fs.rmSync(out, { recursive: true, force: true }); fs.renameSync(staged, out);
  console.log(`[stage-firefox] staged ${entry.version} at ${out}`);
} finally { fs.rmSync(temp, { recursive: true, force: true }); }
