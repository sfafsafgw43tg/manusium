import * as crypto from 'node:crypto';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { execFileSync } from 'node:child_process';

/**
 * Firefox runtime distribution contract.
 *
 * The archive checksum is taken from Mozilla's signed SHA512SUMS release file.
 * We retain Mozilla's LICENSE/README/omni.ja files and write a local manifest
 * containing the executable digest before the runtime becomes discoverable.
 */
export interface GeckoCatalogEntry {
  version: string;
  platform: 'linux-x64';
  source: string;
  archiveSha512: string;
  executable: string;
  license: string;
}

export interface InstalledGeckoRuntime {
  entry: GeckoCatalogEntry;
  rootDir: string;
  executablePath: string;
  installed: boolean;
}

export const FIREFOX_CATALOG: readonly GeckoCatalogEntry[] = [
  {
    version: '140.0',
    platform: 'linux-x64',
    source: 'https://ftp.mozilla.org/pub/firefox/releases/140.0/linux-x86_64/en-US/firefox-140.0.tar.xz',
    archiveSha512: '481bb473c1c8279626e25d7253ee1735ca42e6898a5a664b21f1189d2779c2ecb555536eb46bcb2ac88066c286e831e17b23b877d7cd2d3b650083198c6dedc6',
    executable: 'firefox',
    license: 'MPL-2.0 with additional binary components and Mozilla trademark restrictions; preserve upstream notices.',
  },
] as const;

function sha512(file: string): string { return crypto.createHash('sha512').update(fs.readFileSync(file)).digest('hex'); }
function sha256(file: string): string { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function safeTarList(archive: string): void {
  const listing = execFileSync('tar', ['-tJf', archive], { encoding: 'utf8' }).split(/\r?\n/).filter(Boolean);
  for (const item of listing) {
    const clean = item.replace(/\\/g, '/');
    if (clean.startsWith('/') || clean.split('/').includes('..')) throw new Error(`Unsafe Firefox archive path: ${item}`);
  }
}

export function geckoCatalogEntry(version = FIREFOX_CATALOG[0].version, platform = process.platform, arch = process.arch): GeckoCatalogEntry {
  const key = `${platform}-${arch}`;
  const entry = FIREFOX_CATALOG.find((candidate) => candidate.version === version && candidate.platform === key);
  if (!entry) throw new Error(`No Firefox runtime catalog entry for ${version} on ${key}`);
  return entry;
}

export function listInstalledGecko(root: string, platform = process.platform, arch = process.arch): InstalledGeckoRuntime[] {
  return FIREFOX_CATALOG.filter((entry) => entry.platform === `${platform}-${arch}`).map((entry) => {
    const rootDir = path.join(root, entry.version);
    const executablePath = path.join(rootDir, entry.executable);
    let installed = false;
    try {
      const manifest = JSON.parse(fs.readFileSync(path.join(rootDir, 'runtime.json'), 'utf8')) as { version?: string; executableSha256?: string };
      installed = manifest.version === entry.version && fs.existsSync(executablePath) && manifest.executableSha256 === sha256(executablePath);
    } catch { /* incomplete runtime */ }
    return { entry, rootDir, executablePath, installed };
  });
}

export function installFirefoxRuntime(entry: GeckoCatalogEntry, root: string, fetch = true): InstalledGeckoRuntime {
  if (entry.platform !== `${process.platform}-${process.arch}`) throw new Error(`Firefox runtime ${entry.version} is not supported on ${process.platform}-${process.arch}`);
  fs.mkdirSync(root, { recursive: true });
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'octo-firefox-runtime-'));
  const archive = path.join(temp, 'firefox.tar.xz');
  const unpacked = path.join(temp, 'unpacked');
  try {
    if (fetch) execFileSync('curl', ['-fL', '--retry', '3', entry.source, '-o', archive], { stdio: 'inherit' });
    if (sha512(archive) !== entry.archiveSha512) throw new Error(`Firefox archive SHA-512 mismatch for ${entry.version}`);
    safeTarList(archive);
    fs.mkdirSync(unpacked, { recursive: true });
    execFileSync('tar', ['-xJf', archive, '-C', unpacked], { stdio: 'inherit' });
    const sourceRoot = path.join(unpacked, 'firefox');
    const sourceExecutable = path.join(sourceRoot, entry.executable);
    if (!fs.existsSync(sourceExecutable)) throw new Error(`Firefox executable missing from ${entry.version} archive`);
    const finalRoot = path.join(root, entry.version);
    const staged = `${finalRoot}.partial-${process.pid}`;
    fs.rmSync(staged, { recursive: true, force: true });
    fs.cpSync(sourceRoot, staged, { recursive: true });
    const executablePath = path.join(staged, entry.executable);
    fs.chmodSync(executablePath, 0o755);
    fs.writeFileSync(path.join(staged, 'runtime.json'), `${JSON.stringify({ schema: 1, kind: 'firefox', protocol: 'remote-debugging', version: entry.version, executable: entry.executable, platforms: [entry.platform], executableSha256: sha256(executablePath), source: { url: entry.source, archiveSha512: entry.archiveSha512, license: entry.license } }, null, 2)}\n`);
    fs.writeFileSync(path.join(staged, 'NOTICE.firefox.txt'), `Firefox ${entry.version} from Mozilla.org.\nSource: ${entry.source}\nArchive SHA-512: ${entry.archiveSha512}\n${entry.license}\n`);
    fs.rmSync(finalRoot, { recursive: true, force: true });
    fs.renameSync(staged, finalRoot);
    return { entry, rootDir: finalRoot, executablePath: path.join(finalRoot, entry.executable), installed: true };
  } finally {
    fs.rmSync(temp, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
  }
}

export function discoverFirefoxRuntime(resourcesPath: string, userRuntimeRoot: string, version = FIREFOX_CATALOG[0].version): string | null {
  const roots = [path.join(resourcesPath, 'engines', 'gecko'), userRuntimeRoot];
  for (const root of roots) {
    for (const runtime of listInstalledGecko(root)) {
      if (runtime.entry.version !== version || !runtime.installed) continue;
      return runtime.executablePath;
    }
  }
  return null;
}
