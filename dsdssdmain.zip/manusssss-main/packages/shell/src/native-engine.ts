import { spawn, ChildProcess } from 'node:child_process';
import * as fs from 'node:fs';
import * as net from 'node:net';
import * as os from 'node:os';
import * as path from 'node:path';

export type NativeEngineKind = 'chromium' | 'firefox';

export interface NativeEngineOptions {
  profileDir: string;
  url?: string;
  debugPort?: number;
  headless?: boolean;
  extraArgs?: string[];
  env?: NodeJS.ProcessEnv;
}

export interface NativeEngineProcess {
  kind: NativeEngineKind;
  executable: string;
  profileDir: string;
  child: ChildProcess;
  stop: (timeoutMs?: number) => Promise<void>;
}

export interface NativePageState {
  url: string;
  title: string;
}

interface CdpMessage {
  id?: number;
  method?: string;
  params?: Record<string, unknown>;
  result?: Record<string, unknown>;
  error?: { message?: string };
}

interface CdpTarget {
  type: string;
  webSocketDebuggerUrl?: string;
}

function requireAbsoluteDirectory(dir: string): string {
  if (!path.isAbsolute(dir)) throw new Error('Native engine profile directory must be absolute');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  return dir;
}

/** Build only documented, isolated arguments; callers may add engine-specific flags explicitly. */
export function nativeEngineArgs(kind: NativeEngineKind, options: NativeEngineOptions): string[] {
  const profileDir = requireAbsoluteDirectory(options.profileDir);
  const url = options.url ?? 'about:blank';
  const args: string[] = [];
  if (kind === 'chromium') {
    args.push(`--user-data-dir=${profileDir}`, '--no-first-run', '--no-default-browser-check', '--disable-sync');
    if (options.headless) args.push('--headless=new');
    if (options.debugPort !== undefined) {
      if (!Number.isInteger(options.debugPort) || options.debugPort < 1 || options.debugPort > 65535) throw new Error('Invalid native engine debug port');
      args.push(`--remote-debugging-port=${options.debugPort}`, `--remote-allow-origins=http://127.0.0.1:${options.debugPort}`);
    }
  } else {
    args.push('-profile', profileDir, '-no-remote');
    if (options.headless) args.push('--headless');
    if (options.debugPort !== undefined) {
      if (!Number.isInteger(options.debugPort) || options.debugPort < 1 || options.debugPort > 65535) throw new Error('Invalid native engine debug port');
      args.push('--remote-debugging-port', String(options.debugPort));
    }
  }
  return [...args, ...(options.extraArgs ?? []), url];
}

function waitForPort(port: number, timeoutMs: number, child: ChildProcess): Promise<void> {
  return new Promise((resolve, reject) => {
    const started = Date.now();
    let settled = false;
    const finish = (error?: Error) => {
      if (settled) return;
      settled = true;
      clearInterval(timer);
      clearTimeout(timeout);
      child.off('exit', onExit);
      error ? reject(error) : resolve();
    };
    const probe = () => {
      const socket = net.connect(port, '127.0.0.1');
      socket.once('connect', () => { socket.destroy(); finish(); });
      socket.once('error', () => socket.destroy());
      if (Date.now() - started >= timeoutMs) finish(new Error(`Native engine did not open debug port ${port}`));
    };
    const onExit = (code: number | null, signal: NodeJS.Signals | null) => finish(new Error(`Native engine exited before readiness (${code ?? signal ?? 'unknown'})`));
    const timer = setInterval(probe, 50);
    const timeout = setTimeout(() => finish(new Error(`Native engine readiness timed out after ${timeoutMs}ms`)), timeoutMs);
    child.once('exit', onExit);
    probe();
  });
}

function stopChild(child: ChildProcess, timeoutMs = 5000): Promise<void> {
  return new Promise((resolve) => {
    if (child.exitCode !== null || child.signalCode !== null) { resolve(); return; }
    let settled = false;
    const finish = () => { if (settled) return; settled = true; resolve(); };
    const kill = (signal: NodeJS.Signals) => {
      try {
        // Chromium is a process tree. Detached process groups prevent a
        // renderer/browser child from surviving after the controller closes.
        if (process.platform !== 'win32' && child.pid) process.kill(-child.pid, signal);
        else child.kill(signal);
      } catch { try { child.kill(signal); } catch { /* already gone */ } }
    };
    const timer = setTimeout(() => {
      kill('SIGKILL');
      const finalTimer = setTimeout(finish, 1000);
      child.once('exit', () => { clearTimeout(finalTimer); finish(); });
    }, timeoutMs);
    child.once('exit', () => { clearTimeout(timer); finish(); });
    kill('SIGTERM');
  });
}

/** Spawn a real Chromium or Gecko process and optionally wait for its DevTools port. */
export async function spawnNativeEngine(kind: NativeEngineKind, executable: string, options: NativeEngineOptions): Promise<NativeEngineProcess> {
  if (!path.isAbsolute(executable)) throw new Error('Native engine executable must be an absolute path');
  if (!fs.existsSync(executable)) throw new Error(`Native engine executable not found: ${executable}`);
  const profileDir = requireAbsoluteDirectory(options.profileDir);
  const child = spawn(executable, nativeEngineArgs(kind, { ...options, profileDir }), {
    detached: true,
    shell: false,
    stdio: ['ignore', 'ignore', 'pipe'],
    windowsHide: true,
    env: { ...process.env, ...options.env },
  });
  const earlyError = new Promise<never>((_, reject) => child.once('error', reject));
  try {
    if (options.debugPort !== undefined) await Promise.race([waitForPort(options.debugPort, 15_000, child), earlyError]);
    return { kind, executable, profileDir, child, stop: (timeoutMs?: number) => stopChild(child, timeoutMs) };
  } catch (error) {
    await stopChild(child, 1000);
    throw error;
  }
}

function targetUrl(port: number): string { return `http://127.0.0.1:${port}/json/list`; }

async function waitForTarget(port: number, timeoutMs: number): Promise<CdpTarget> {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const response = await fetch(targetUrl(port));
      if (response.ok) {
        const targets = await response.json() as CdpTarget[];
        const target = targets.find((entry) => entry.type === 'page' && entry.webSocketDebuggerUrl);
        if (target) return target;
      }
    } catch { /* Chromium is still starting */ }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error(`Chromium did not expose a page target on DevTools port ${port}`);
}

/** A small CDP client for one Chromium page. It deliberately exposes only the vertical-slice operations. */
export class CdpPage {
  private readonly socket: WebSocket;
  private nextId = 1;
  private readonly pending = new Map<number, { resolve: (value: CdpMessage) => void; reject: (error: Error) => void }>();
  private readonly events = new Map<string, Set<(params: Record<string, unknown>) => void>>();
  private closed = false;

  private constructor(socket: WebSocket) {
    this.socket = socket;
    socket.addEventListener('message', (event) => {
      const message = JSON.parse(String(event.data)) as CdpMessage;
      if (message.id !== undefined) {
        const request = this.pending.get(message.id);
        if (!request) return;
        this.pending.delete(message.id);
        if (message.error) request.reject(new Error(message.error.message ?? 'CDP command failed'));
        else request.resolve(message);
      } else if (message.method) {
        for (const listener of this.events.get(message.method) ?? []) listener(message.params ?? {});
      }
    });
    socket.addEventListener('close', () => this.fail(new Error('Chromium CDP connection closed')));
    socket.addEventListener('error', () => this.fail(new Error('Chromium CDP connection failed')));
  }

  static async connect(port: number, timeoutMs = 15_000): Promise<CdpPage> {
    const target = await waitForTarget(port, timeoutMs);
    if (!target.webSocketDebuggerUrl) throw new Error('Chromium page target has no websocket URL');
    const socket = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Timed out connecting to Chromium CDP')), timeoutMs);
      socket.addEventListener('open', () => { clearTimeout(timer); resolve(); }, { once: true });
      socket.addEventListener('error', () => { clearTimeout(timer); reject(new Error('Could not connect to Chromium CDP')); }, { once: true });
    });
    const page = new CdpPage(socket);
    await page.command('Page.enable');
    await page.command('Runtime.enable');
    return page;
  }

  private fail(error: Error): void {
    if (this.closed) return;
    for (const request of this.pending.values()) request.reject(error);
    this.pending.clear();
  }

  on(method: string, listener: (params: Record<string, unknown>) => void): () => void {
    const listeners = this.events.get(method) ?? new Set();
    listeners.add(listener);
    this.events.set(method, listeners);
    return () => listeners.delete(listener);
  }

  command(method: string, params: Record<string, unknown> = {}): Promise<CdpMessage> {
    if (this.closed) return Promise.reject(new Error('CDP page is closed'));
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.socket.send(JSON.stringify({ id, method, params }));
    });
  }

  async navigate(url: string): Promise<void> {
    if (!/^(https?|about|data):/i.test(url)) throw new Error('Native Chromium navigation requires an http(s), about, or data URL');
    await this.command('Page.navigate', { url });
  }

  async state(): Promise<NativePageState> {
    const result = await this.command('Runtime.evaluate', { expression: 'JSON.stringify({url: location.href, title: document.title})', returnByValue: true });
    const value = result.result?.result as { value?: string } | undefined;
    return JSON.parse(value?.value ?? '{"url":"","title":""}') as NativePageState;
  }

  async close(): Promise<void> {
    if (this.closed) return;
    this.closed = true;
    try { this.socket.close(); } catch { /* already closed */ }
  }
}

export function defaultNativeProfileRoot(appName = 'octo-native'): string {
  return path.join(os.tmpdir(), appName);
}
