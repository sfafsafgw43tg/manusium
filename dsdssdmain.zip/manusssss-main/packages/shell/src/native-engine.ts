import { spawn, ChildProcess } from 'node:child_process';
import * as fs from 'node:fs';
import * as net from 'node:net';
import * as os from 'node:os';
import * as path from 'node:path';

export type NativeEngineKind = 'chromium' | 'firefox';

export interface NativeEngineOptions {
  profileDir: string;
  url?: string;
  debugPort?: number;
  headless?: boolean;
  extraArgs?: string[];
  env?: NodeJS.ProcessEnv;
}

export interface NativeEngineProcess {
  kind: NativeEngineKind;
  executable: string;
  profileDir: string;
  child: ChildProcess;
  stop: (timeoutMs?: number) => Promise<void>;
}

function requireAbsoluteDirectory(dir: string): string {
  if (!path.isAbsolute(dir)) throw new Error('Native engine profile directory must be absolute');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  return dir;
}

/** Build only documented, isolated arguments; callers may add engine-specific flags explicitly. */
export function nativeEngineArgs(kind: NativeEngineKind, options: NativeEngineOptions): string[] {
  const profileDir = requireAbsoluteDirectory(options.profileDir);
  const url = options.url ?? 'about:blank';
  const args: string[] = [];
  if (kind === 'chromium') {
    args.push(`--user-data-dir=${profileDir}`, '--no-first-run', '--no-default-browser-check', '--disable-sync');
    if (options.headless) args.push('--headless=new');
    if (options.debugPort !== undefined) {
      if (!Number.isInteger(options.debugPort) || options.debugPort < 1 || options.debugPort > 65535) throw new Error('Invalid native engine debug port');
      args.push(`--remote-debugging-port=${options.debugPort}`, `--remote-allow-origins=http://127.0.0.1:${options.debugPort}`);
    }
  } else {
    args.push('-profile', profileDir, '-no-remote');
    if (options.headless) args.push('--headless');
    if (options.debugPort !== undefined) {
      if (!Number.isInteger(options.debugPort) || options.debugPort < 1 || options.debugPort > 65535) throw new Error('Invalid native engine debug port');
      args.push('--remote-debugging-port', String(options.debugPort));
    }
  }
  return [...args, ...(options.extraArgs ?? []), url];
}

function waitForPort(port: number, timeoutMs: number, child: ChildProcess): Promise<void> {
  return new Promise((resolve, reject) => {
    const started = Date.now();
    let settled = false;
    const finish = (error?: Error) => {
      if (settled) return;
      settled = true;
      clearInterval(timer);
      clearTimeout(timeout);
      child.off('exit', onExit);
      error ? reject(error) : resolve();
    };
    const probe = () => {
      const socket = net.connect(port, '127.0.0.1');
      socket.once('connect', () => { socket.destroy(); finish(); });
      socket.once('error', () => socket.destroy());
      if (Date.now() - started >= timeoutMs) finish(new Error(`Native engine did not open debug port ${port}`));
    };
    const onExit = (code: number | null, signal: NodeJS.Signals | null) => finish(new Error(`Native engine exited before readiness (${code ?? signal ?? 'unknown'})`));
    const timer = setInterval(probe, 50);
    const timeout = setTimeout(() => finish(new Error(`Native engine readiness timed out after ${timeoutMs}ms`)), timeoutMs);
    child.once('exit', onExit);
    probe();
  });
}

function stopChild(child: ChildProcess, timeoutMs = 5000): Promise<void> {
  return new Promise((resolve) => {
    if (child.exitCode !== null || child.signalCode !== null) { resolve(); return; }
    const timer = setTimeout(() => { try { child.kill('SIGKILL'); } catch { /* already gone */ } resolve(); }, timeoutMs);
    child.once('exit', () => { clearTimeout(timer); resolve(); });
    try { child.kill('SIGTERM'); } catch { clearTimeout(timer); resolve(); }
  });
}

/** Spawn a real Chromium or Gecko process and optionally wait for its DevTools port. */
export async function spawnNativeEngine(kind: NativeEngineKind, executable: string, options: NativeEngineOptions): Promise<NativeEngineProcess> {
  if (!path.isAbsolute(executable)) throw new Error('Native engine executable must be an absolute path');
  if (!fs.existsSync(executable)) throw new Error(`Native engine executable not found: ${executable}`);
  const profileDir = requireAbsoluteDirectory(options.profileDir);
  const child = spawn(executable, nativeEngineArgs(kind, { ...options, profileDir }), {
    detached: false,
    shell: false,
    stdio: ['ignore', 'ignore', 'pipe'],
    windowsHide: true,
    env: { ...process.env, ...options.env },
  });
  const earlyError = new Promise<never>((_, reject) => child.once('error', reject));
  try {
    if (options.debugPort !== undefined) await Promise.race([waitForPort(options.debugPort, 15_000, child), earlyError]);
    return { kind, executable, profileDir, child, stop: (timeoutMs?: number) => stopChild(child, timeoutMs) };
  } catch (error) {
    await stopChild(child, 1000);
    throw error;
  }
}

export function defaultNativeProfileRoot(appName = 'octo-native'): string {
  return path.join(os.tmpdir(), appName);
}
