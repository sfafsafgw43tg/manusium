import { afterEach, describe, expect, it } from 'vitest';
import * as fs from 'node:fs';
import * as net from 'node:net';
import * as os from 'node:os';
import * as path from 'node:path';
import { CdpPage, NativeEngineProcess, spawnNativeEngine } from '../src/native-engine';

const executable = process.env.OCTO_CHROMIUM_PATH || '/usr/bin/chromium';
const available = fs.existsSync(executable);
const suite = available ? describe : describe.skip;

function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address === 'string') { server.close(); reject(new Error('No ephemeral port')); return; }
      server.close(() => resolve(address.port));
    });
  });
}

suite('real Chromium CDP vertical slice', () => {
  let processUnderTest: NativeEngineProcess | undefined;
  let page: CdpPage | undefined;
  const roots: string[] = [];

  afterEach(async () => {
    await page?.close();
    await processUnderTest?.stop();
    page = undefined;
    processUnderTest = undefined;
    while (roots.length) fs.rmSync(roots.pop()!, { recursive: true, force: true });
  });

  it('launches an isolated real Chromium process and controls one page navigation', async () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'octo-cdp-test-'));
    roots.push(root);
    const port = await freePort();
    processUnderTest = await spawnNativeEngine('chromium', executable, {
      profileDir: path.join(root, 'profile'),
      debugPort: port,
      headless: true,
      url: 'about:blank',
      extraArgs: ['--no-sandbox', '--disable-gpu'],
    });
    page = await CdpPage.connect(port);
    await page.navigate('data:text/html,<title>Native%20Chromium</title><h1>native</h1>');
    const state = await page.state();
    expect(state.title).toBe('Native Chromium');
    expect(state.url).toContain('data:text/html');
  });

  it('surfaces a renderer/process crash as a closed native process', async () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'octo-cdp-crash-'));
    roots.push(root);
    const port = await freePort();
    processUnderTest = await spawnNativeEngine('chromium', executable, {
      profileDir: path.join(root, 'profile'),
      debugPort: port,
      headless: true,
      url: 'about:blank',
      extraArgs: ['--no-sandbox', '--disable-gpu'],
    });
    page = await CdpPage.connect(port);
    const exited = new Promise<number | null>((resolve) => processUnderTest!.child.once('exit', (code) => resolve(code)));
    await processUnderTest.stop();
    expect(await exited).not.toBeNull();
    await page.close();
    await expect(page.state()).rejects.toThrow(/closed|failed|WebSocket|CDP/i);
  });
});
