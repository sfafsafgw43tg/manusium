import { describe, expect, it } from 'vitest';
import * as path from 'node:path';
import { nativeEngineArgs } from '../src/native-engine';

describe('native engine process contract', () => {
  const profile = path.resolve('/tmp/octo-native-test-profile');

  it('builds isolated Chromium arguments with a DevTools endpoint', () => {
    expect(nativeEngineArgs('chromium', { profileDir: profile, debugPort: 9229, headless: true, url: 'about:blank' })).toEqual([
      `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check', '--disable-sync', '--headless=new',
      '--remote-debugging-port=9229', '--remote-allow-origins=http://127.0.0.1:9229', 'about:blank',
    ]);
  });

  it('builds isolated Gecko arguments without a shell command string', () => {
    expect(nativeEngineArgs('firefox', { profileDir: profile, debugPort: 9230, headless: true, url: 'about:blank' })).toEqual([
      '-profile', profile, '-no-remote', '--headless', '--remote-debugging-port', '9230', 'about:blank',
    ]);
  });

  it('rejects relative profile directories and invalid ports', () => {
    expect(() => nativeEngineArgs('chromium', { profileDir: 'relative/profile' })).toThrow(/absolute/);
    expect(() => nativeEngineArgs('chromium', { profileDir: profile, debugPort: 0 })).toThrow(/debug port/);
  });
});
