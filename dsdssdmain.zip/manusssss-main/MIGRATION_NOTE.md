# Native browser runtime migration note

## Why the requested migration was not completed

The current OctoSuite project is an Electron application. Its launcher, browser windows, tab views, trusted chrome, preload bridges, IPC handlers, secure storage, permissions, downloads, window lifecycle, packaging, and tests all depend on Electron APIs.

The requested architecture is not a small feature change. It requires replacing that runtime with separately managed Chromium and Gecko browser processes, then rebuilding the native window, tab, permission, download, storage, crash-recovery, IPC, installer, update, signing, and test layers around those processes.

The existing Firefox support does not provide this architecture. It can launch a separately configured Firefox binary for selected profiles, but it is not an embedded or fully integrated Gecko core. The current Firefox-looking shell also does not change the underlying Electron/Chromium engine.

Camoufox and invisible_playwright are useful references and Firefox automation integrations, but they do not replace the desktop runtime required by this application. Camoufox uses a patched Firefox distribution and custom Playwright interfaces. invisible_playwright is a Python Playwright-compatible wrapper with documented unsupported surfaces, including CDP, tracing, HAR, and API request context. Integrating either one would therefore require a new process boundary and an adapter contract rather than a direct import.

It would be inaccurate and unsafe to claim that Electron had been removed, that both native engine cores had been implemented, or that all fingerprinting behavior had been implemented and verified when the current source still contains Electron-dependent runtime code and no native Chromium/Gecko build pipeline.

## What was completed instead

The existing browser UI remains functional. Recent changes improved popup hover feedback and fixed notification lifecycle issues. Permission notifications are anchored below the security lock, and late notifications are ignored once browser shutdown begins.

## What is required for a complete migration

A complete migration needs a separately reviewed engine-runner contract, native process management, authenticated IPC, per-profile isolation, Chromium and Gecko runtime packaging, signed and reproducible engine builds, permission and download routing, secure storage integration, crash recovery, updater support, Windows packaging, and integration tests on each supported platform.

Until those pieces exist and pass runtime tests with the actual engine binaries, the migration must remain marked as incomplete.
