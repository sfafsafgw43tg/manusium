# Native browser runtime migration note

## Chromium runtime catalog milestone

The application now has a catalog-backed Chromium runtime manager. Chrome for Testing Stable **155.0.8059.39** is the default supported runtime, with Beta **156.0.8078.12** as an optional supported choice. The older 140.0.7339.207 build is marked retired and compatibility-only; it cannot be installed as a new runtime.

The catalog records exact version, channel, platform, source URL, archive checksum, support state, executable name, CDP protocol, and capabilities. It is validated at startup and has regression coverage for unsupported/unpinned/corrupt entries.

The profile editor now shows the platform's catalog entries, install status, channel and support state. Install downloads to a temporary directory, verifies the pinned checksum, rejects traversal paths, validates the executable, writes the versioned manifest and notice, and atomically installs the result. Removal is refused if a version is selected by any profile or used by a running native Chromium session. The profile stores the exact selected runtime version and native launch resolves that exact version through the existing manifest/checksum contract.

## Verification status

Linux x64 was verified in this sandbox with the real pinned Stable runtime: navigation, tabs, crash shutdown, and cleanup passed. The release workflow stages Windows x64 Stable and runs the Windows packaged-runtime test on `windows-latest`. Windows installer creation and visible launch are not proven by this Linux environment; the local cross-build produced `win-unpacked` but the NSIS step requires Wine here. No Gecko/Camoufox binary is added or advertised.

## Electron boundary

Electron still owns the launcher/profile-management window, existing browser chrome and `WebContentsView` windows, address bar/tab-strip rendering for Electron profiles, permissions/download/popup routing for Electron profiles, secure storage integration, much of window lifecycle, and the remaining Electron profile runtime. This catalog work does not remove Electron or claim a complete native-browser migration.

## Compatibility policy

Runtime removal is blocked while selected or running. Existing profile data is not silently migrated between versions. The next hardening stage is an explicit per-version profile-data schema marker and migration/rollback snapshot flow; until then, the app preserves the existing profile directory and blocks unsafe removal rather than silently downgrading data.

See `docs/chromium-runtime-catalog.md` and `docs/engine-runtimes.md` for source, checksums, licensing, update cadence, platform support, troubleshooting, and release requirements.
