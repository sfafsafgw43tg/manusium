# Native browser runtime migration note

## Chromium runtime packaging milestone

The repository now has a reproducible, pinned Chromium packaging path for the supported Windows x64 product target:

- Chrome for Testing **140.0.7339.207** is acquired from a fixed URL.
- The archive SHA-256 is checked before extraction.
- The complete runtime is staged under `resources/engines/chromium/140.0.7339.207/`.
- `runtime.json` uses `octo.engine-manifest.v1` and records platform, CDP protocol, capabilities, executable checksum, source URL, archive checksum, and licensing note.
- `npm run dist:browser` runs staging before electron-builder, and `extraResources` places the runtime under installed `resources/engines`.
- Discovery validates the manifest, supported platform, executable containment/name, and executable SHA-256 before launch.
- `npm run test:native-packaged` stages a real pinned Linux x64 Chrome for Testing runtime and runs real-CDP navigation and tab integration against that staged executable, not `/usr/bin/chromium`.

Windows visible-window behavior and the final Windows installer must still be verified on the Windows CI/release runner. Linux x64 staging and headless CDP verification are locally testable and are not claims of Windows UI verification.

## Existing work and remaining Electron boundary

The previous UI, popup, permission, profile creator, native process, and native tab-control work remains in place. Electron still owns the launcher/profile-management window, existing browser chrome and `WebContentsView` windows, address bar/tab-strip rendering, permission/download/popup routing for Electron profiles, secure-storage integration, much of window lifecycle, and the remaining Electron profile runtime. This milestone does **not** remove Electron and does not claim a complete native-browser migration.

Gecko/Camoufox remains a separate future runtime. No Gecko binary is added, staged, or advertised here.

## Reproducible commands

```bash
npm ci
npm run typecheck
npm test
npm run build:browser
npm run test:native-packaged
npm run dist:browser       # on Windows x64 release CI
```

The runtime acquisition, exact checksums, layout, notices, platform matrix, and troubleshooting are documented in `docs/engine-runtimes.md`.
